# Technical QC Report

- Run: `qc-de214c0a7289465b8aacf7c0536ac609`
- Project: `project-legacy-faceless-baseline-a82bca2bc076` revision 1
- Sequence: `sequence-main`
- Status: **passed**
- Output: `/tmp/video-engine-parity-faceless/canonical.mp4`
- Started: 2026-07-24T16:23:48.564510+00:00
- Completed: 2026-07-24T16:23:50.089448+00:00

## Checks

| Scope | Check | Status | Summary |
|---|---|---|---|
| ingest | `ingest.sources` | passed | validated 4 media source(s) |
| timeline | `timeline.invariants` | passed | validated timeline invariants and visual coverage |
| timeline | `timeline.caption_layout` | passed | validated 1 selected caption track(s) |
| timeline | `timeline.render_capabilities` | passed | timeline compiles to supported backend capabilities |
| video | `video.output` | passed | validated dimensions, frame rate, and colour tags |
| video | `video.signal` | passed | scanned encoded frames for unexpected black and frozen intervals |
| video | `video.graphics_bounds` | passed | validated per-frame alpha bounds for designed graphics |
| audio | `audio.signal` | passed | measured loudness, peak, silence, channel balance, and mono compatibility |
| audio | `audio.duration_sync` | passed | compared stream-level audio and video durations |
| audio | `audio.boundary_pops` | passed | sampled 12 audio edit boundary/boundaries |
| delivery | `delivery.output` | passed | validated playability, streams, codecs, duration, fast-start, and hashes |
| video | `video.contact_sheet` | passed | generated and hashed encoded-output contact sheet |

## Findings

No technical findings.

## Evidence

- `contact_sheet`: `/tmp/video-engine-parity-faceless/qc/contact-sheet.png` (sha256 `ca315e2c63c5def82120a475b2c7b684fbcf7ef2cc174a0933e89cbdefaef15f`, 575343 bytes)

## Policy

```json
{
  "audio_video_tolerance_samples": 1024,
  "black_is_blocking": false,
  "black_min_duration_seconds": 0.5,
  "boundary_pop_threshold": 0.35,
  "channel_imbalance_db": 6.0,
  "clipping_threshold_dbfs": -0.1,
  "decode_all_sources": true,
  "duration_tolerance_frames": 1,
  "fail_on_warnings": false,
  "freeze_is_blocking": false,
  "freeze_min_duration_seconds": 2.0,
  "generate_contact_sheet": true,
  "implicit_blank_is_blocking": false,
  "loudness_range_tolerance_lu": 3.0,
  "loudness_tolerance_lu": 1.0,
  "max_boundary_checks": 250,
  "mono_cancellation_db": 9.0,
  "silence_min_duration_seconds": 2.0,
  "silence_noise_db": -60.0,
  "unexpected_silence_is_blocking": false,
  "verify_source_hashes": true
}
```
