# Media Parity Report

- Status: **passed**
- Reference: `/home/stanley/video-editing/test_projects/engine_baseline/outputs/legacy_faceless_preview.mp4`
- Candidate: `/home/stanley/video-editing/test_projects/engine_baseline/outputs/canonical_faceless_preview.mp4`
- Candidate frames: 48
- Candidate duration exact: True

## Frame Samples

| Time | Reference | Candidate | Distance | Pass |
| --- | --- | --- | ---: | --- |

## Audio Samples

- 8/24s: 336.00 Hz vs 324.00 Hz (delta 12.00 Hz, pass=True)
- 30/24s: 336.00 Hz vs 336.00 Hz (delta 0.00 Hz, pass=True)
- 40/24s: 324.00 Hz vs 336.00 Hz (delta 12.00 Hz, pass=True)

## Documented Improvements

- Program duration is 48 frames instead of the truncated legacy 46 frames.
- Mono legacy audio is delivered as explicit stereo.
- Pillow overlays are replaced by full-resolution registered Remotion graphics.
