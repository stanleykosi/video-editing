# Technical QC Report

- Run: `qc-518e7e31ea3d4d988cf73f6b7f798911`
- Project: `project-edl-24939d8e71a2` revision 1
- Sequence: `sequence-main`
- Status: **passed_with_warnings**
- Output: `/tmp/video-engine-parity-existing/canonical.mp4`
- Started: 2026-07-24T16:34:29.432693+00:00
- Completed: 2026-07-24T16:34:33.194434+00:00

## Checks

| Scope | Check | Status | Summary |
|---|---|---|---|
| ingest | `ingest.sources` | passed | validated 4 media source(s) |
| timeline | `timeline.invariants` | passed | validated timeline invariants and visual coverage |
| timeline | `timeline.caption_layout` | warning | validated 1 selected caption track(s) |
| timeline | `timeline.render_capabilities` | passed | timeline compiles to supported backend capabilities |
| video | `video.output` | passed | validated dimensions, frame rate, and colour tags |
| video | `video.signal` | passed | scanned encoded frames for unexpected black and frozen intervals |
| video | `video.graphics_bounds` | passed | timeline contains no designed graphics requiring bounds telemetry |
| audio | `audio.signal` | warning | measured loudness, peak, silence, channel balance, and mono compatibility |
| audio | `audio.duration_sync` | passed | compared stream-level audio and video durations |
| audio | `audio.boundary_pops` | passed | sampled 8 audio edit boundary/boundaries |
| delivery | `delivery.output` | passed | validated playability, streams, codecs, duration, fast-start, and hashes |
| video | `video.contact_sheet` | passed | generated and hashed encoded-output contact sheet |

## Findings

- **NON-BLOCKING** `caption.reading_speed` at `caption_track:captions/cue:captions-1`: caption exceeds the configured reading speed
- **NON-BLOCKING** `audio.loudness_range_failure`: loudness range is outside the configured delivery tolerance
  - `loudness_range`: 0.0 LU; expected 11.0

## Evidence

- `contact_sheet`: `/tmp/video-engine-parity-existing/qc/contact-sheet.png` (sha256 `7342f864f8d3d1feb7b6db4a3d7f13e2924ea990dad30698b8b127d4ced8bd73`, 231108 bytes)

## Policy

```json
{
  "audio_video_tolerance_samples": 1024,
  "black_is_blocking": false,
  "black_min_duration_seconds": 0.5,
  "boundary_pop_threshold": 0.35,
  "channel_imbalance_db": 6.0,
  "clipping_threshold_dbfs": -0.1,
  "decode_all_sources": true,
  "duration_tolerance_frames": 1,
  "fail_on_warnings": false,
  "freeze_is_blocking": false,
  "freeze_min_duration_seconds": 2.0,
  "generate_contact_sheet": true,
  "implicit_blank_is_blocking": false,
  "loudness_range_tolerance_lu": 3.0,
  "loudness_tolerance_lu": 1.0,
  "max_boundary_checks": 250,
  "mono_cancellation_db": 9.0,
  "silence_min_duration_seconds": 2.0,
  "silence_noise_db": -60.0,
  "unexpected_silence_is_blocking": false,
  "verify_source_hashes": true
}
```
