# Media Parity Report

- Status: **passed**
- Reference: `/home/stanley/video-editing/test_projects/engine_baseline/outputs/legacy_base_preview.mp4`
- Candidate: `/home/stanley/video-editing/test_projects/engine_baseline/outputs/canonical_base_preview.mp4`
- Candidate frames: 58
- Candidate duration exact: True

## Frame Samples

| Time | Reference | Candidate | Distance | Pass |
| --- | --- | --- | ---: | --- |
| 1/24s | `e767a7e7e7e6e7e7` | `6767a7e7e7e6e7e7` | 1 | True |
| 7/24s | `67e7e7a7e7e7e7e7` | `67e767a7e7e7e6e7` | 2 | True |
| 14/24s | `67e7e7e7a7e7e7e7` | `67e7e76727e7e7e7` | 2 | True |
| 22/24s | `000000000069cbc2` | `080808080869c3c2` | 6 | True |
| 29/24s | `000000000069cbc2` | `080808080869c3c2` | 6 | True |
| 38/24s | `000000000069cbc2` | `080808080869c3c2` | 6 | True |
| 44/24s | `67e7e7e7e7e567e7` | `67e7e7e7e7e567e7` | 0 | True |
| 50/24s | `67e7e7e7e7e7e767` | `67e7e7e7e7e7e767` | 0 | True |
| 54/24s | `67e7e7e7e7e7e767` | `67e7e7e7e7e7e767` | 0 | True |

## Audio Samples

- 5/24s: 444.00 Hz vs 444.00 Hz (delta 0.00 Hz, pass=True)
- 27/24s: 552.00 Hz vs 552.00 Hz (delta 0.00 Hz, pass=True)
- 47/24s: 444.00 Hz vs 444.00 Hz (delta 0.00 Hz, pass=True)

## Documented Improvements

- Frame-quantized cuts remove the legacy two-frame duration overrun.
