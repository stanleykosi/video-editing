# Media Parity Report

- Status: **passed**
- Reference: `/home/stanley/video-editing/test_projects/engine_baseline/outputs/legacy_existing_preview.mp4`
- Candidate: `/home/stanley/video-editing/test_projects/engine_baseline/outputs/canonical_existing_preview.mp4`
- Candidate frames: 58
- Candidate duration exact: True

## Frame Samples

| Time | Reference | Candidate | Distance | Pass |
| --- | --- | --- | ---: | --- |
| 2/24s | `e767a7e7e7e6e7e7` | `6767a7e7e7e7e6e7` | 3 | True |
| 32/24s | `000000000069cbc2` | `080808080869c3c2` | 6 | True |
| 57/24s | `67e7e7e7e7e7e767` | `67e7e7e7e7e76767` | 1 | True |

## Audio Samples

- 5/24s: 444.00 Hz vs 444.00 Hz (delta 0.00 Hz, pass=True)
- 27/24s: 552.00 Hz vs 552.00 Hz (delta 0.00 Hz, pass=True)
- 47/24s: 444.00 Hz vs 444.00 Hz (delta 0.00 Hz, pass=True)

## Documented Improvements

- Canonical output is 58 frames instead of the legacy 60-frame overrun.
