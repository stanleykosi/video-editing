from pathlib import Path

import pytest

from editorial_brain import EditorialBrain
from editorial_brain.benchmark.fixtures import synthetic_fixture
from editorial_brain.benchmark.runner import _run_scenario
from editorial_brain.benchmark.scenarios import SCENARIOS

REQUIRED_METRICS = {
    "invalid_source_ranges",
    "cuts_inside_words",
    "missing_required_beats",
    "duration_error",
    "duplicate_source_usage",
    "repetition_score",
    "continuity_violations",
    "visual_requirement_match",
    "reaction_preservation",
    "audio_picture_alignment",
    "must_include_coverage",
    "must_exclude_violations",
    "patch_validation",
    "engine_compile_success",
    "deterministic_repeatability",
    "expected_select_top_k_recall",
    "expected_cut_window_accuracy",
    "expected_candidate_rank",
    "expected_j_l_cut_decision",
    "expected_reaction_hold",
}


@pytest.mark.golden
@pytest.mark.parametrize("scenario", SCENARIOS, ids=lambda item: item.id)
def test_golden_scenario_executes_plan_and_engine_compile(tmp_path: Path, scenario) -> None:
    result = _run_scenario(tmp_path, scenario)
    metrics = {metric.name: metric for metric in result.metrics}
    assert result.passed
    assert metrics.keys() >= REQUIRED_METRICS
    assert all(metrics[name].passed for name in REQUIRED_METRICS)


@pytest.mark.golden
def test_intentional_long_hold_emits_no_boundary_cut(tmp_path: Path) -> None:
    scenario = next(item for item in SCENARIOS if item.id == "intentional_long_hold")
    project, brief, index, _ = synthetic_fixture(tmp_path, scenario)
    plan = (
        EditorialBrain(tmp_path)
        .plan(
            project=project,
            brief=brief,
            analysis=index,
            variants=3,
        )
        .best
    )
    assert len(plan.assembly.segments) == 1
    assert plan.assembly.cut_ids == []
    assert plan.assembly.segments[0].source_range.duration == brief.constraints.target_duration


@pytest.mark.golden
def test_dialogue_golden_preserves_reaction_with_continuing_audio(tmp_path: Path) -> None:
    scenario = next(item for item in SCENARIOS if item.id == "interview")
    project, brief, index, _ = synthetic_fixture(tmp_path, scenario)
    plan = (
        EditorialBrain(tmp_path)
        .plan(
            project=project,
            brief=brief,
            analysis=index,
            variants=3,
        )
        .best
    )
    reaction = plan.assembly.segments[1]
    assert reaction.role == "reaction"
    assert reaction.audio_relationship.value == "reaction_continuing_dialogue"
    assert reaction.source_range.overlaps(index.shots[1].reactions[0].source_range)
