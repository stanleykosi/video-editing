from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from editorial_brain import EditorialBrain
from editorial_brain.analysis.audio_events import AudioWindow
from editorial_brain.analysis.motion import motion_direction, optical_flow_energy
from editorial_brain.analysis.pauses import classify_pauses
from editorial_brain.analysis.speech import (
    build_phrases,
    cuts_inside_words,
    nearest_word_boundary,
)
from editorial_brain.analysis.synchronization import correlate_audio
from editorial_brain.continuity.audio import dialogue_continuity, room_tone_score
from editorial_brain.core.confidence import conservative_confidence, weighted_confidence
from editorial_brain.core.evidence import evidence_by_id, merge_evidence, require_evidence_kind
from editorial_brain.core.models import (
    Confidence,
    EditorialBrief,
    EditorialProject,
    EvidenceBundle,
    EvidenceKind,
    PauseClass,
    SourceSynchronization,
    SpeakerSegment,
)
from editorial_brain.core.provenance import segment_extensions
from editorial_brain.cuts.action import action_cut_bonus
from editorial_brain.observability.metrics import MetricsCollector
from editorial_brain.observability.trace import TraceBuilder
from editorial_brain.planning.broll import rank_broll
from editorial_brain.planning.montage import montage_cut_anchors, order_montage
from editorial_brain.planning.multicam import apply_multicam_preferences, plan_multicam
from editorial_brain.policies.registry import PolicyRegistry
from editorial_brain.providers.base import (
    EmbeddingRequest,
    FrameInput,
    ProviderStatus,
    TranscriptionRequest,
    VisionRequest,
)
from editorial_brain.providers.deterministic import (
    DeterministicEmbeddingProvider,
    DeterministicTranscriptionProvider,
    DeterministicVisionProvider,
)
from editorial_brain.providers.registry import ProviderRegistry
from editorial_brain.rhythm.density import information_density
from editorial_brain.rhythm.energy import combined_energy
from editorial_brain.rhythm.music_alignment import nearest_music_alignment
from editorial_brain.rhythm.repetition import repetition_score
from editorial_brain.search.dynamic import duration_knapsack
from editorial_brain.search.ranking import rank_assemblies
from editorial_brain.selects.generator import generate_selects
from editorial_brain.storage.project_store import EditorialProjectStore
from editorial_brain.story.beats import build_story_map
from editorial_brain.story.brief import normalize_brief
from editorial_brain.story.structure import missing_mandatory_beats, topological_beat_ids
from editorial_brain.understanding.camera import camera_from_labels
from editorial_brain.understanding.reactions import protection_window, reactions_from_labels
from editorial_brain.understanding.subjects import subjects_from_labels
from editorial_brain.understanding.visible_events import actions_from_labels
from video_engine.api import RationalTime, TimeRange


def test_speech_pause_audio_and_sync_utilities(editorial_index) -> None:
    original = editorial_index.transcripts[0]
    shifted = [
        word.model_copy(
            update={
                "source_range": TimeRange(
                    start=RationalTime(value=position * 2, timescale=1),
                    duration=RationalTime(value=1, timescale=2),
                )
            }
        )
        for position, word in enumerate(original.words)
    ]
    transcript = original.model_copy(update={"words": shifted, "phrases": []}, deep=True)
    phrased = build_phrases(transcript)
    assert len(phrased.phrases) == len(shifted)
    assert cuts_inside_words(phrased, [RationalTime(value=1, timescale=4)])
    assert nearest_word_boundary(phrased, RationalTime(value=3, timescale=4), edge="out")
    windows = [
        AudioWindow(
            id=f"window-{position}",
            media_id=transcript.media_id,
            source_range=word.source_range,
            rms=0.001,
            peak=0.01,
            transient_strength=0,
            silent=True,
        )
        for position, word in enumerate(shifted)
    ]
    pauses = classify_pauses(transcript, audio_windows=windows, audio_events=[])
    assert pauses
    assert {item.classification for item in pauses} <= {
        PauseClass.THINKING_PAUSE,
        PauseClass.DEAD_SPACE,
    }
    assert (
        room_tone_score(
            windows,
            windows,
            left_time=shifted[0].source_range.start,
            right_time=shifted[1].source_range.start,
        )
        == 1
    )
    assert dialogue_continuity(original, original) == 1
    waveform = np.sin(np.linspace(0, 12, 2000, dtype=np.float64))
    sync = correlate_audio(
        waveform,
        np.roll(waveform, 20),
        sample_rate=100,
        reference_media_id="left",
        target_media_id="right",
        reference_media_sha256="a" * 64,
        target_media_sha256="b" * 64,
        maximum_offset_seconds=2,
    )
    assert abs(float(sync.target_offset.fraction)) <= 2
    assert len(sync.evidence) == 2


def test_visual_rhythm_search_and_planning_helpers(
    tmp_path: Path, editorial_project, editorial_brief, editorial_index
) -> None:
    shot = editorial_index.shots[1].model_copy(
        update={
            "semantics": editorial_index.shots[1].semantics.model_copy(
                update={
                    "search_terms": [
                        "subject:product",
                        "action:opens lid",
                        "gesture",
                        "close",
                        "pan",
                    ]
                }
            )
        },
        deep=True,
    )
    assert subjects_from_labels(shot)[0].label == "product"
    assert actions_from_labels(shot)[0].label == "opens lid"
    reaction = reactions_from_labels(shot)[0]
    assert protection_window(reaction).duration > reaction.source_range.duration
    assert camera_from_labels(shot).shot_scale == "close"
    assert information_density(shot, editorial_index.transcripts) >= 0
    assert combined_energy(shot, editorial_index.audio_events) >= 0

    brain = EditorialBrain(tmp_path)
    story = brain.build_story(
        project=editorial_project, brief=editorial_brief, analysis=editorial_index
    ).story
    selects = brain.generate_selects(
        project=editorial_project, brief=editorial_brief, analysis=editorial_index
    ).candidates
    assert rank_broll(story.beats[0], selects, purpose="visual_proof")
    assert order_montage(selects, editorial_index.music_events)
    assert montage_cut_anchors(editorial_index.music_events) == []
    assert nearest_music_alignment(RationalTime.zero(), []) == 0.5
    chosen = duration_knapsack(selects, target_milliseconds=4000)
    assert chosen
    with pytest.raises(ValueError):
        duration_knapsack(selects, target_milliseconds=0)
    plan_set = brain.plan(
        project=editorial_project,
        brief=editorial_brief,
        analysis=editorial_index,
        variants=2,
    )
    assert rank_assemblies([item.plan.assembly for item in plan_set.variants])[0]
    assert repetition_score(plan_set.best.assembly.segments) == 0
    selected_cut = next(
        (point for point in plan_set.best.cut_points if point.kind == "motion_start"), None
    )
    if selected_cut is not None:
        assert action_cut_bonus(selected_cut) > 0


def test_evidence_confidence_registry_storage_and_observability(
    tmp_path: Path, editorial_project, editorial_brief, editorial_index
) -> None:
    bundle = editorial_index.evidence
    assert evidence_by_id(bundle)
    assert {item.id for item in merge_evidence(bundle, EvidenceBundle()).refs} == {
        item.id for item in bundle.refs
    }
    require_evidence_kind(bundle.refs[0], {bundle.refs[0].kind})
    with pytest.raises(ValueError):
        require_evidence_kind(bundle.refs[0], {EvidenceKind.USER_SUPPLIED})
    low = Confidence(score=0.3, basis=EvidenceKind.MEASURED, calibration="low")
    high = Confidence(score=0.9, basis=EvidenceKind.OBSERVED, calibration="high")
    assert conservative_confidence([low, high], basis=EvidenceKind.DERIVED).score == 0.3
    assert weighted_confidence([(low, 1), (high, 3)], basis=EvidenceKind.DERIVED).score == 0.75

    policies = PolicyRegistry()
    assert policies.ids() == ["dialogue", "montage", "narration", "neutral"]
    with pytest.raises(KeyError):
        policies.get("missing")
    with pytest.raises(ValueError):
        policies.register(policies.get("neutral"))

    provider_registry = ProviderRegistry()
    embedding = DeterministicEmbeddingProvider(dimensions=8)
    provider_registry.register("embedding", embedding)
    assert provider_registry.available("embedding") == ["deterministic"]
    assert provider_registry.get("embedding", "deterministic") is embedding
    with pytest.raises(ValueError):
        provider_registry.register("embedding", embedding)

    metrics = MetricsCollector()
    metrics.start("selects")
    metrics.increment("selects", "candidates", 3)
    assert metrics.finish("selects").counters == {"candidates": 3}
    trace = TraceBuilder("run")
    trace.stage("analysis", {"shots": 2})
    assert trace.build().stage_metrics["analysis"] == {"shots": 2}

    brain = EditorialBrain(tmp_path)
    plan = brain.plan(
        project=editorial_project,
        brief=editorial_brief,
        analysis=editorial_index,
        variants=1,
    ).best
    assert segment_extensions(plan.assembly.segments[0], plan.decisions[0])
    store = EditorialProjectStore()
    editorial_project_model = EditorialProject(
        id="brain-project",
        engine_project_id=editorial_project.id,
        engine_project_revision=editorial_project.revision,
        brief=editorial_brief,
        analysis_version=editorial_index.analysis_version,
    )
    project_path = store.save_project(tmp_path / "brain-project.json", editorial_project_model)
    assert store.load_project(project_path) == editorial_project_model
    plan_path = store.save_plan(tmp_path / "plan.json", plan)
    assert store.load_plan(plan_path) == plan
    assert (
        normalize_brief(EditorialBrief(id="brief", objective="  make   edit ")).objective
        == "make edit"
    )
    assert topological_beat_ids(plan.story)
    assert missing_mandatory_beats(plan.story, set())


def test_deterministic_media_providers(tmp_path: Path, editorial_index) -> None:
    transcript = editorial_index.transcripts[0]
    source = (tmp_path / "audio.wav").resolve()
    source.write_bytes(b"fixture")
    transcription = DeterministicTranscriptionProvider(
        {transcript.media_sha256: transcript}
    ).transcribe(
        TranscriptionRequest(
            request_id="transcription",
            media_id=transcript.media_id,
            media_sha256=transcript.media_sha256,
            source_path=source,
        )
    )
    assert transcription.status is ProviderStatus.SUCCESS
    missing = DeterministicTranscriptionProvider().transcribe(
        TranscriptionRequest(
            request_id="missing",
            media_id=transcript.media_id,
            media_sha256=transcript.media_sha256,
            source_path=source,
        )
    )
    assert missing.status is ProviderStatus.UNAVAILABLE
    vectors = DeterministicEmbeddingProvider(dimensions=8).embed(
        EmbeddingRequest(request_id="embed", texts={"proof": "product proof"})
    )
    assert vectors.output is not None and len(vectors.output.vectors["proof"]) == 8
    frame = (tmp_path / "frame.jpg").resolve()
    frame.write_bytes(b"not-decoded-by-fixture-provider")
    vision = DeterministicVisionProvider({"d" * 64: ["proof", "detail"]}).inspect(
        VisionRequest(
            request_id="vision",
            task="proof",
            instruction="find proof",
            frames=[FrameInput(candidate_id="frame", path=frame, sha256="d" * 64)],
        )
    )
    assert vision.status is ProviderStatus.SUCCESS


def test_optical_flow_measurements() -> None:
    previous = np.zeros((32, 32, 3), dtype=np.uint8)
    current = previous.copy()
    current[:, 4:, :] = 255
    assert 0 <= optical_flow_energy(previous, current) <= 1
    assert motion_direction(previous, current) in {
        "neutral",
        "left_to_right",
        "right_to_left",
    }


def test_multicam_preferences_require_sync_and_use_speaker_evidence(
    editorial_brief, editorial_index
) -> None:
    second_sha = "b" * 64
    second_shot = editorial_index.shots[1].model_copy(
        update={
            "id": "shot-camera-b",
            "media_id": "camera-b",
            "media_sha256": second_sha,
            "semantics": editorial_index.shots[1].semantics.model_copy(
                update={
                    "search_terms": [
                        *editorial_index.shots[1].semantics.search_terms,
                        "speaker:speaker-1",
                    ]
                }
            ),
            "evidence": [
                editorial_index.shots[1]
                .evidence[0]
                .model_copy(
                    update={
                        "id": "evidence:camera-b",
                        "media_id": "camera-b",
                        "media_sha256": second_sha,
                    }
                )
            ],
        },
        deep=True,
    )
    index = editorial_index.model_copy(
        update={
            "shots": [*editorial_index.shots, second_shot],
            "media_hashes": {**editorial_index.media_hashes, "camera-b": second_sha},
        },
        deep=True,
    )
    dialogue_brief = EditorialBrief(
        id="multicam-dialogue",
        objective=editorial_brief.objective,
        profile="dialogue",
    )
    story = build_story_map(dialogue_brief, index)
    pools = generate_selects(story, index, PolicyRegistry().get("dialogue"))
    unsynchronized = apply_multicam_preferences(story, pools, index)
    assert all(item.media_id != "camera-b" for values in unsynchronized.values() for item in values)
    sync = SourceSynchronization(
        reference_media_id="media-a",
        target_media_id="camera-b",
        target_offset=RationalTime.zero(),
        correlation=0.9,
        confidence=Confidence(
            score=0.9,
            basis=EvidenceKind.MEASURED,
            calibration="fixture-sync",
        ),
        evidence=[editorial_index.evidence.refs[0], second_shot.evidence[0]],
    )
    synchronized_index = index.model_copy(update={"synchronizations": [sync]}, deep=True)
    synchronized = apply_multicam_preferences(story, pools, synchronized_index)
    assert any(item.media_id == "camera-b" for values in synchronized.values() for item in values)
    speakers = [
        SpeakerSegment(
            id="speaker-segment",
            speaker_id="speaker-1",
            source_range=editorial_index.shots[1].source_range,
            confidence=sync.confidence,
        )
    ]
    assert plan_multicam(speakers, synchronized_index.shots, [sync])
