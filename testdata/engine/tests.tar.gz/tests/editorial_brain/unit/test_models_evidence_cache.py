from pathlib import Path

import pytest
from pydantic import ValidationError

from editorial_brain.core.hashing import fingerprint
from editorial_brain.core.models import Confidence, EditorialBrief, EvidenceKind, EvidenceRef
from editorial_brain.storage.cache import BrainCache, CacheIdentity


def test_models_are_strict_and_versioned() -> None:
    with pytest.raises(ValidationError):
        EditorialBrief.model_validate({"id": "brief", "objective": "edit", "unexpected": True})
    brief = EditorialBrief(id="brief", objective="edit")
    assert brief.schema_version == "1.0.0"


def test_model_inference_requires_provider_evidence() -> None:
    with pytest.raises(ValidationError, match="provider evidence"):
        EvidenceRef(
            id="evidence",
            kind=EvidenceKind.MODEL_INFERRED,
            media_id="media",
            analysis_version="v1",
            confidence=Confidence(
                score=0.4,
                basis=EvidenceKind.MODEL_INFERRED,
                calibration="fixture",
            ),
        )


def test_cache_key_covers_provider_prompt_and_parameters(tmp_path: Path) -> None:
    base = dict(
        namespace="semantic",
        source_hashes={"media": "a" * 64},
        analysis_version="v1",
        provider="fixture",
        model="model-v1",
        provider_fingerprint="provider-fingerprint",
        prompt_fingerprint="prompt-v1",
    )
    first = CacheIdentity(**base, parameters={"temperature": 0})
    second = CacheIdentity(**base, parameters={"temperature": 1})
    assert first.key != second.key
    cache = BrainCache(tmp_path / "cache")
    brief = EditorialBrief(id="brief", objective="edit")
    cache.store(first, brief)
    assert cache.load(first, EditorialBrief) == brief
    assert cache.load(second, EditorialBrief) is None


def test_nested_models_hash_deterministically() -> None:
    brief = EditorialBrief(id="brief", objective="edit", seed=7)
    assert fingerprint({"brief": brief}) == fingerprint({"brief": brief.model_copy(deep=True)})


def test_corrupt_cache_entry_is_quarantined(tmp_path: Path) -> None:
    identity = CacheIdentity(
        namespace="semantic",
        source_hashes={"media": "a" * 64},
        analysis_version="v1",
        provider="fixture",
        model="model-v1",
        provider_fingerprint="provider-v1",
        prompt_fingerprint="prompt-v1",
    )
    cache = BrainCache(tmp_path / "cache")
    path = cache.store(identity, EditorialBrief(id="brief", objective="edit"))
    path.write_text("{corrupt", encoding="utf-8")
    assert cache.load(identity, EditorialBrief) is None
    assert not path.exists()
    assert len(list(cache.quarantine.glob("*.invalid"))) == 1
