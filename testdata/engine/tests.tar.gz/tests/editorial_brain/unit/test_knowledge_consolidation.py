from functools import lru_cache
from pathlib import Path

from editorial_brain.core.models import EditorialBrief, ReferenceEditProfile
from editorial_brain.knowledge.consolidator import consolidate_catalog
from editorial_brain.knowledge.loader import load_catalog
from editorial_brain.knowledge.taste import synthesize_taste_profile
from video_engine.api import RationalTime

REPO_ROOT = Path(__file__).resolve().parents[3]


@lru_cache(maxsize=1)
def _base():
    return consolidate_catalog(load_catalog(REPO_ROOT / "knowledge"))


def _reference(
    identifier: str,
    *,
    median_seconds: int,
    silence: float,
    graphics: float,
    music: float,
) -> ReferenceEditProfile:
    return ReferenceEditProfile(
        id=identifier,
        source_sha256=("a" if identifier.endswith("fast") else "b") * 64,
        shot_duration_quantiles={"p50": RationalTime(value=median_seconds, timescale=1)},
        cut_frequency_hz=1 / median_seconds,
        camera_motion_frequency=0.8 if identifier.endswith("fast") else 0.1,
        caption_density=graphics,
        graphic_density=graphics,
        sfx_event_density=graphics,
        silence_ratio=silence,
        music_sync_score=music,
        repetition_score=0.15,
    )


def test_consolidated_base_is_deduplicated_resolved_and_source_neutral() -> None:
    base = _base()
    checked = (REPO_ROOT / "knowledge/editorial_base/v1/index.json").read_text(encoding="utf-8")
    assert base.model_validate_json(checked).fingerprint == base.fingerprint
    assert base.statistics.input_items >= 380
    assert base.statistics.principle_reduction_ratio >= 0.7
    assert base.statistics.total_construct_reduction_ratio >= 0.45
    assert base.statistics.duplicate_statements_removed >= 400
    assert base.statistics.unresolved_conflicts == 0
    assert len(base.principles) == len(
        {principle.normalized_signature for principle in base.principles}
    )
    payload = base.model_dump(mode="json")
    serialized = base.model_dump_json().lower()
    assert not _contains_forbidden_key(payload)
    assert "youtube.com" not in serialized
    assert "youtu.be" not in serialized


def test_consolidation_and_taste_are_repeatable() -> None:
    catalog = load_catalog(REPO_ROOT / "knowledge")
    first = consolidate_catalog(catalog)
    second = consolidate_catalog(catalog)
    assert first.fingerprint == second.fingerprint
    assert first.model_dump(mode="json") == second.model_dump(mode="json")
    brief = EditorialBrief(
        id="repeatable",
        objective="Preserve natural reactions and visual proof with restrained presentation",
        seed=42,
    )
    assert synthesize_taste_profile(first, brief) == synthesize_taste_profile(second, brief)


def test_duplicate_support_does_not_vote_a_principle_up() -> None:
    base = _base()
    brief = EditorialBrief(id="no-popularity-vote", objective="clear story and visual proof")
    original = synthesize_taste_profile(base, brief)
    inflated = base.model_copy(
        update={
            "principles": [
                principle.model_copy(update={"support_count": principle.support_count * 100})
                for principle in base.principles
            ]
        }
    )
    changed = synthesize_taste_profile(inflated, brief)
    assert changed.axes == original.axes
    assert changed.selected == original.selected
    assert changed.fingerprint == original.fingerprint


def test_reference_grammar_creates_bounded_per_video_taste_not_a_copied_edit() -> None:
    base = _base()
    brief = EditorialBrief(
        id="reference-conditioned",
        objective="Create a clear product story",
        reference_influence=0.5,
    )
    fast = synthesize_taste_profile(
        base,
        brief,
        reference=_reference(
            "reference-fast", median_seconds=1, silence=0.02, graphics=0.8, music=0.9
        ),
    )
    patient = synthesize_taste_profile(
        base,
        brief,
        reference=_reference(
            "reference-patient", median_seconds=6, silence=0.3, graphics=0.05, music=0.2
        ),
    )
    assert fast.fingerprint != patient.fingerprint
    assert fast.axes["cut_energy"] > patient.axes["cut_energy"]
    assert fast.axes["presentation_restraint"] < patient.axes["presentation_restraint"]
    assert fast.axes["musicality"] > patient.axes["musicality"]
    assert fast.axes["breathing_room"] < patient.axes["breathing_room"]
    serialized = fast.model_dump_json().lower()
    assert "source_sha256" not in serialized
    assert "shot_duration_quantiles" not in serialized
    assert "source_range" not in serialized


def _contains_forbidden_key(value: object) -> bool:
    forbidden = {
        "creator",
        "creator_id",
        "source",
        "source_id",
        "source_ids",
        "source_path",
        "relative_path",
        "sha256",
        "url",
    }
    if isinstance(value, dict):
        return any(key in forbidden or _contains_forbidden_key(item) for key, item in value.items())
    if isinstance(value, list):
        return any(_contains_forbidden_key(item) for item in value)
    return False
