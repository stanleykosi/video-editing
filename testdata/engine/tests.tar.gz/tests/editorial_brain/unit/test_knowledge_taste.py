from pathlib import Path

from editorial_brain import EditorialBrain
from editorial_brain.benchmark.fixtures import synthetic_fixture
from editorial_brain.benchmark.scenarios import SCENARIOS
from editorial_brain.core.models import EditorialBrief, EditorialProfile, WorkflowModifier
from editorial_brain.knowledge.compiler import apply_directives
from editorial_brain.knowledge.consolidator import consolidate_catalog
from editorial_brain.knowledge.loader import load_catalog
from editorial_brain.knowledge.provider import RepositoryKnowledgeDirectiveProvider
from editorial_brain.knowledge.taste import (
    compile_taste_directives,
    synthesize_taste_profile,
)
from editorial_brain.policies.neutral import neutral_policy

REPO_ROOT = Path(__file__).resolve().parents[3]


def test_complete_repository_knowledge_catalog_is_strict_and_fingerprinted() -> None:
    catalog = load_catalog(REPO_ROOT / "knowledge")
    assert len(catalog.items) >= 380
    assert not catalog.rejected_files
    assert len(catalog.fingerprint) == 64
    assert {item.kind.value for item in catalog.items} == {
        "playbook",
        "lesson",
        "technique",
        "preset",
        "style",
        "qc_checklist",
    }


def test_emotional_documentary_synthesizes_human_hold_and_executable_priors() -> None:
    catalog = load_catalog(REPO_ROOT / "knowledge")
    base = consolidate_catalog(catalog)
    brief = EditorialBrief(
        id="documentary-hold",
        objective=(
            "Build a human documentary scene that preserves the silent emotional reaction "
            "and aftermath instead of cutting only for speed"
        ),
        profile=EditorialProfile.DIALOGUE,
        modifiers=[WorkflowModifier.DOCUMENTARY, WorkflowModifier.LONG_FORM],
        knowledge_max_items=60,
    )
    profile = synthesize_taste_profile(base, brief)
    directives = compile_taste_directives(base, profile)
    policy = apply_directives(neutral_policy(), directives)
    assert policy.cut.weights["reaction_preservation"] > 1
    assert policy.cut.weights["emotional_continuity"] > 1
    assert policy.selects.reaction_value > neutral_policy().selects.reaction_value
    assert policy.pacing.allow_intentional_long_holds
    assert policy.directive_ids
    assert policy.knowledge_fingerprint is not None
    assert profile.axes["reaction_patience"] > 0
    assert profile.axes["breathing_room"] > 0


def test_knowledge_provider_writes_source_neutral_taste_and_supports_opt_out(
    tmp_path: Path,
) -> None:
    provider = RepositoryKnowledgeDirectiveProvider(
        tmp_path, knowledge_root=REPO_ROOT / "knowledge"
    )
    enabled = EditorialBrief(
        id="enabled",
        objective="short-form product proof with a clear hook and visual evidence",
        modifiers=[WorkflowModifier.SHORT_FORM, WorkflowModifier.PRODUCT_VIDEO],
    )
    assert provider.directives(enabled)
    assert (tmp_path / ".editorial-brain/knowledge/taste-enabled.json").is_file()
    assert not (tmp_path / ".editorial-brain/knowledge/consolidated-base.json").exists()
    disabled = enabled.model_copy(update={"id": "disabled", "knowledge_mode": "off"})
    assert provider.directives(disabled) == []
    assert provider.last_profile is not None
    assert not provider.last_profile.selected


def test_taste_identity_survives_plan_and_engine_compilation(tmp_path: Path) -> None:
    project, brief, index, _expected = synthetic_fixture(tmp_path, SCENARIOS[0])
    brief = brief.model_copy(
        update={
            "objective": "Preserve natural human cadence, reactions, and emotional hold time",
            "knowledge_max_items": 50,
        }
    )
    provider = RepositoryKnowledgeDirectiveProvider(
        tmp_path, knowledge_root=REPO_ROOT / "knowledge"
    )
    brain = EditorialBrain(tmp_path, directive_provider=provider)
    plans = brain.plan(project=project, brief=brief, analysis=index, variants=2)
    plan = plans.best
    assert isinstance(plan.extensions["editorial_brain:taste_profile_id"], str)
    assert isinstance(plan.extensions["editorial_brain:taste_fingerprint"], str)
    assert isinstance(plan.extensions["editorial_brain:knowledge_base_fingerprint"], str)
    serialized = plan.model_dump_json()
    assert "relative_path" not in serialized
    assert "source_ids" not in serialized
    assert "youtube" not in serialized.lower()
    assert all(
        any(policy_id.startswith(("principle:", "taste:")) for policy_id in decision.policy_ids)
        for decision in plan.decisions
    )
    compiled = brain.compile(project=project, plan=plan)
    assert compiled.patch is not None
    assert compiled.validated_project is not None
