from editorial_brain.continuity.visual import continuity_score
from editorial_brain.planning.assembly import create_assemblies
from editorial_brain.policies.registry import PolicyRegistry
from editorial_brain.rhythm.pacing import PacingSample, build_pacing_curve
from editorial_brain.selects.generator import generate_selects
from editorial_brain.story.beats import build_story_map


def test_continuity_dimensions_and_motivated_discontinuity(editorial_index) -> None:
    regular = continuity_score(editorial_index.shots[0], editorial_index.shots[1])
    motivated = continuity_score(
        editorial_index.shots[0], editorial_index.shots[1], intent="smash_cut"
    )
    assert 0 <= regular.overall <= 1
    assert motivated.motivated_discontinuity
    assert motivated.overall >= 0.75


def test_pacing_detects_identical_fast_run() -> None:
    policy = PolicyRegistry().get("neutral").pacing
    samples = [
        PacingSample(
            segment_id=f"segment-{index}",
            duration=policy.minimum_shot_duration,
            motion_energy=0.9,
            information_density=0.9,
            audio_energy=0.8,
            emotional_intensity=0.5,
        )
        for index in range(6)
    ]
    curve = build_pacing_curve(samples, policy)
    assert "repeated_identical_shot_durations" in curve.warnings
    assert "excessive_visual_information_density" in curve.warnings


def test_beam_search_keeps_alternative_assemblies(
    editorial_project, editorial_brief, editorial_index
) -> None:
    policy = PolicyRegistry().get("neutral")
    story = build_story_map(editorial_brief, editorial_index)
    pools = generate_selects(story, editorial_index, policy)
    assemblies = create_assemblies(
        story,
        pools,
        editorial_index.shots,
        editorial_brief,
        policy,
        variants=2,
    )
    assert len(assemblies) == 2
    assert assemblies[0].score.overall >= assemblies[1].score.overall
    assert assemblies[0].segments[0].select_id != assemblies[1].segments[0].select_id
