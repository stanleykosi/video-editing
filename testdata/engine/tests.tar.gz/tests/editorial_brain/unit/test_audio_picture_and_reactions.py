from editorial_brain.continuity.visual import continuity_score
from editorial_brain.core.models import AudioPictureRelationship
from editorial_brain.cuts.jcut import plan_jcut
from editorial_brain.cuts.lcut import plan_lcut
from editorial_brain.cuts.reaction import reaction_cut_rejection
from video_engine.api import RationalTime


def test_reaction_window_can_explicitly_reject_cut(editorial_index) -> None:
    shot = editorial_index.shots[1]
    assert reaction_cut_rejection(shot, RationalTime(value=11, timescale=2))


def test_j_and_l_cut_planners_are_motivated(editorial_index) -> None:
    continuity = continuity_score(editorial_index.shots[0], editorial_index.shots[1])
    handle = RationalTime(value=1, timescale=2)
    relation, extension = plan_jcut(
        continuity,
        incoming_dialogue=True,
        available_handle=handle,
    )
    assert relation in {AudioPictureRelationship.J_CUT, AudioPictureRelationship.HARD_AV}
    assert extension <= handle
    reaction_relation, reaction_extension = plan_lcut(
        continuity,
        outgoing_dialogue=True,
        incoming_reaction=True,
        available_handle=handle,
    )
    assert reaction_relation is AudioPictureRelationship.REACTION_CONTINUING_DIALOGUE
    assert reaction_extension > RationalTime.zero()
