from editorial_brain.analysis.speech import cuts_inside_words
from editorial_brain.core.models import EditorialBrief, EditorialProfile, PauseClass, PauseEvent
from editorial_brain.cuts.boundaries import boundary_rejections
from editorial_brain.cuts.candidates import generate_cut_points
from editorial_brain.cuts.dialogue import removable_pause
from editorial_brain.policies.registry import PolicyRegistry
from editorial_brain.selects.generator import generate_selects
from editorial_brain.story.beats import build_story_map
from video_engine.api import RationalTime, TimeRange


def test_story_selects_preserve_alternatives(editorial_brief, editorial_index) -> None:
    story = build_story_map(editorial_brief, editorial_index)
    pools = generate_selects(story, editorial_index, PolicyRegistry().get("neutral"))
    candidates = pools[story.beats[0].id]
    assert len(candidates) == 2
    assert candidates[0].alternative_ids == [candidates[1].id]
    assert any(candidates[0].source_range == shot.source_range for shot in editorial_index.shots)
    assert candidates[0].inner_usable_range == candidates[0].source_range


def test_cut_points_are_structural_and_never_inside_words(editorial_index) -> None:
    points = generate_cut_points(editorial_index)
    assert {point.kind for point in points} >= {"word", "phrase", "shot", "source_handle"}
    transcript = editorial_index.transcripts[0]
    assert not cuts_inside_words(transcript, [point.time for point in points])
    middle = RationalTime(value=1, timescale=2)
    assert "inside_spoken_word" in boundary_rejections(
        media_range=editorial_index.shots[0].source_range,
        cut_time=middle,
        transcript=transcript,
    )


def test_pause_removal_is_context_and_confidence_gated(editorial_index) -> None:
    protected = PauseEvent(
        id="pause-protected",
        media_id="media-a",
        source_range=editorial_index.shots[0].source_range,
        classification=PauseClass.DEAD_SPACE,
        protected=True,
        confidence=editorial_index.shots[0].quality.confidence,
    )
    assert not removable_pause(protected, aggressive=True)
    assert not removable_pause(
        protected.model_copy(
            update={
                "protected": False,
                "confidence": protected.confidence.model_copy(update={"score": 0.4}),
            }
        )
    )
    assert removable_pause(protected.model_copy(update={"protected": False}))


def test_source_led_story_omits_dead_air_and_preserves_protected_pause(
    editorial_index,
) -> None:
    pause_range = TimeRange(
        start=RationalTime(value=4, timescale=1),
        duration=RationalTime(value=1, timescale=1),
    )
    pause_evidence = (
        editorial_index.shots[1]
        .evidence[0]
        .model_copy(
            update={
                "id": "evidence:protected-pause",
                "source_range": pause_range,
                "shot_id": None,
            }
        )
    )
    protected = PauseEvent(
        id="pause-reaction",
        media_id="media-a",
        source_range=pause_range,
        classification=PauseClass.REACTION_HOLD,
        protected=True,
        evidence=[pause_evidence],
        confidence=editorial_index.shots[1].quality.confidence,
    )
    dead = protected.model_copy(
        update={
            "id": "pause-dead",
            "classification": PauseClass.DEAD_SPACE,
            "protected": False,
        },
        deep=True,
    )
    index = editorial_index.model_copy(
        update={
            "pauses": [protected, dead],
            "evidence": editorial_index.evidence.model_copy(
                update={"refs": [*editorial_index.evidence.refs, pause_evidence]}
            ),
        },
        deep=True,
    )
    brief = EditorialBrief(
        id="source-dialogue",
        objective="tighten dialogue but preserve the reaction hold",
        profile=EditorialProfile.DIALOGUE,
    )
    story = build_story_map(brief, index)
    assert [beat.function.value for beat in story.beats] == ["evidence", "reaction"]
    pools = generate_selects(story, index, PolicyRegistry().get("dialogue"))
    reaction_selects = pools[story.beats[1].id]
    assert reaction_selects[0].inner_usable_range == pause_range
