from pathlib import Path

import pytest

from editorial_brain import EditorialBrain
from editorial_brain.core.models import (
    Confidence,
    EditorialBrief,
    EvidenceKind,
    EvidenceRef,
    Transcript,
    TranscriptPhrase,
    TranscriptWord,
)
from video_engine.api import MediaReference, RationalTime, TimeRange


def test_plan_compiles_and_applies_transactionally(
    tmp_path: Path, editorial_project, editorial_brief, editorial_index
) -> None:
    brain = EditorialBrain(tmp_path)
    plans = brain.plan(
        project=editorial_project,
        brief=editorial_brief,
        analysis=editorial_index,
        variants=2,
    )
    compiled = brain.compile(project=editorial_project, plan=plans.best)
    assert compiled.patch is not None
    assert compiled.patch.expected_project_revision == editorial_project.revision
    assert compiled.validated_project.revision == editorial_project.revision + 1
    assert any(
        track.extensions.get("editorial_brain:plan_id")
        for track in compiled.validated_project.sequence(
            editorial_project.active_sequence_id
        ).timeline.tracks
    )


def test_revision_conflict_fails_before_mutation(
    tmp_path: Path, editorial_project, editorial_brief, editorial_index
) -> None:
    brain = EditorialBrain(tmp_path)
    plan = brain.plan(
        project=editorial_project,
        brief=editorial_brief,
        analysis=editorial_index,
        variants=1,
    ).best
    revised = editorial_project.model_copy(update={"revision": editorial_project.revision + 1})
    with pytest.raises(ValueError, match="revision conflict"):
        brain.compile(project=revised, plan=plan)


def test_multi_beat_plan_retains_scored_cut_alternatives(
    tmp_path: Path, editorial_project, editorial_index
) -> None:
    brief = EditorialBrief(
        id="brief-two-beats",
        objective="show claim then proof",
        script_text="This product proves value. Product proof matters.",
    )
    plan = (
        EditorialBrain(tmp_path)
        .plan(
            project=editorial_project,
            brief=brief,
            analysis=editorial_index,
            variants=2,
        )
        .best
    )
    assert plan.assembly.cut_ids
    assert plan.cut_candidates
    assert all(
        cut_id in {item.id for item in plan.cut_candidates} for cut_id in plan.assembly.cut_ids
    )
    assert any(decision.kind == "cut" for decision in plan.decisions)


def test_separate_voice_over_compiles_as_dedicated_audio_source(
    tmp_path: Path, editorial_project, editorial_index
) -> None:
    narration_sha = "c" * 64
    narration_media = MediaReference.model_validate(
        {
            "id": "narration-media",
            "uri": str(tmp_path / "voice-over.wav"),
            "sha256": narration_sha,
            "available_range": {
                "start": {"value": 0, "timescale": 1},
                "duration": {"value": 4, "timescale": 1},
            },
            "streams": [
                {
                    "index": 0,
                    "codec_type": "audio",
                    "codec_name": "pcm_s16le",
                    "sample_rate": 48_000,
                    "channels": 1,
                }
            ],
        }
    )
    project = editorial_project.model_copy(
        update={"media": [*editorial_project.media, narration_media]}, deep=True
    )
    confidence = Confidence(
        score=0.98,
        basis=EvidenceKind.OBSERVED,
        calibration="narration_fixture",
    )
    words = [
        TranscriptWord(
            id=f"narration-word-{position}",
            text=text,
            punctuated_text=text,
            source_range=TimeRange(
                start=RationalTime(value=position, timescale=1),
                duration=RationalTime(value=1, timescale=1),
            ),
            confidence=confidence,
        )
        for position, text in enumerate(["This", "product", "proves", "value"])
    ]
    narration = Transcript(
        id="narration-transcript",
        media_id="narration-media",
        media_sha256=narration_sha,
        language="en",
        words=words,
        phrases=[
            TranscriptPhrase(
                id="narration-phrase",
                text="This product proves value.",
                source_range=TimeRange.from_start_end(
                    words[0].source_range.start, words[-1].source_range.end
                ),
                word_ids=[item.id for item in words],
                confidence=confidence,
            )
        ],
    )
    narration_evidence = [
        EvidenceRef(
            id=f"evidence:{word.id}",
            kind=EvidenceKind.USER_SUPPLIED,
            media_id="narration-media",
            media_sha256=narration_sha,
            source_range=word.source_range,
            transcript_id="narration-transcript",
            transcript_word_id=word.id,
            analysis_version="narration-fixture-v1",
            confidence=confidence,
            summary="user-supplied narration word timing",
        )
        for word in words
    ]
    narration_evidence.append(
        EvidenceRef(
            id="evidence:narration-phrase",
            kind=EvidenceKind.USER_SUPPLIED,
            media_id="narration-media",
            media_sha256=narration_sha,
            source_range=narration.phrases[0].source_range,
            transcript_id="narration-transcript",
            transcript_phrase_id="narration-phrase",
            analysis_version="narration-fixture-v1",
            confidence=confidence,
            summary="user-supplied narration phrase timing",
        )
    )
    index = editorial_index.model_copy(
        update={
            "project_id": project.id,
            "media_hashes": {
                **editorial_index.media_hashes,
                "narration-media": narration_sha,
            },
            "transcripts": [*editorial_index.transcripts, narration],
            "evidence": editorial_index.evidence.model_copy(
                update={"refs": [*editorial_index.evidence.refs, *narration_evidence]}
            ),
        },
        deep=True,
    )
    brief = EditorialBrief(
        id="narration-brief",
        objective="align product proof to supplied narration",
        script_text="This product proves value.",
        narration_media_id="narration-media",
        narration_transcript_id="narration-transcript",
    )
    brain = EditorialBrain(tmp_path)
    plan = brain.plan(project=project, brief=brief, analysis=index, variants=1).best
    compiled = brain.compile(project=project, plan=plan)
    timeline = compiled.validated_project.sequence().timeline
    audio_items = [
        item for track in timeline.tracks for item in track.items if track.track_type == "audio"
    ]
    video_items = [
        item for track in timeline.tracks for item in track.items if track.track_type == "video"
    ]
    assert any(item.media_reference_id == "narration-media" for item in audio_items)
    assert all(item.source_audio_enabled is False for item in video_items)
    assert all(
        segment.audio_relationship.value == "broll_continuing_dialogue"
        for segment in plan.assembly.segments
    )
