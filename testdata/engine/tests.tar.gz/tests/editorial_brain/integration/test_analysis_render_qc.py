from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from editorial_brain import EditorialBrain
from editorial_brain.core.models import EditorialBrief
from video_engine.api import QCRequest, RenderRequest, VideoEngine


@pytest.mark.integration
@pytest.mark.golden
def test_brain_analysis_plan_patch_render_and_qc(tmp_path: Path) -> None:
    source = tmp_path / "source.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "testsrc2=size=320x180:rate=24:duration=2",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:sample_rate=48000:duration=2",
            "-map",
            "0:v:0",
            "-map",
            "1:a:0",
            "-c:v",
            "libx264",
            "-preset",
            "ultrafast",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-shortest",
            str(source),
        ],
        check=True,
    )
    engine = VideoEngine(tmp_path)
    project = engine.create_project("Brain render integration", width=320, height=180)
    record = engine.media().import_media(source)
    project = project.model_copy(
        update={"media": [engine.media().to_media_reference(record)]}, deep=True
    )
    brain = EditorialBrain(tmp_path)
    brief = EditorialBrief(
        id="render-brief",
        objective="show the measured source clearly",
        script_text="Show the source clearly.",
    )

    analysis = brain.analyze(project=project, brief=brief)
    assert analysis.index.shots
    assert analysis.index.shot_boundaries
    reference = brain.analyze_reference(source)
    assert reference.profile.shot_duration_quantiles
    plan = brain.plan(
        project=project,
        brief=brief,
        analysis=analysis,
        variants=2,
        reference=reference,
    ).best
    assert plan.reference_profile_id == reference.profile.id
    assert "reference:" in plan.policy_id
    compiled = brain.compile(project=project, plan=plan)
    assert compiled.patch is not None
    output = tmp_path / "brain-preview.mp4"
    render = engine.renderer(compiled.validated_project).render(
        RenderRequest(output_path=output, sectioning=False, use_cache=False)
    )
    assert output.is_file()
    assert render.output_path == output
    qc = engine.qc(compiled.validated_project).run(
        QCRequest(output_path=output, report_dir=tmp_path / "qc")
    )
    assert qc.report.status.value in {"passed", "passed_with_warnings"}
    assert qc.report.output_sha256 is not None
