from pathlib import Path

from editorial_brain import EditorialBrain
from editorial_brain.cli.main import build_parser, main
from editorial_brain.core.models import EditorialBrief
from video_engine.api import Project


def test_every_cli_command_accepts_json() -> None:
    parser = build_parser()
    commands = {
        "doctor": ["doctor", "--json"],
        "knowledge": ["knowledge", "--brief", "brief.yaml", "--json"],
        "knowledge-build": ["knowledge-build", "--json"],
        "analyze-reference": ["analyze-reference", "reference.mp4", "--json"],
        "analyze": ["analyze", "project.json", "--brief", "brief.yaml", "--json"],
        "story": ["story", "project.json", "--brief", "brief.yaml", "--json"],
        "selects": ["selects", "project.json", "--brief", "brief.yaml", "--json"],
        "plan": ["plan", "project.json", "--brief", "brief.yaml", "--json"],
        "variants": ["variants", "project.json", "--brief", "brief.yaml", "--json"],
        "compile": ["compile", "project.json", "plan.json", "--json"],
        "apply": ["apply", "project.json", "plan.json", "--json"],
        "explain": ["explain", "plan.json", "--json"],
        "benchmark": ["benchmark", "--json"],
    }
    for command, arguments in commands.items():
        parsed = parser.parse_args(arguments)
        assert parsed.command == command
        assert parsed.as_json is True


def test_cli_compile_and_apply_use_revision_checked_patch(
    tmp_path: Path, editorial_project: Project, editorial_index
) -> None:
    brain = EditorialBrain(tmp_path)
    brief = EditorialBrief(
        id="cli-brief",
        objective="show product proof",
        script_text="Show product proof.",
    )
    plan = brain.plan(
        project=editorial_project,
        brief=brief,
        analysis=editorial_index,
        variants=1,
    ).best
    project_path = tmp_path / "project.json"
    plan_path = tmp_path / "plan.json"
    project_path.write_text(editorial_project.model_dump_json(indent=2), encoding="utf-8")
    plan_path.write_text(plan.model_dump_json(indent=2), encoding="utf-8")

    assert main(["compile", str(project_path), str(plan_path), "--json"]) == 0
    assert main(["apply", str(project_path), str(plan_path), "--json"]) == 0
    applied = Project.model_validate_json(project_path.read_text(encoding="utf-8"))
    assert applied.revision == editorial_project.revision + 1
