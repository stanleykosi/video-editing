from __future__ import annotations

from pathlib import Path

import pytest

from editorial_brain.core.models import (
    CameraDescriptor,
    Confidence,
    EditorialBrief,
    EvidenceBundle,
    EvidenceKind,
    EvidenceRef,
    MediaUnderstandingIndex,
    Shot,
    ShotBoundary,
    ShotQuality,
    ShotSemantics,
    Transcript,
    TranscriptPhrase,
    TranscriptWord,
    VisibleReaction,
)
from video_engine.api import MediaReference, Project, RationalTime, TimeRange, VideoEngine

MEDIA_SHA = "a" * 64


def rt(value: int, timescale: int = 1) -> RationalTime:
    return RationalTime(value=value, timescale=timescale)


def tr(start: int, duration: int, timescale: int = 1) -> TimeRange:
    return TimeRange(start=rt(start, timescale), duration=rt(duration, timescale))


def confidence(score: float = 1, basis: EvidenceKind = EvidenceKind.MEASURED) -> Confidence:
    return Confidence(score=score, basis=basis, calibration="test_fixture")


def evidence(
    identifier: str, source_range: TimeRange, *, shot_id: str | None = None
) -> EvidenceRef:
    return EvidenceRef(
        id=f"evidence:{identifier}",
        kind=EvidenceKind.MEASURED,
        media_id="media-a",
        media_sha256=MEDIA_SHA,
        source_range=source_range,
        shot_id=shot_id,
        analysis_version="test-v1",
        confidence=confidence(),
        summary="deterministic fixture evidence",
    )


@pytest.fixture
def editorial_project(tmp_path: Path) -> Project:
    project = (
        VideoEngine(tmp_path)
        .create_project("Editorial fixture")
        .model_copy(update={"id": "project-editorial-fixture"})
    )
    media = MediaReference.model_validate(
        {
            "id": "media-a",
            "uri": str(tmp_path / "source.mp4"),
            "sha256": MEDIA_SHA,
            "available_range": tr(0, 8).model_dump(mode="json"),
            "streams": [
                {"index": 0, "codec_type": "video", "codec_name": "h264"},
                {
                    "index": 1,
                    "codec_type": "audio",
                    "codec_name": "aac",
                    "sample_rate": 48_000,
                    "channels": 2,
                },
            ],
        }
    )
    return project.model_copy(update={"media": [media]}, deep=True)


@pytest.fixture
def editorial_index(editorial_project: Project) -> MediaUnderstandingIndex:
    ranges = [tr(0, 4), tr(4, 4)]
    refs = [
        evidence(f"shot-{position}", value, shot_id=f"shot-{position}")
        for position, value in enumerate(ranges)
    ]
    shots = [
        Shot(
            id=f"shot-{position}",
            media_id="media-a",
            media_sha256=MEDIA_SHA,
            source_range=value,
            inner_usable_range=value,
            reactions=(
                [
                    VisibleReaction(
                        id="reaction-meaningful",
                        cue="long_silent_reaction",
                        source_range=tr(5, 1),
                        salience=0.9,
                        confidence=confidence(0.9, EvidenceKind.OBSERVED),
                    )
                ]
                if position == 1
                else []
            ),
            camera=CameraDescriptor(
                shot_scale="medium" if position == 0 else "close",
                motion="locked",
                screen_direction="left_to_right",
                confidence=confidence(),
            ),
            quality=ShotQuality(
                sharpness=0.9 - position * 0.1,
                exposure=0.9,
                stability=0.9,
                composition=0.85,
                confidence=confidence(),
            ),
            semantics=ShotSemantics(
                summary=(
                    "speaker explains the product benefit"
                    if position == 0
                    else "close product proof and meaningful reaction"
                ),
                search_terms=(
                    ["speaker", "product", "benefit"]
                    if position == 0
                    else ["product", "proof", "reaction", "detail"]
                ),
                reaction_value=0.9 if position == 1 else 0.1,
                evidence_value=0.9 if position == 1 else 0.5,
                cutaway_value=0.8 if position == 1 else 0.2,
                confidence=confidence(0.9, EvidenceKind.OBSERVED),
            ),
            motion_energy=0.1 + position * 0.2,
            evidence=[refs[position]],
        )
        for position, value in enumerate(ranges)
    ]
    words = [
        TranscriptWord(
            id=f"word-{position}",
            text=text,
            punctuated_text=text,
            source_range=tr(position, 1),
            speaker_id="speaker-1",
            confidence=confidence(0.98, EvidenceKind.OBSERVED),
        )
        for position, text in enumerate(["This", "product", "proves", "value"])
    ]
    phrase = TranscriptPhrase(
        id="phrase-0",
        text="This product proves value.",
        source_range=tr(0, 4),
        word_ids=[word.id for word in words],
        speaker_id="speaker-1",
        kind="claim",
        emphasis=0.9,
        named_visual_references=["product"],
        confidence=confidence(0.95, EvidenceKind.OBSERVED),
    )
    refs.extend(
        EvidenceRef(
            id=f"evidence:{word.id}",
            kind=EvidenceKind.OBSERVED,
            media_id="media-a",
            media_sha256=MEDIA_SHA,
            source_range=word.source_range,
            transcript_id="transcript-a",
            transcript_word_id=word.id,
            analysis_version="test-v1",
            confidence=word.confidence,
            summary="fixture transcript word",
        )
        for word in words
    )
    refs.append(
        EvidenceRef(
            id="evidence:phrase-0",
            kind=EvidenceKind.OBSERVED,
            media_id="media-a",
            media_sha256=MEDIA_SHA,
            source_range=phrase.source_range,
            transcript_id="transcript-a",
            transcript_phrase_id=phrase.id,
            analysis_version="test-v1",
            confidence=phrase.confidence,
            summary="fixture transcript phrase",
        )
    )
    boundaries = [
        ShotBoundary(
            id=f"boundary-{position}",
            media_id="media-a",
            time=value.start,
            kind="source_start" if position == 0 else "hard_cut",
            strength=1,
            evidence=[refs[position]],
        )
        for position, value in enumerate(ranges)
    ]
    boundaries.append(
        ShotBoundary(
            id="boundary-end",
            media_id="media-a",
            time=tr(0, 8).end,
            kind="source_end",
            strength=1,
            evidence=[refs[-1]],
        )
    )
    return MediaUnderstandingIndex(
        project_id=editorial_project.id,
        analysis_version="test-v1",
        media_hashes={"media-a": MEDIA_SHA},
        shots=shots,
        shot_boundaries=boundaries,
        transcripts=[
            Transcript(
                id="transcript-a",
                media_id="media-a",
                media_sha256=MEDIA_SHA,
                language="en",
                words=words,
                phrases=[phrase],
            )
        ],
        evidence=EvidenceBundle(refs=refs),
    )


@pytest.fixture
def editorial_brief() -> EditorialBrief:
    return EditorialBrief(
        id="brief-fixture",
        objective="Show the product benefit and visible proof clearly",
        script_text="This product proves value.",
    )
