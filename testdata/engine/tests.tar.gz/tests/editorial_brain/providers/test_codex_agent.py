from __future__ import annotations

import json
from pathlib import Path

from editorial_brain.core.hashing import file_sha256
from editorial_brain.providers.base import (
    CandidateInput,
    FrameInput,
    ProviderStatus,
    RetryPolicy,
    SemanticRequest,
    VisionRequest,
)
from editorial_brain.providers.codex_agent import CodexAgentProvider
from video_engine.process import CommandResult


class _FixtureRunner:
    def __init__(self, judgments: list[dict[str, object]]) -> None:
        self.judgments = judgments
        self.calls: list[tuple[tuple[str, ...], str | None]] = []

    def run(self, command: list[str], **kwargs: object) -> CommandResult:
        normalized = tuple(str(item) for item in command)
        self.calls.append((normalized, kwargs.get("input_text")))  # type: ignore[arg-type]
        output = Path(normalized[normalized.index("--output-last-message") + 1])
        output.write_text(json.dumps({"judgments": self.judgments}), encoding="utf-8")
        return CommandResult(
            command=normalized,
            return_code=0,
            stdout=json.dumps({"type": "thread.started", "thread_id": "agent-request"}),
            stderr="",
            duration_seconds=0.01,
        )


def _semantic_request() -> SemanticRequest:
    return SemanticRequest(
        request_id="semantic",
        task="compare",
        instruction="prefer a complete thought",
        retry=RetryPolicy(attempts=1),
        candidates=[CandidateInput(candidate_id="known", summary="verified candidate")],
    )


def _provider(monkeypatch, tmp_path: Path, judgments: list[dict[str, object]]):
    monkeypatch.setattr(
        "editorial_brain.providers.codex_agent.shutil.which", lambda _: "/bin/codex"
    )
    auth_home = tmp_path / "codex-home"
    auth_home.mkdir()
    (auth_home / "auth.json").write_text("{}", encoding="utf-8")
    monkeypatch.setenv("CODEX_HOME", str(auth_home))
    provider = CodexAgentProvider(tmp_path)
    runner = _FixtureRunner(judgments)
    provider._runner = runner  # type: ignore[assignment]
    return provider, runner


def test_codex_agent_uses_stdin_read_only_schema_and_verified_ids(
    monkeypatch, tmp_path: Path
) -> None:
    provider, runner = _provider(
        monkeypatch,
        tmp_path,
        [
            {
                "candidate_id": "known",
                "score": 0.9,
                "labels": ["complete"],
                "reasons": ["thought completes"],
                "confidence": 0.8,
            }
        ],
    )
    result = provider.judge(_semantic_request())
    assert result.status is ProviderStatus.SUCCESS
    command, prompt = runner.calls[0]
    assert command[command.index("--sandbox") + 1] == "read-only"
    assert "--ephemeral" in command and command[-1] == "-"
    assert prompt is not None and "known" in prompt
    assert result.evidence is not None and result.evidence.request_id == "agent-request"


def test_codex_agent_rejects_invented_candidate(monkeypatch, tmp_path: Path) -> None:
    provider, _ = _provider(
        monkeypatch,
        tmp_path,
        [
            {
                "candidate_id": "invented",
                "score": 1.0,
                "labels": [],
                "reasons": [],
                "confidence": 1.0,
            }
        ],
    )
    result = provider.judge(_semantic_request())
    assert result.status is ProviderStatus.FAILED
    assert result.error_code == "agent_execution_failed"


def test_codex_agent_rejects_fields_outside_strict_schema(monkeypatch, tmp_path: Path) -> None:
    provider, _ = _provider(
        monkeypatch,
        tmp_path,
        [
            {
                "candidate_id": "known",
                "score": 0.5,
                "labels": [],
                "reasons": [],
                "confidence": 0.5,
                "timestamp": 12.5,
            }
        ],
    )
    result = provider.judge(_semantic_request())
    assert result.status is ProviderStatus.FAILED


def test_codex_agent_vision_preserves_frame_order_and_hash(monkeypatch, tmp_path: Path) -> None:
    frame = tmp_path / "frame.jpg"
    frame.write_bytes(b"fixture-frame")
    provider, runner = _provider(
        monkeypatch,
        tmp_path,
        [
            {
                "candidate_id": "frame-1",
                "score": 0.7,
                "labels": ["detail"],
                "reasons": ["clear detail"],
                "confidence": 0.75,
            }
        ],
    )
    result = provider.inspect(
        VisionRequest(
            request_id="vision",
            task="inspect",
            instruction="observable cues only",
            retry=RetryPolicy(attempts=1),
            frames=[
                FrameInput(
                    candidate_id="frame-1",
                    path=frame.resolve(),
                    sha256=file_sha256(frame),
                )
            ],
        )
    )
    assert result.status is ProviderStatus.SUCCESS
    command, _ = runner.calls[0]
    assert command[command.index("--image") + 1] == str(frame.resolve())


def test_codex_agent_is_clearly_unavailable_without_cli(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr("editorial_brain.providers.codex_agent.shutil.which", lambda _: None)
    result = CodexAgentProvider(tmp_path).judge(_semantic_request())
    assert result.status is ProviderStatus.UNAVAILABLE
    assert result.error_code == "agent_runtime_unavailable"
