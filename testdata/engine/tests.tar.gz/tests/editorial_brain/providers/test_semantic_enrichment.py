from pathlib import Path

from editorial_brain.core.models import ShotFrame
from editorial_brain.providers.deterministic import (
    DeterministicSemanticProvider,
    DeterministicVisionProvider,
)
from editorial_brain.understanding.shot_semantics import enrich_shot_semantics
from editorial_brain.understanding.speech_semantics import enrich_speech_semantics


def test_deterministic_semantics_enrich_verified_shot_and_phrase_candidates(
    tmp_path: Path, editorial_index
) -> None:
    frame_path = tmp_path / "frame.jpg"
    frame_path.write_bytes(b"fixture")
    frame_sha = "e" * 64
    shot = editorial_index.shots[0].model_copy(
        update={
            "frames": [
                ShotFrame(
                    id="frame-verified",
                    media_id="media-a",
                    time=editorial_index.shots[0].source_range.start,
                    artifact_path=str(frame_path),
                    sha256=frame_sha,
                    role="representative",
                )
            ]
        },
        deep=True,
    )
    index = editorial_index.model_copy(
        update={"shots": [shot, *editorial_index.shots[1:]]}, deep=True
    )
    visual = enrich_shot_semantics(
        index,
        DeterministicVisionProvider(
            {
                frame_sha: [
                    "subject:product",
                    "action:opens",
                    "gesture",
                    "detail",
                    "locked",
                ]
            }
        ),
        instruction="product proof detail gesture",
    )
    assert visual.shots[0].subjects[0].label == "product"
    assert visual.shots[0].actions[0].label == "opens"
    assert visual.shots[0].reactions[0].cue == "gesture"
    assert visual.shots[0].camera.shot_scale == "detail"
    speech = enrich_speech_semantics(visual, DeterministicSemanticProvider())
    assert speech.provider_evidence
    assert speech.transcripts[0].phrases[0].emphasis >= 0
