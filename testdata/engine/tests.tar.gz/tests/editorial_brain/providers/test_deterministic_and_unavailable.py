import json
from pathlib import Path

import httpx

from editorial_brain import EditorialBrain
from editorial_brain.core.hashing import file_sha256
from editorial_brain.providers.base import (
    CandidateInput,
    FrameInput,
    ProviderStatus,
    RetryPolicy,
    SemanticRequest,
    TranscriptionRequest,
    VisionRequest,
)
from editorial_brain.providers.codex_agent import CodexAgentProvider
from editorial_brain.providers.deepgram import DeepgramTranscriptionProvider
from editorial_brain.providers.deterministic import DeterministicSemanticProvider
from editorial_brain.providers.openai_provider import OpenAIProvider


def test_deterministic_semantic_provider_is_repeatable() -> None:
    provider = DeterministicSemanticProvider()
    request = SemanticRequest(
        request_id="request",
        task="product proof",
        instruction="rank product proof",
        candidates=[CandidateInput(candidate_id="candidate", summary="clear product proof")],
    )
    assert provider.judge(request) == provider.judge(request)


def test_deepgram_missing_key_is_explicit(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.delenv("DEEPGRAM_API_KEY", raising=False)
    result = DeepgramTranscriptionProvider().transcribe(
        TranscriptionRequest(
            request_id="request",
            media_id="media",
            media_sha256="a" * 64,
            source_path=(tmp_path / "missing.wav").resolve(),
        )
    )
    assert result.status is ProviderStatus.UNAVAILABLE
    assert result.error_code == "missing_api_key"


def test_cloud_providers_resolve_project_env_without_mutating_process_env(
    monkeypatch, tmp_path: Path
) -> None:
    monkeypatch.delenv("DEEPGRAM_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    env_file = tmp_path / ".env"
    env_file.write_text(
        "DEEPGRAM_API_KEY=deepgram-project-key\nOPENAI_API_KEY=openai-project-key\n",
        encoding="utf-8",
    )
    deepgram = DeepgramTranscriptionProvider(env_file=env_file)
    openai = OpenAIProvider(env_file=env_file)
    assert deepgram.credential_configured
    assert deepgram.credential_source == "project_env_file"
    assert openai.credential_configured
    assert openai.credential_source == "project_env_file"


def test_environment_factory_prefers_openai_then_authenticated_codex(
    monkeypatch, tmp_path: Path
) -> None:
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    env_file = tmp_path / ".env"
    env_file.write_text("DEEPGRAM_API_KEY=deepgram-project-key\n", encoding="utf-8")
    auth_home = tmp_path / "codex-home"
    auth_home.mkdir()
    (auth_home / "auth.json").write_text("{}", encoding="utf-8")
    monkeypatch.setenv("CODEX_HOME", str(auth_home))
    monkeypatch.setattr("editorial_brain.providers.codex_agent.shutil.which", lambda _: "/codex")
    brain = EditorialBrain.from_environment(tmp_path, env_file=env_file)
    assert isinstance(brain.semantic_provider, CodexAgentProvider)
    assert isinstance(brain.vision_provider, CodexAgentProvider)

    env_file.write_text(
        "DEEPGRAM_API_KEY=deepgram-project-key\nOPENAI_API_KEY=openai-project-key\n",
        encoding="utf-8",
    )
    openai_brain = EditorialBrain.from_environment(tmp_path, env_file=env_file)
    assert isinstance(openai_brain.semantic_provider, OpenAIProvider)
    assert openai_brain.semantic_provider is openai_brain.vision_provider


class _Response:
    def __init__(self, payload: dict, *, status_code: int = 200) -> None:
        self.status_code = status_code
        self._payload = payload
        self.headers = {"x-request-id": "provider-request"}

    def json(self) -> dict:
        return self._payload


def test_deepgram_response_is_converted_to_rational_word_times(monkeypatch, tmp_path: Path) -> None:
    source = tmp_path / "speech.wav"
    source.write_bytes(b"fixture")
    monkeypatch.setenv("DEEPGRAM_API_KEY", "test-key")
    payload = {
        "metadata": {"request_id": "deepgram-request", "duration": 1.25},
        "results": {
            "channels": [
                {
                    "alternatives": [
                        {
                            "detected_language": "en",
                            "words": [
                                {
                                    "word": "Hello",
                                    "punctuated_word": "Hello,",
                                    "start": 0.125,
                                    "end": 0.625,
                                    "confidence": 0.97,
                                    "speaker": 0,
                                },
                                {
                                    "word": "world",
                                    "start": 0.625,
                                    "end": 1.125,
                                    "confidence": 0.96,
                                    "speaker": 1,
                                },
                            ],
                        }
                    ]
                }
            ]
        },
    }
    monkeypatch.setattr(httpx, "post", lambda *args, **kwargs: _Response(payload))
    result = DeepgramTranscriptionProvider().transcribe(
        TranscriptionRequest(
            request_id="request",
            media_id="media",
            media_sha256="a" * 64,
            source_path=source.resolve(),
            retry=RetryPolicy(attempts=1),
        )
    )
    assert result.status is ProviderStatus.SUCCESS
    assert result.output is not None
    assert result.output.words[0].source_range.start.value == 125_000
    assert result.output.words[0].source_range.start.timescale == 1_000_000
    assert {item.speaker_id for item in result.output.speakers} == {"speaker_0", "speaker_1"}


def test_openai_structured_response_rejects_invented_candidate_id(monkeypatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    output = {
        "judgments": [
            {
                "candidate_id": "invented",
                "score": 0.9,
                "labels": ["proof"],
                "reasons": ["clear proof"],
                "confidence": 0.9,
            }
        ]
    }
    payload = {
        "id": "response-id",
        "output": [
            {
                "type": "message",
                "content": [{"type": "output_text", "text": __import__("json").dumps(output)}],
            }
        ],
    }
    monkeypatch.setattr(httpx, "post", lambda *args, **kwargs: _Response(payload))
    result = OpenAIProvider().judge(
        SemanticRequest(
            request_id="request",
            task="rank proof",
            instruction="use observable evidence",
            candidates=[CandidateInput(candidate_id="verified", summary="verified proof")],
            retry=RetryPolicy(attempts=1),
        )
    )
    assert result.status is ProviderStatus.FAILED
    assert result.error_code == "invalid_provider_response"


def test_openai_semantic_and_vision_success_are_strictly_structured(
    monkeypatch, tmp_path: Path
) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    def response_for(request, *args, **kwargs):
        body = kwargs["json"]
        schema_name = body["text"]["format"]["name"]
        candidate_id = "verified" if schema_name == "editorial_semantic" else "frame"
        output = {
            "judgments": [
                {
                    "candidate_id": candidate_id,
                    "score": 0.9,
                    "labels": ["proof", "detail"],
                    "reasons": ["observable product detail"],
                    "confidence": 0.85,
                }
            ]
        }
        return _Response(
            {
                "id": "response-id",
                "usage": {"input_tokens": 12, "output_tokens": 8},
                "output": [
                    {
                        "type": "message",
                        "content": [{"type": "output_text", "text": json.dumps(output)}],
                    }
                ],
            }
        )

    monkeypatch.setattr(httpx, "post", response_for)
    provider = OpenAIProvider()
    semantic = provider.judge(
        SemanticRequest(
            request_id="semantic",
            task="proof",
            instruction="rank observable proof",
            candidates=[CandidateInput(candidate_id="verified", summary="product proof")],
            retry=RetryPolicy(attempts=1),
        )
    )
    assert semantic.status is ProviderStatus.SUCCESS
    assert semantic.evidence is not None
    assert semantic.evidence.usage.input_tokens == 12
    frame = (tmp_path / "frame.jpg").resolve()
    frame.write_bytes(b"fixture-image")
    vision = provider.inspect(
        VisionRequest(
            request_id="vision",
            task="proof",
            instruction="describe observable proof",
            frames=[
                FrameInput(
                    candidate_id="frame",
                    path=frame,
                    sha256=file_sha256(frame),
                )
            ],
            retry=RetryPolicy(attempts=1),
        )
    )
    assert vision.status is ProviderStatus.SUCCESS
    assert vision.output is not None
    assert vision.output.judgments[0].observable_cues == ["observable product detail"]
