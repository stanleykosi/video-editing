import os
import wave
from pathlib import Path

import pytest

from editorial_brain.core.hashing import file_sha256
from editorial_brain.providers.base import (
    CandidateInput,
    ProviderStatus,
    RetryPolicy,
    SemanticRequest,
    TranscriptionRequest,
)
from editorial_brain.providers.deepgram import DeepgramTranscriptionProvider
from editorial_brain.providers.openai_provider import OpenAIProvider

pytestmark = pytest.mark.provider_smoke


def _enabled() -> bool:
    return os.getenv("EDITORIAL_BRAIN_RUN_PROVIDER_SMOKE") == "1"


@pytest.mark.skipif(not _enabled(), reason="real provider smoke is explicitly opt-in")
def test_openai_semantic_provider_smoke() -> None:
    result = OpenAIProvider().judge(
        SemanticRequest(
            request_id="provider-smoke-openai",
            task="rank visual proof",
            instruction="Prefer the candidate that visibly proves the claim.",
            candidates=[
                CandidateInput(candidate_id="proof", summary="clear product proof close-up")
            ],
            retry=RetryPolicy(attempts=1),
        )
    )
    assert result.status is ProviderStatus.SUCCESS
    assert result.output is not None
    assert result.output.judgments[0].candidate_id == "proof"


@pytest.mark.skipif(not _enabled(), reason="real provider smoke is explicitly opt-in")
def test_deepgram_transcription_provider_smoke(tmp_path: Path) -> None:
    source = tmp_path / "silence.wav"
    with wave.open(str(source), "wb") as stream:
        stream.setnchannels(1)
        stream.setsampwidth(2)
        stream.setframerate(16_000)
        stream.writeframes(b"\x00\x00" * 16_000)
    result = DeepgramTranscriptionProvider().transcribe(
        TranscriptionRequest(
            request_id="provider-smoke-deepgram",
            media_id="smoke-audio",
            media_sha256=file_sha256(source),
            source_path=source.resolve(),
            retry=RetryPolicy(attempts=1),
        )
    )
    assert result.status is ProviderStatus.SUCCESS
    assert result.output is not None
