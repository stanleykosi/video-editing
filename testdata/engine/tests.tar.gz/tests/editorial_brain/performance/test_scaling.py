import time
import tracemalloc
from pathlib import Path

import pytest

from editorial_brain.benchmark.fixtures import synthetic_fixture
from editorial_brain.benchmark.scenarios import SCENARIOS
from editorial_brain.core.models import EditorialBrief, EditorialConstraints, StoryMap
from editorial_brain.policies.registry import PolicyRegistry
from editorial_brain.search.beam import beam_search
from editorial_brain.selects.generator import generate_selects
from editorial_brain.storage.cache import BrainCache, CacheIdentity
from editorial_brain.story.beats import build_story_map
from editorial_brain.understanding.index import SearchDocument, UnderstandingSearchIndex
from video_engine.api import RationalTime


@pytest.mark.performance
def test_thousand_document_index_and_search_under_one_second() -> None:
    started = time.monotonic()
    index = UnderstandingSearchIndex(
        [
            SearchDocument(
                id=f"document-{number:04d}",
                kind="shot",
                media_id="media",
                text=f"subject action proof sequence {number % 25}",
                terms=["subject", "action", "proof", "sequence", str(number % 25)],
                source_id=f"shot-{number:04d}",
            )
            for number in range(1000)
        ]
    )
    hits = index.search("subject proof 7", limit=20)
    assert hits
    assert time.monotonic() - started < 1


@pytest.mark.performance
def test_four_hour_transcript_scale_index_stays_bounded() -> None:
    tracemalloc.start()
    started = time.monotonic()
    documents = [
        SearchDocument(
            id=f"phrase-{second:05d}",
            kind="transcript_phrase",
            media_id="four-hour-source",
            text=f"speaker explains topic {second % 120} with proof {second % 17}",
            terms=["speaker", "explains", str(second % 120), str(second % 17)],
            source_id=f"phrase-{second:05d}",
        )
        for second in range(4 * 60 * 60)
    ]
    index = UnderstandingSearchIndex(documents)
    hits = index.search("topic 42 proof", limit=25)
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    assert hits
    assert time.monotonic() - started < 10
    assert peak < 256 * 1024 * 1024


@pytest.mark.performance
def test_long_form_beam_search_prunes_hundreds_of_beat_options(tmp_path: Path) -> None:
    scenario = SCENARIOS[0]
    _project, base_brief, index, _expected = synthetic_fixture(tmp_path, scenario)
    policy = PolicyRegistry().get(base_brief.profile.value).model_copy(update={"beam_width": 24})
    base_story = build_story_map(base_brief, index)
    base_pools = generate_selects(base_story, index, policy, top_k=3)
    beats = []
    pools = {}
    for position in range(120):
        template = base_story.beats[position % len(base_story.beats)]
        beat_id = f"long-beat:{position:04d}"
        beats.append(
            template.model_copy(
                update={
                    "id": beat_id,
                    "must_follow": [f"long-beat:{position - 1:04d}"] if position else [],
                },
                deep=True,
            )
        )
        source_pool = base_pools[template.id]
        pools[beat_id] = [
            candidate.model_copy(
                update={
                    "id": f"long-select:{position:04d}:{rank:02d}",
                    "beat_id": beat_id,
                },
                deep=True,
            )
            for rank, candidate in enumerate(source_pool)
        ]
    story = StoryMap(brief_id="long-form", beats=beats)
    brief = base_brief.model_copy(
        update={
            "id": "long-form",
            "constraints": EditorialConstraints(
                target_duration=RationalTime(value=7 * 120, timescale=2),
                beam_width=24,
            ),
        },
        deep=True,
    )
    started = time.monotonic()
    assemblies = beam_search(
        story,
        pools,
        index.shots,
        brief,
        policy,
        variants=3,
        seed=19,
    )
    assert len(assemblies) == 3
    assert all(len(item.segments) == 120 for item in assemblies)
    assert time.monotonic() - started < 10


@pytest.mark.performance
def test_validated_cache_reuse_is_bounded(tmp_path: Path) -> None:
    cache = BrainCache(tmp_path / "cache")
    identity = CacheIdentity(
        namespace="performance",
        source_hashes={"media": "a" * 64},
        analysis_version="1.0.0",
        provider="deterministic",
        model="fixture-v1",
        provider_fingerprint="provider-v1",
        prompt_fingerprint="schema-v1",
    )
    expected = EditorialBrief(id="cache-performance", objective="reuse verified analysis")
    cache.store(identity, expected)

    started = time.monotonic()
    for _ in range(1000):
        assert cache.load(identity, EditorialBrief) == expected
    assert time.monotonic() - started < 2
