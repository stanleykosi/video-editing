"""Immutable evidence for the renderer behavior frozen before migration."""

from __future__ import annotations

import json
from typing import Any

import pytest

from scripts.baseline_bundle import materialize_baseline
from tests.support.legacy_fixtures import probe

BASELINE = materialize_baseline()


def _video(metadata: dict[str, Any]) -> dict[str, Any]:
    return next(stream for stream in metadata["streams"] if stream["codec_type"] == "video")


def _audio(metadata: dict[str, Any]) -> dict[str, Any]:
    return next(stream for stream in metadata["streams"] if stream["codec_type"] == "audio")


@pytest.mark.integration
def test_archived_existing_renderer_contract_is_frozen() -> None:
    metadata = probe(BASELINE / "outputs" / "legacy_existing_preview.mp4")
    video = _video(metadata)
    audio = _audio(metadata)
    assert (int(video["width"]), int(video["height"])) == (320, 180)
    assert video["r_frame_rate"] == "24/1"
    assert video["nb_frames"] == "60"
    assert audio["sample_rate"] == "48000"
    assert float(metadata["format"]["duration"]) == pytest.approx(2.5, abs=0.001)


@pytest.mark.integration
def test_archived_faceless_renderer_contract_is_frozen() -> None:
    metadata = probe(BASELINE / "outputs" / "legacy_faceless_preview.mp4")
    video = _video(metadata)
    audio = _audio(metadata)
    assert (int(video["width"]), int(video["height"])) == (160, 284)
    assert video["r_frame_rate"] == "24/1"
    assert video["nb_frames"] == "46"
    assert audio["sample_rate"] == "48000"
    assert audio["channels"] == 1
    assert float(metadata["format"]["duration"]) == pytest.approx(1.92, abs=0.001)


def test_archived_manifest_records_decoded_essence_and_audio() -> None:
    manifest = json.loads((BASELINE / "baseline_manifest.json").read_text(encoding="utf-8"))
    assert set(manifest["outputs"]) == {
        "existing",
        "existing_base",
        "caption",
        "overlay",
        "sfx",
        "faceless",
        "vertical",
        "hdr_to_sdr",
    }
    for artifact in manifest["outputs"].values():
        assert len(artifact["sha256"]) == 64
        assert len(artifact["essence"]["framemd5_sha256"]) == 64
        assert len(artifact["essence"]["pcm_s16le_sha256"]) == 64
        assert artifact["loudness"]["input_i"] != "-inf"


def test_archived_ass_fixture_contains_one_control_sequence() -> None:
    fixture = BASELINE / "workspace" / "existing" / "master.ass"
    dialogue = next(
        line for line in fixture.read_text(encoding="utf-8").splitlines() if "CAPTION" in line
    )
    assert "\\N" in dialogue
    assert "\\\\N" not in dialogue
