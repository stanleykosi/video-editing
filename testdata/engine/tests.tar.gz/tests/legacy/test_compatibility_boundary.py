from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
VIDEO_USE = ROOT / "tools" / "video-use"
COMPAT = VIDEO_USE / "compat"
HELPERS = VIDEO_USE / "helpers"


def test_compatibility_implementations_and_forwarders_have_one_owner() -> None:
    expected = {"caption_styles.py", "grade.py", "render.py", "timeline_view.py"}
    implementations = {
        path.name for path in COMPAT.glob("*.py") if path.name != "__init__.py"
    }
    assert implementations == expected

    for name in sorted(expected):
        wrapper = (HELPERS / name).read_text(encoding="utf-8")
        assert "compat" in wrapper
        assert len(wrapper.splitlines()) <= 25


def test_compatibility_facades_do_not_restore_a_second_renderer() -> None:
    render_source = (COMPAT / "render.py").read_text(encoding="utf-8")
    grade_source = (COMPAT / "grade.py").read_text(encoding="utf-8")
    timeline_source = (COMPAT / "timeline_view.py").read_text(encoding="utf-8")

    assert "VideoEngine" in render_source
    assert ".renderer(" in render_source
    assert "subprocess" not in render_source
    assert "VideoEngine" in grade_source
    assert "subprocess" not in grade_source
    assert "VideoEngine" in timeline_source
    assert "subprocess" not in timeline_source
