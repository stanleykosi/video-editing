"""Prevent retired second render implementations from returning."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HELPERS = ROOT / "tools" / "video-use" / "helpers"
RETIRED_FILENAMES = (
    "faceless" + "_renderer.py",
    "render_vertical" + "_podcast_clips.py",
    "render_variant" + "_caption_styles.py",
    "sfx" + "_renderer.py",
)
LIVE_SUFFIXES = {".py", ".md", ".json", ".toml", ".yaml", ".yml", ".js", ".ts"}
LIVE_ROOTS = (
    ROOT / "src",
    ROOT / "scripts",
    ROOT / "tools" / "video-use" / "helpers",
    ROOT / "content_creation",
    ROOT / "skills",
    ROOT / "presets",
    ROOT / "style_packs",
    ROOT / "qc_checklists",
    ROOT / "technique_cards",
    ROOT / ".github" / "workflows",
)
LIVE_FILES = (
    ROOT / "README.md",
    ROOT / "pyproject.toml",
    ROOT / "package.json",
    ROOT / "tools" / "video-use" / "README.md",
    ROOT / "tools" / "video-use" / "SKILL.md",
    ROOT / "tools" / "video-use" / "install.md",
)


def _production_files() -> list[Path]:
    files = [
        path
        for root in LIVE_ROOTS
        if root.is_dir()
        for path in root.rglob("*")
        if path.is_file() and path.suffix in LIVE_SUFFIXES and "__pycache__" not in path.parts
    ]
    return sorted({*files, *(path for path in LIVE_FILES if path.is_file())})


def test_deprecated_renderers_cannot_return() -> None:
    assert [name for name in RETIRED_FILENAMES if (HELPERS / name).exists()] == []

    retired_terms = {
        term for filename in RETIRED_FILENAMES for term in (filename, filename.removesuffix(".py"))
    }
    references = {
        f"{path.relative_to(ROOT)}:{line_number}": term
        for path in _production_files()
        for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1)
        for term in retired_terms
        if term in line
    }
    assert references == {}
