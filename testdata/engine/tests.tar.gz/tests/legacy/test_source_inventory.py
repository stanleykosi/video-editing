from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
ENGINE = ROOT / "src" / "video_engine"
REQUIRED_SUBSYSTEMS = {
    "adapters",
    "api",
    "audio",
    "captions",
    "cli",
    "color",
    "core",
    "graphics",
    "inspection",
    "media",
    "operations",
    "qc",
    "render",
    "storage",
    "visual",
}


def test_required_engine_subsystems_are_source_visible_and_not_ignored() -> None:
    assert {path.name for path in ENGINE.iterdir() if path.is_dir()} >= REQUIRED_SUBSYSTEMS
    for name in sorted(REQUIRED_SUBSYSTEMS):
        package = ENGINE / name
        assert (package / "__init__.py").is_file(), package
        assert any(package.rglob("*.py")), package

    if shutil.which("git") is None or not (ROOT / ".git").exists():
        pytest.skip("Git ignore validation requires a Git working tree")

    ignored: list[str] = []
    for path in sorted(ENGINE.rglob("*")):
        if not path.is_file() or path.suffix not in {".py", ".typed", ".ts", ".tsx", ".mjs"}:
            continue
        result = subprocess.run(
            ["git", "check-ignore", "--no-index", "--quiet", str(path.relative_to(ROOT))],
            cwd=ROOT,
            check=False,
        )
        if result.returncode == 0:
            ignored.append(path.relative_to(ROOT).as_posix())
        else:
            assert result.returncode == 1, result.returncode
    assert ignored == []
