from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

import pytest

from scripts.baseline_bundle import materialize_baseline
from tests.support.golden_metrics import (
    audio_summary,
    decode_audio,
    decoded_pcm_sha256,
    frame_dhash,
    frame_dhash_digest,
    frame_dhash_sequence,
    frequency_levels_db,
    hamming_distance,
    media_tool_fingerprint,
    probe,
)
from tests.support.golden_projects import BUILDERS, GoldenProject
from video_engine.api.engine import VideoEngine
from video_engine.core.schema import CaptionTrack, ColorSpace
from video_engine.qc.models import QCOverallStatus, QCRequest
from video_engine.render.models import RenderMode, RenderRequest
from video_engine.render.nodes import ArtifactType

ROOT = Path(__file__).resolve().parents[2]
EXPECTATIONS = json.loads(
    (ROOT / "testdata" / "engine" / "golden_expectations.json").read_text(encoding="utf-8")
)
EXACT_TOOL_MATCH = EXPECTATIONS["media_tool_fingerprint"] == media_tool_fingerprint()
EXPECTATIONS = EXPECTATIONS["projects"]
ALL_PROJECT_IDS = {
    "existing_footage_edit",
    "faceless_vertical_edit",
    *BUILDERS,
}


@pytest.fixture(scope="module")
def golden_engine(tmp_path_factory: pytest.TempPathFactory) -> VideoEngine:
    return VideoEngine(tmp_path_factory.mktemp("canonical-golden-engine"))


def _render_request(scenario: GoldenProject, output: Path) -> RenderRequest:
    section_duration = (
        scenario.project.settings.frame_rate.frames_to_time(scenario.section_duration_frames)
        if scenario.section_duration_frames is not None
        else None
    )
    return RenderRequest(
        output_path=output,
        mode=RenderMode.PREVIEW,
        sectioning=scenario.section_duration_frames is not None,
        section_duration=section_duration,
    )


def _assert_output(
    scenario: GoldenProject,
    output: Path,
    expectation: dict[str, Any],
) -> None:
    metadata = probe(output)
    video = next(stream for stream in metadata["streams"] if stream["codec_type"] == "video")
    audio = next(stream for stream in metadata["streams"] if stream["codec_type"] == "audio")
    assert (int(video["width"]), int(video["height"])) == scenario.expected_dimensions
    assert int(video["nb_read_frames"]) == scenario.expected_frames
    assert video["avg_frame_rate"] == (
        f"{scenario.project.settings.frame_rate.numerator}/"
        f"{scenario.project.settings.frame_rate.denominator}"
    )
    assert audio["sample_rate"] == "48000"
    assert audio["channels"] == 2
    measured_sequence = frame_dhash_sequence(output)
    expected_sequence = tuple(expectation["all_frame_dhash"])
    assert len(measured_sequence) == len(expected_sequence) == scenario.expected_frames
    distances = [
        hamming_distance(measured, expected)
        for measured, expected in zip(
            measured_sequence,
            expected_sequence,
            strict=True,
        )
    ]
    assert max(distances, default=0) <= int(expectation["all_frame_max_hamming"])
    assert sum(distances) / max(1, len(distances)) <= float(expectation["all_frame_mean_hamming"])
    expected_digest = hashlib.sha256(
        ("\n".join(expected_sequence) + "\n").encode("ascii")
    ).hexdigest()
    assert expected_digest == expectation["all_frame_dhash_sha256"]
    if EXACT_TOOL_MATCH:
        assert frame_dhash_digest(output) == expectation["all_frame_dhash_sha256"]
    expected_hashes = expectation["frame_dhash"]
    assert set(expected_hashes) == {str(index) for index in scenario.frame_samples}
    for index in scenario.frame_samples:
        measured = frame_dhash(output, index)
        assert hamming_distance(measured, expected_hashes[str(index)]) <= int(
            expectation["all_frame_max_hamming"]
        )
    samples = decode_audio(output)
    expected_samples = round(
        scenario.project.settings.frame_rate.frames_to_time(scenario.expected_frames).seconds
        * 48_000
    )
    assert abs(samples.size - expected_samples) <= 2_048
    if EXACT_TOOL_MATCH:
        assert samples.size == int(expectation["audio_samples"])
    levels = frequency_levels_db(samples, scenario.audio_frequencies_hz)
    assert all(level > -45 for level in levels.values()), levels
    for window in scenario.audio_windows:
        window_samples = samples[window.start_sample : window.end_sample]
        present = frequency_levels_db(window_samples, window.present_frequencies_hz)
        absent = frequency_levels_db(window_samples, window.absent_frequencies_hz)
        assert all(value >= window.present_minimum_db for value in present.values()), present
        assert all(value <= window.absent_maximum_db for value in absent.values()), absent


def test_golden_expectation_manifest_covers_required_projects() -> None:
    assert set(EXPECTATIONS) == ALL_PROJECT_IDS
    baseline = materialize_baseline()
    for historical in ("existing_footage_edit", "faceless_vertical_edit"):
        evidence_path = Path(str(EXPECTATIONS[historical]["evidence"]))
        evidence = baseline / evidence_path.relative_to("engine_baseline")
        assert evidence.is_file()


@pytest.mark.golden
@pytest.mark.integration
@pytest.mark.parametrize(
    "scenario_id",
    list(BUILDERS),
)
def test_canonical_golden_project(
    scenario_id: str,
    golden_engine: VideoEngine,
) -> None:
    scenario = BUILDERS[scenario_id](golden_engine)
    if scenario.browser_required and os.environ.get("VIDEO_ENGINE_RUN_REMOTION_INTEGRATION") != "1":
        pytest.skip("set VIDEO_ENGINE_RUN_REMOTION_INTEGRATION=1 with a runnable browser")
    validation = golden_engine.validate_project(scenario.project)
    assert validation.valid
    project_path = golden_engine.project_root / "projects" / f"{scenario.id}.json"
    golden_engine.save_project(scenario.project, project_path)
    loaded, migrations = golden_engine.load_project(project_path)
    assert not migrations
    assert loaded == scenario.project

    service = golden_engine.renderer(scenario.project)
    request = _render_request(
        scenario, golden_engine.project_root / "outputs" / f"{scenario.id}.mp4"
    )
    compiled = service.compile(request)
    node_kinds = {node.node_type.value for node in compiled.graph.nodes}
    assert set(scenario.required_node_kinds) <= node_kinds
    render = service.render(request)
    assert render.output_path.is_file()
    _assert_output(scenario, render.output_path, EXPECTATIONS[scenario.id])
    mux = compiled.graph.node(compiled.graph.outputs["main"])
    encoded_audio = next(
        compiled.graph.node(node_id)
        for node_id in mux.inputs
        if compiled.graph.node(node_id).artifact_type is ArtifactType.ENCODED_AUDIO
    )
    master_id = encoded_audio.inputs[0]
    master_record = next(
        record for record in render.manifest.records if record.node_id == master_id
    )
    assert master_record.artifact_path is not None
    exact_master = decode_audio(master_record.artifact_path)
    expected_master_samples = round(
        scenario.project.settings.frame_rate.frames_to_time(scenario.expected_frames).seconds
        * 48_000
    )
    assert exact_master.size == expected_master_samples
    expected_master = EXPECTATIONS[scenario.id]["master_audio"]
    measured_master = audio_summary(exact_master)
    assert float(measured_master["rms"]) == pytest.approx(float(expected_master["rms"]), abs=0.005)
    assert float(measured_master["peak"]) == pytest.approx(float(expected_master["peak"]), abs=0.01)
    assert float(measured_master["dc_offset"]) == pytest.approx(
        float(expected_master["dc_offset"]), abs=0.002
    )
    if EXACT_TOOL_MATCH:
        assert (
            decoded_pcm_sha256(master_record.artifact_path)
            == EXPECTATIONS[scenario.id]["master_pcm_f32le_stereo_sha256"]
        )

    qc = golden_engine.qc(scenario.project).run(
        QCRequest(
            output_path=render.output_path,
            report_dir=golden_engine.project_root / "qc" / scenario.id,
        )
    )
    assert qc.report.status in {
        QCOverallStatus.PASSED,
        QCOverallStatus.PASSED_WITH_WARNINGS,
    }
    findings = sorted(check.code for check in qc.report.checks if check.status.value != "passed")
    assert findings == EXPECTATIONS[scenario.id]["qc_findings"]
    assert qc.report.output_sha256 == render.manifest.output_sha256
    contact_sheets = [
        artifact for artifact in qc.report.evidence if artifact.kind == "contact_sheet"
    ]
    assert len(contact_sheets) == 1
    contact_sheet = contact_sheets[0]
    assert contact_sheet.path.is_file()
    assert hashlib.sha256(contact_sheet.path.read_bytes()).hexdigest() == contact_sheet.sha256
    audio_signal = next(check for check in qc.report.checks if check.code == "audio.signal")
    if scenario.audio_frequencies_hz:
        measurements = {item.name: item.value for item in audio_signal.measurements}
        expected_loudness = EXPECTATIONS[scenario.id]["loudness"]
        assert float(measurements["integrated_loudness"]) == pytest.approx(
            float(expected_loudness["integrated_lufs"]), abs=0.3
        )
        assert float(measurements["true_peak"]) == pytest.approx(
            float(expected_loudness["true_peak_dbtp"]), abs=0.3
        )
    if any(
        isinstance(track, CaptionTrack) for track in scenario.project.sequence().timeline.tracks
    ):
        caption_layout = next(
            check for check in qc.report.checks if check.code == "timeline.caption_layout"
        )
        assert caption_layout.status.value == "passed"
    if scenario.browser_required:
        bounds = next(check for check in qc.report.checks if check.code == "video.graphics_bounds")
        assert bounds.status.value == "passed"

    if scenario.id == "hdr_to_sdr_project":
        metadata = probe(render.output_path)
        video = next(stream for stream in metadata["streams"] if stream["codec_type"] == "video")
        assert video["color_transfer"] == "bt709"
        assert video["color_primaries"] == "bt709"
        assert compiled.delivery_profile.output_color_space is ColorSpace.REC709

    if scenario.id == "long_form_sequence":
        range_output = golden_engine.project_root / "outputs" / "long-form-chapter-2.mp4"
        chapter = service.render(
            RenderRequest(
                output_path=range_output,
                mode=RenderMode.RANGE,
                chapter_id="chapter-1",
                sectioning=False,
            )
        )
        chapter_probe = probe(chapter.output_path)
        chapter_video = next(
            stream for stream in chapter_probe["streams"] if stream["codec_type"] == "video"
        )
        assert int(chapter_video["nb_read_frames"]) == 48
