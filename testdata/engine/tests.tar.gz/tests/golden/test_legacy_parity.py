from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pytest

from scripts.baseline_bundle import materialize_baseline
from video_engine.api.engine import VideoEngine
from video_engine.core.time import FrameRate, RationalTime
from video_engine.qc.models import QCOverallStatus, QCRequest
from video_engine.qc.parity import ParityPolicy
from video_engine.render.models import RenderMode, RenderRequest

ROOT = Path(__file__).resolve().parents[2]
BASELINE = materialize_baseline()
WORKSPACE = BASELINE / "workspace"
ARCHIVE_ROOT = Path("/home/stanley/video-editing")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _relocate_archived_path(value: str) -> Path:
    source = Path(value)
    try:
        relative = source.relative_to(ARCHIVE_ROOT)
    except ValueError:
        return source
    baseline_relative = Path("test_projects") / "engine_baseline"
    if relative.is_relative_to(baseline_relative):
        return BASELINE / relative.relative_to(baseline_relative)
    return ROOT / relative


def _relocate_payload(value: Any) -> Any:
    if isinstance(value, str) and value.startswith(f"{ARCHIVE_ROOT}/"):
        return str(_relocate_archived_path(value))
    if isinstance(value, list):
        return [_relocate_payload(item) for item in value]
    if isinstance(value, dict):
        return {key: _relocate_payload(item) for key, item in value.items()}
    return value


def _portable_edl(source: Path, destination: Path) -> Path:
    payload = _relocate_payload(json.loads(source.read_text(encoding="utf-8")))
    destination.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return destination


def _frames(value: int) -> RationalTime:
    return RationalTime(value=value, timescale=24)


@dataclass(frozen=True)
class LegacyCase:
    key: str
    edl_name: str
    output_name: str
    expected_frames: int
    frame_samples: tuple[int, ...]
    max_hash_distance: int
    audio_samples: tuple[int, ...]
    improvements: tuple[str, ...]


CASES = (
    LegacyCase(
        "base",
        "base_edl.json",
        "legacy_base_preview.mp4",
        58,
        (1, 7, 14, 22, 29, 38, 44, 50, 54),
        8,
        (5, 27, 47),
        ("Frame-quantized cuts remove the legacy two-frame duration overrun.",),
    ),
    LegacyCase(
        "caption",
        "caption_edl.json",
        "legacy_caption_preview.mp4",
        58,
        (2, 32, 57),
        9,
        (5, 27, 47),
        ("ASS captions retain native styling while timeline duration is exact.",),
    ),
    LegacyCase(
        "overlay",
        "overlay_edl.json",
        "legacy_overlay_preview.mp4",
        58,
        (2, 34, 52),
        9,
        (5, 27, 47),
        ("Overlay placement is rational and does not extend program duration.",),
    ),
    LegacyCase(
        "sfx",
        "sfx_edl.json",
        "legacy_sfx_preview.mp4",
        58,
        (2, 12, 28, 48, 55),
        8,
        (5, 24, 47),
        ("SFX placement is sample-counted and program duration remains exact.",),
    ),
    LegacyCase(
        "existing",
        "edl.json",
        "legacy_existing_preview.mp4",
        58,
        (2, 32, 57),
        10,
        (5, 27, 47),
        ("Canonical output is 58 frames instead of the legacy 60-frame overrun.",),
    ),
    LegacyCase(
        "vertical",
        "vertical_edl.json",
        "legacy_vertical_preview.mp4",
        24,
        (),
        0,
        (5, 14),
        ("Explicit focus_x=0 is honored instead of being replaced by center focus.",),
    ),
    LegacyCase(
        "hdr_to_sdr",
        "hdr_edl.json",
        "legacy_hdr_preview.mp4",
        24,
        (3, 10, 18),
        16,
        (5, 14),
        ("HLG is explicitly interpreted and emitted as tagged Rec.709 SDR.",),
    ),
)


def test_frozen_legacy_manifest_checksums_are_immutable() -> None:
    manifest = json.loads((BASELINE / "baseline_manifest.json").read_text(encoding="utf-8"))
    for archived_path, expected in manifest["inputs"].items():
        path = _relocate_archived_path(archived_path)
        assert path.is_file(), path
        assert _sha256(path) == expected
    for entry in manifest["outputs"].values():
        path = _relocate_archived_path(entry["path"])
        assert path.is_file(), path
        assert _sha256(path) == entry["sha256"]
    for entry in manifest["contact_sheets"].values():
        path = _relocate_archived_path(entry["path"])
        assert path.is_file(), path
        assert _sha256(path) == entry["sha256"]


@pytest.mark.golden
@pytest.mark.integration
@pytest.mark.parametrize("case", CASES, ids=lambda case: case.key)
def test_existing_legacy_variants_have_canonical_render_parity(
    case: LegacyCase,
    tmp_path: Path,
) -> None:
    source_edl = WORKSPACE / "existing" / case.edl_name
    portable_edl = _portable_edl(source_edl, tmp_path / case.edl_name)
    engine = VideoEngine(tmp_path / "engine")
    migration = engine.adapters().import_legacy_edl(portable_edl)
    assert migration.report.valid
    candidate = tmp_path / f"canonical-{case.key}.mp4"
    render = engine.renderer(migration.project).render(
        RenderRequest(
            output_path=candidate,
            mode=RenderMode.PREVIEW,
            delivery_profile_id="preview",
        )
    )
    assert render.manifest.output_sha256

    policy = ParityPolicy(
        frame_rate=FrameRate(numerator=24),
        expected_candidate_duration=_frames(case.expected_frames),
        frame_sample_times=tuple(_frames(value) for value in case.frame_samples),
        max_frame_hash_distance=(case.max_hash_distance if case.frame_samples else None),
        audio_sample_times=tuple(_frames(value) for value in case.audio_samples),
        audio_window=_frames(2),
        audio_rms_tolerance_db=18,
        documented_improvements=case.improvements,
    )
    report = engine.parity().compare(
        BASELINE / "outputs" / case.output_name,
        candidate,
        policy,
    )
    engine.parity().write(
        report,
        tmp_path / f"{case.key}-parity.json",
        tmp_path / f"{case.key}-parity.md",
    )
    assert report.passed, report.model_dump(mode="json")
    assert report.candidate.frame_count == case.expected_frames


@pytest.mark.golden
@pytest.mark.integration
def test_faceless_legacy_fixture_has_canonical_render_and_qc_parity(
    tmp_path: Path,
) -> None:
    if os.environ.get("VIDEO_ENGINE_RUN_REMOTION_INTEGRATION") != "1":
        pytest.skip("set VIDEO_ENGINE_RUN_REMOTION_INTEGRATION=1 with a runnable browser")
    project_dir = WORKSPACE / "faceless"
    engine = VideoEngine(tmp_path / "engine")
    migration = engine.adapters().import_faceless(
        project_dir,
        voiceover=project_dir / "assets" / "audio" / "voiceover.wav",
    )
    candidate = tmp_path / "canonical-faceless.mp4"
    render = engine.renderer(migration.project).render(
        RenderRequest(
            output_path=candidate,
            mode=RenderMode.PREVIEW,
            delivery_profile_id="preview",
        )
    )
    assert render.manifest.output_sha256 == (
        "833e5a07931e7e95303eec486741d89bb40507338903f3fb76923f89d9e03031"
    )
    report = engine.parity().compare(
        BASELINE / "outputs" / "legacy_faceless_preview.mp4",
        candidate,
        ParityPolicy(
            frame_rate=FrameRate(numerator=24),
            expected_candidate_duration=_frames(48),
            audio_sample_times=(_frames(8), _frames(30), _frames(40)),
            audio_window=_frames(2),
            audio_frequency_tolerance_hz=12,
            audio_rms_tolerance_db=3,
            require_audio_channel_match=False,
            documented_improvements=(
                "Program duration is 48 frames instead of the truncated legacy 46 frames.",
                "Mono legacy audio is delivered as explicit stereo.",
                "Pillow overlays are replaced by full-resolution registered Remotion graphics.",
            ),
        ),
    )
    assert report.passed, report.model_dump(mode="json")
    qc = engine.qc(migration.project).run(
        QCRequest(output_path=candidate, report_dir=tmp_path / "qc")
    )
    assert qc.report.status is QCOverallStatus.PASSED
    bounds = next(check for check in qc.report.checks if check.code == "video.graphics_bounds")
    assert bounds.status.value == "passed"
