from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest

from tests.support.legacy_fixtures import build_legacy_workspace, probe

ROOT = Path(__file__).resolve().parents[2]
RENDER = ROOT / "tools" / "video-use" / "helpers" / "render.py"
LAUNCHER = ROOT / "tools" / "video-use" / "helpers" / "video_engine.py"
TIMELINE_VIEW = ROOT / "tools" / "video-use" / "helpers" / "timeline_view.py"
PYTHON = ROOT / ".venv" / "bin" / "python"


@pytest.fixture(scope="module")
def compatibility_workspace(tmp_path_factory: pytest.TempPathFactory) -> dict[str, Path]:
    return build_legacy_workspace(tmp_path_factory.mktemp("compatibility-entrypoints"))


@pytest.mark.integration
def test_existing_render_helper_delegates_to_canonical_engine(
    compatibility_workspace: dict[str, Path],
) -> None:
    output = compatibility_workspace["root"] / "compatibility-preview.mp4"
    completed = subprocess.run(
        [
            str(PYTHON),
            str(RENDER),
            str(compatibility_workspace["base_edl"]),
            "--output",
            str(output),
            "--preview",
            "--no-loudnorm",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)
    metadata = probe(output)
    video = next(stream for stream in metadata["streams"] if stream["codec_type"] == "video")
    assert payload["ok"] is True
    assert payload["deprecated_entrypoint"] == str(RENDER.resolve())
    assert payload["qc_status"] == "passed"
    assert payload["output_sha256"]
    assert Path(payload["canonical_project"]).is_file()
    assert Path(payload["migration_report"]).is_file()
    assert video["nb_frames"] == "58"
    assert float(metadata["format"]["duration"]) == pytest.approx(58 / 24, abs=0.001)


def test_existing_render_helper_lists_caption_styles() -> None:
    completed = subprocess.run(
        [str(PYTHON), str(RENDER), "--list-caption-styles"],
        check=True,
        capture_output=True,
        text=True,
    )
    styles = json.loads(completed.stdout)
    assert "editorial_serif" in styles["styles"]
    assert styles["default_style"] in styles["styles"]


def test_location_independent_launcher_runs_outside_repository(tmp_path: Path) -> None:
    project_dir = tmp_path / "launched-project"
    completed = subprocess.run(
        [
            str(PYTHON),
            str(LAUNCHER),
            "init",
            str(project_dir),
            "--name",
            "Launcher Fixture",
            "--json",
        ],
        cwd=tmp_path,
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)
    assert payload["ok"] is True
    assert Path(payload["project"]) == project_dir / "project.json"


@pytest.mark.integration
def test_timeline_view_helper_delegates_to_canonical_inspection(
    compatibility_workspace: dict[str, Path],
) -> None:
    output = compatibility_workspace["root"] / "timeline-view.png"
    completed = subprocess.run(
        [
            str(PYTHON),
            str(TIMELINE_VIEW),
            str(compatibility_workspace["assets"] / "landscape_a.mp4"),
            "0",
            "1",
            "--n-frames",
            "4",
            "--output",
            str(output),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)
    artifact_kinds = {artifact["kind"] for artifact in payload["artifacts"]}
    assert payload["ok"] is True
    assert payload["deprecated_entrypoint"] == str(TIMELINE_VIEW.resolve())
    assert payload["canonical_command"] == "video-engine inspect range"
    assert output.is_file()
    assert Path(payload["inspection_report"]).is_file()
    assert {"filmstrip", "waveform", "inspection_contact_sheet"} <= artifact_kinds


def test_compatibility_final_cannot_bypass_visual_approval(
    compatibility_workspace: dict[str, Path],
) -> None:
    completed = subprocess.run(
        [
            str(PYTHON),
            str(RENDER),
            str(compatibility_workspace["base_edl"]),
            "--output",
            str(compatibility_workspace["root"] / "unapproved.mp4"),
            "--skip-visual-qc",
        ],
        capture_output=True,
        text=True,
    )
    assert completed.returncode == 2
    assert "unapproved final delivery is no longer supported" in completed.stderr
