from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import pytest

from video_engine.api.engine import VideoEngine
from video_engine.cli.main import main
from video_engine.core.schema import (
    AudioClip,
    AudioTrack,
    Clip,
    LoudnessProfile,
    MediaReference,
    StillImageClip,
    VideoTrack,
)
from video_engine.core.time import FrameRate, RationalTime, TimeRange
from video_engine.errors import EngineError
from video_engine.qc.models import QCOverallStatus, QCPolicy, QCRequest, QCScope
from video_engine.render.models import RenderMode, RenderRequest


@pytest.fixture(scope="module")
def qc_source(tmp_path_factory: pytest.TempPathFactory) -> Path:
    directory = tmp_path_factory.mktemp("qc-source")
    output = directory / "source.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "testsrc2=size=320x180:rate=24:duration=1",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:sample_rate=48000:duration=1",
            "-filter_complex",
            "[1:a]aformat=channel_layouts=stereo[a]",
            "-map",
            "0:v:0",
            "-map",
            "[a]",
            "-c:v",
            "libx264",
            "-preset",
            "ultrafast",
            "-pix_fmt",
            "yuv420p",
            "-color_primaries",
            "bt709",
            "-color_trc",
            "bt709",
            "-colorspace",
            "bt709",
            "-c:a",
            "aac",
            "-ar",
            "48000",
            "-shortest",
            output,
        ],
        check=True,
    )
    return output


def _render_fixture(tmp_path: Path, source: Path) -> tuple[VideoEngine, Path, Path]:
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "QC Integration",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    record = engine.media().import_media(source)
    project.media.append(engine.media().to_media_reference(record))
    full_range = TimeRange(
        start=RationalTime.zero(),
        duration=RationalTime(value=1, timescale=1),
    )
    project.sequence().timeline.tracks.append(
        VideoTrack(
            id="v1",
            items=[
                Clip(
                    id="clip-1",
                    media_reference_id=record.id,
                    timeline_range=full_range,
                    source_range=full_range,
                )
            ],
        )
    )
    project_path = engine.save_project(project)
    output = tmp_path / "preview.mp4"
    engine.renderer(project).render(
        RenderRequest(
            output_path=output,
            mode=RenderMode.PREVIEW,
            delivery_profile_id="preview",
        )
    )
    return engine, project_path, output


@pytest.mark.integration
@pytest.mark.golden
def test_manifest_bound_qc_measures_real_encoded_output(tmp_path: Path, qc_source: Path) -> None:
    engine, project_path, output = _render_fixture(tmp_path, qc_source)
    project, _ = engine.load_project(project_path)
    result = engine.qc(project).run(
        QCRequest(
            output_path=output,
            report_dir=tmp_path / "qc-report",
            policy=QCPolicy(
                black_min_duration_seconds=0.25,
                freeze_min_duration_seconds=0.5,
            ),
        )
    )

    assert result.report.status is QCOverallStatus.PASSED
    assert result.report.output_sha256 is not None
    assert {check.code for check in result.report.checks} >= {
        "ingest.sources",
        "timeline.invariants",
        "timeline.render_capabilities",
        "video.output",
        "video.signal",
        "audio.signal",
        "audio.duration_sync",
        "delivery.output",
        "video.contact_sheet",
    }
    contact_sheet = next(
        evidence for evidence in result.report.evidence if evidence.kind == "contact_sheet"
    )
    assert contact_sheet.path.is_file()
    assert contact_sheet.size_bytes > 0
    assert json.loads(result.json_path.read_text(encoding="utf-8"))["status"] == "passed"


@pytest.mark.integration
def test_final_render_requires_revision_bound_human_qc_approval(
    tmp_path: Path,
    qc_source: Path,
) -> None:
    engine, project_path, preview = _render_fixture(tmp_path, qc_source)
    project, _ = engine.load_project(project_path)
    qc_result = engine.qc(project).run(
        QCRequest(output_path=preview, report_dir=tmp_path / "approval-qc")
    )
    approval, approval_path = engine.approvals().create(
        qc_result,
        reviewed_by="integration-reviewer",
        notes="Reviewed the generated contact sheet and technical report.",
    )
    assert approval.preview_output_sha256 == qc_result.report.output_sha256

    with pytest.raises(EngineError, match="human-reviewed QC approval"):
        engine.renderer(project).render(
            RenderRequest(
                output_path=tmp_path / "unapproved-final.mp4",
                mode=RenderMode.FINAL,
                delivery_profile_id="final",
            )
        )

    final = engine.renderer(project).render(
        RenderRequest(
            output_path=tmp_path / "approved-final.mp4",
            mode=RenderMode.FINAL,
            delivery_profile_id="final",
            qc_approval_path=approval_path,
        )
    )
    manifest_approval = final.manifest.metadata["qc_approval"]
    assert isinstance(manifest_approval, dict)
    assert manifest_approval["approval_id"] == approval.approval_id

    changed = project.model_copy(deep=True)
    changed.revision += 1
    with pytest.raises(EngineError, match="does not match the canonical revision"):
        engine.renderer(changed).render(
            RenderRequest(
                output_path=tmp_path / "stale-final.mp4",
                mode=RenderMode.FINAL,
                delivery_profile_id="final",
                qc_approval_path=approval_path,
            )
        )


@pytest.mark.integration
def test_qc_blocks_a_truncated_delivery(tmp_path: Path, qc_source: Path) -> None:
    engine, project_path, output = _render_fixture(tmp_path, qc_source)
    project, _ = engine.load_project(project_path)
    damaged = tmp_path / "damaged.mp4"
    damaged.write_bytes(output.read_bytes()[:1024])

    report = (
        engine.qc(project)
        .run(
            QCRequest(
                output_path=damaged,
                delivery_profile_id="preview",
                scopes=(QCScope.DELIVERY,),
                report_dir=tmp_path / "damaged-report",
                policy=QCPolicy(generate_contact_sheet=False),
            )
        )
        .report
    )

    assert report.status is QCOverallStatus.FAILED
    assert any(finding.code == "delivery.output_unplayable" for finding in report.findings)


@pytest.mark.integration
def test_qc_reports_adversarial_video_audio_and_delivery_failures(
    tmp_path: Path,
    qc_source: Path,
) -> None:
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "QC adversarial fixture",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    record = engine.media().import_media(qc_source)
    project.media.append(engine.media().to_media_reference(record))
    project.delivery_profiles[0] = project.delivery_profiles[0].model_copy(
        update={
            "loudness": LoudnessProfile(
                integrated_lufs=-14,
                true_peak_dbtp=-2,
                loudness_range_lu=7,
            )
        }
    )
    project.sequence().timeline.tracks.append(
        VideoTrack(
            id="v1",
            items=[
                Clip(
                    id="first",
                    media_reference_id=record.id,
                    timeline_range=TimeRange(
                        start=RationalTime.zero(),
                        duration=RationalTime(value=1, timescale=2),
                    ),
                    source_range=TimeRange(
                        start=RationalTime.zero(),
                        duration=RationalTime(value=1, timescale=2),
                    ),
                ),
                Clip(
                    id="second",
                    media_reference_id=record.id,
                    timeline_range=TimeRange(
                        start=RationalTime(value=1, timescale=2),
                        duration=RationalTime(value=1, timescale=2),
                    ),
                    source_range=TimeRange(
                        start=RationalTime(value=1, timescale=2),
                        duration=RationalTime(value=1, timescale=2),
                    ),
                ),
            ],
        )
    )
    output = tmp_path / "adversarial.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=c=black:size=640x360:rate=30:duration=1.2",
            "-f",
            "lavfi",
            "-i",
            (
                "aevalsrc=if(lt(t\\,0.35)\\,0.99\\,"
                "if(lt(t\\,0.5)\\,0\\,-0.99))|"
                "if(lt(t\\,0.35)\\,-0.495\\,"
                "if(lt(t\\,0.5)\\,0\\,0.495)):"
                "sample_rate=48000:duration=0.75:channel_layout=stereo"
            ),
            "-map",
            "0:v:0",
            "-map",
            "1:a:0",
            "-c:v",
            "mpeg4",
            "-q:v",
            "5",
            "-c:a",
            "mp3",
            output,
        ],
        check=True,
    )

    report = (
        engine.qc(project)
        .run(
            QCRequest(
                output_path=output,
                delivery_profile_id="preview",
                scopes=(QCScope.VIDEO, QCScope.AUDIO, QCScope.DELIVERY),
                report_dir=tmp_path / "adversarial-qc",
                expected_output_sha256="0" * 64,
                expected_caption_paths=(tmp_path / "missing.vtt",),
                policy=QCPolicy(
                    black_min_duration_seconds=0.2,
                    freeze_min_duration_seconds=0.2,
                    silence_min_duration_seconds=0.1,
                    audio_video_tolerance_samples=128,
                    channel_imbalance_db=3,
                    mono_cancellation_db=3,
                    boundary_pop_threshold=0.2,
                    generate_contact_sheet=False,
                ),
            )
        )
        .report
    )
    codes = {finding.code for finding in report.findings}
    frozen_output = tmp_path / "frozen.mkv"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "testsrc2=size=320x180:rate=24:duration=0.25",
            "-f",
            "lavfi",
            "-i",
            "color=c=red:size=320x180:rate=24:duration=0.5",
            "-f",
            "lavfi",
            "-i",
            "testsrc2=size=320x180:rate=24:duration=0.25",
            "-filter_complex",
            "[0:v][1:v][2:v]concat=n=3:v=1:a=0[outv]",
            "-map",
            "[outv]",
            "-c:v",
            "ffv1",
            frozen_output,
        ],
        check=True,
    )
    frozen_report = (
        engine.qc(project)
        .run(
            QCRequest(
                output_path=frozen_output,
                delivery_profile_id="preview",
                scopes=(QCScope.VIDEO,),
                report_dir=tmp_path / "frozen-qc",
                policy=QCPolicy(
                    black_min_duration_seconds=0.2,
                    freeze_min_duration_seconds=0.2,
                    generate_contact_sheet=False,
                ),
            )
        )
        .report
    )
    codes.update(finding.code for finding in frozen_report.findings)

    assert {
        "video.wrong_dimensions",
        "video.wrong_frame_rate",
        "video.invalid_color_tags",
        "video.unexpected_black",
        "video.unexpected_freeze",
        "audio.loudness_failure",
        "audio.true_peak_failure",
        "audio.loudness_range_failure",
        "audio.clipping",
        "audio.unexpected_silence",
        "audio.channel_imbalance",
        "audio.mono_compatibility",
        "audio.video_duration_mismatch",
        "audio.boundary_pop",
        "delivery.wrong_video_codec",
        "delivery.wrong_audio_codec",
        "delivery.checksum_mismatch",
        "delivery.caption_sidecar_missing",
        "delivery.fast_start_missing",
        "delivery.wrong_duration",
    } <= codes


@pytest.mark.integration
def test_ingest_qc_reports_real_source_identity_stream_and_probe_failures(
    tmp_path: Path,
    qc_source: Path,
) -> None:
    engine = VideoEngine(tmp_path)
    project = engine.create_project("QC ingest failures", width=320, height=180)
    changed = tmp_path / "changed.mp4"
    shutil.copy2(qc_source, changed)
    changed_record = engine.media().import_media(changed)
    project.media.append(engine.media().to_media_reference(changed_record))
    with changed.open("ab") as destination:
        destination.write(b"post-import mutation")

    audio_only = tmp_path / "audio-only.wav"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:sample_rate=48000:duration=1",
            "-c:a",
            "pcm_s16le",
            audio_only,
        ],
        check=True,
    )
    audio_record = engine.media().import_media(audio_only)
    project.media.append(engine.media().to_media_reference(audio_record))

    video_only = tmp_path / "video-only.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            qc_source,
            "-an",
            "-c:v",
            "copy",
            video_only,
        ],
        check=True,
    )
    video_record = engine.media().import_media(video_only)
    project.media.append(engine.media().to_media_reference(video_record))

    still = tmp_path / "still.png"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=c=blue:size=320x180",
            "-frames:v",
            "1",
            still,
        ],
        check=True,
    )
    still_record = engine.media().import_media(still)
    project.media.append(engine.media().to_media_reference(still_record))

    corrupt = tmp_path / "corrupt.mp4"
    corrupt.write_bytes(b"not a media container")
    project.media.extend(
        [
            MediaReference(id="missing-media", uri=str(tmp_path / "missing.mp4")),
            MediaReference(id="offline-media", uri=str(tmp_path / "offline.mp4"), offline=True),
            MediaReference(id="corrupt-media", uri=str(corrupt)),
        ]
    )
    full_range = TimeRange(start=RationalTime.zero(), duration=RationalTime(value=1, timescale=1))
    project.sequence().timeline.tracks.extend(
        [
            VideoTrack(
                id="video-sources",
                items=[
                    Clip(
                        id="changed-source",
                        media_reference_id=changed_record.id,
                        timeline_range=full_range,
                        source_range=full_range,
                    ),
                    Clip(
                        id="audio-used-as-video",
                        media_reference_id=audio_record.id,
                        timeline_range=full_range,
                        source_range=full_range,
                        source_audio_enabled=False,
                    ),
                    Clip(
                        id="durationless-still-as-video",
                        media_reference_id=still_record.id,
                        timeline_range=full_range,
                        source_range=full_range,
                        source_audio_enabled=False,
                    ),
                ],
            ),
            AudioTrack(
                id="audio-sources",
                items=[
                    AudioClip(
                        id="video-used-as-audio",
                        media_reference_id=video_record.id,
                        timeline_range=full_range,
                        source_range=full_range,
                    )
                ],
            ),
        ]
    )

    report = (
        engine.qc(project)
        .run(
            QCRequest(
                scopes=(QCScope.INGEST,),
                report_dir=tmp_path / "ingest-failures",
                policy=QCPolicy(decode_all_sources=False, generate_contact_sheet=False),
            )
        )
        .report
    )
    codes = {finding.code for finding in report.findings}

    assert {
        "ingest.hash_mismatch",
        "ingest.missing_video_stream",
        "ingest.missing_audio_stream",
        "ingest.bad_duration",
        "ingest.media_missing",
        "ingest.media_offline",
        "ingest.probe_failed",
    } <= codes


@pytest.mark.integration
def test_qc_cli_emits_machine_readable_delivery_report(
    tmp_path: Path,
    qc_source: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    _, project_path, output = _render_fixture(tmp_path, qc_source)
    exit_code = main(
        [
            "qc",
            str(project_path),
            "--output",
            str(output),
            "--scope",
            "delivery",
            "--no-contact-sheet",
            "--report-dir",
            str(tmp_path / "cli-qc"),
            "--json",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["ok"] is True
    assert payload["status"] == "passed"
    assert Path(payload["report_json"]).is_file()


@pytest.mark.integration
def test_qc_and_final_render_cli_use_machine_readable_approval(
    tmp_path: Path,
    qc_source: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    _, project_path, output = _render_fixture(tmp_path, qc_source)
    qc_exit = main(
        [
            "qc",
            str(project_path),
            "--output",
            str(output),
            "--report-dir",
            str(tmp_path / "approved-qc"),
            "--approve-by",
            "cli-reviewer",
            "--approval-notes",
            "Reviewed all contact-sheet frames.",
            "--json",
        ]
    )
    qc_payload = json.loads(capsys.readouterr().out)
    assert qc_exit == 0
    assert qc_payload["approval"]["approval"]["reviewed_by"] == "cli-reviewer"
    approval_path = Path(qc_payload["approval"]["path"])

    final = tmp_path / "cli-final.mp4"
    render_exit = main(
        [
            "render",
            "final",
            str(project_path),
            str(final),
            "--approval",
            str(approval_path),
            "--json",
        ]
    )
    render_payload = json.loads(capsys.readouterr().out)
    assert render_exit == 0
    assert render_payload["ok"] is True
    assert final.is_file()


@pytest.mark.integration
def test_ingest_accepts_durationless_image_used_as_timeline_still(tmp_path: Path) -> None:
    image = tmp_path / "still.png"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=c=red:size=96x54",
            "-frames:v",
            "1",
            image,
        ],
        check=True,
    )
    engine = VideoEngine(tmp_path)
    project = engine.create_project("Still ingest", width=96, height=54)
    record = engine.media().import_media(image)
    project.media.append(engine.media().to_media_reference(record))
    project.sequence().timeline.tracks.append(
        VideoTrack(
            id="v1",
            items=[
                StillImageClip(
                    id="still-1",
                    media_reference_id=record.id,
                    timeline_range=TimeRange(
                        start=RationalTime.zero(),
                        duration=RationalTime(value=1, timescale=1),
                    ),
                )
            ],
        )
    )

    report = (
        engine.qc(project)
        .run(
            QCRequest(
                scopes=(QCScope.INGEST,),
                report_dir=tmp_path / "still-qc",
            )
        )
        .report
    )

    assert report.status is QCOverallStatus.PASSED
    assert not any(finding.code == "ingest.bad_duration" for finding in report.findings)
