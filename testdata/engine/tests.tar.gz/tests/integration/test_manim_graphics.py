from __future__ import annotations

import os
from pathlib import Path

import pytest

from video_engine.config import EngineConfig
from video_engine.core.time import FrameRate, RationalTime
from video_engine.graphics.models import GraphicAsset, GraphicRenderer
from video_engine.process import CommandRunner
from video_engine.render.backends.manim import ManimBackend
from video_engine.render.cache import sha256_file
from video_engine.render.nodes import ArtifactType, MotionGraphicNode

pytestmark = pytest.mark.skipif(
    os.environ.get("VIDEO_ENGINE_RUN_MANIM_INTEGRATION") != "1",
    reason="real Manim execution is opt-in",
)


def test_manim_backend_renders_valid_alpha_range(tmp_path: Path) -> None:
    script = tmp_path / "scene.py"
    script.write_text(
        """from manim import *

class EngineScene(Scene):
    def construct(self):
        circle = Circle(radius=1.0, color=WHITE, fill_opacity=0.8)
        self.play(FadeIn(circle), run_time=0.5)
        self.wait(0.5)
""",
        encoding="utf-8",
    )
    node = MotionGraphicNode(
        id="manim",
        artifact_type=ArtifactType.VIDEO,
        component_id="manim_scene",
        component_version="1.0.0",
        component_digest="a" * 64,
        renderer=GraphicRenderer.MANIM,
        props={"source_asset_id": "source", "scene_name": "EngineScene"},
        assets=(
            GraphicAsset(
                id="source",
                source_path=script,
                sha256=sha256_file(script),
                media_type="data",
                staged_name="scene.py",
            ),
        ),
        duration=RationalTime(value=1, timescale=1),
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
        composition_duration_frames=24,
        render_duration_frames=24,
        transparent=True,
    )
    work_dir = tmp_path / "work"
    work_dir.mkdir()
    backend = ManimBackend(
        EngineConfig(
            manim_path=str(Path("tools/video-use/vendor/manim-video/.venv/bin/manim").resolve())
        ),
        Path.cwd(),
    )
    execution = backend.execute(node, (), work_dir / "output.mov", work_dir)
    assert execution.path.is_file()
    assert execution.metadata["renderer"] == "manim"
    assert execution.metadata["frame_count"] == 24
    assert execution.metadata["has_alpha"] is True


@pytest.mark.skipif(
    os.environ.get("VIDEO_ENGINE_RUN_MANIM_LATEX_INTEGRATION") != "1",
    reason="real Manim MathTex execution is opt-in",
)
def test_manim_mathtex_toolchain(tmp_path: Path) -> None:
    manim = Path(os.environ["VIDEO_ENGINE_MANIM"]).resolve()
    script = tmp_path / "math_scene.py"
    script.write_text(
        """from manim import *

class MathScene(Scene):
    def construct(self):
        equation = MathTex(r"x^2 + y^2 = 1")
        self.add(equation)
        self.wait(0.25)
""",
        encoding="utf-8",
    )
    media_dir = tmp_path / "media"
    CommandRunner().run(
        [
            manim,
            "render",
            "--disable_caching",
            "--progress_bar",
            "none",
            "--media_dir",
            media_dir,
            "--fps",
            "24",
            "--resolution",
            "320,180",
            script,
            "MathScene",
        ],
        timeout=180,
    )
    assert any(media_dir.rglob("MathScene.mp4"))
