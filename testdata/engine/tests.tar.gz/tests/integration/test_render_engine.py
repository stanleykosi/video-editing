from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

import pytest
import soundfile as sf
from PIL import Image, ImageChops, ImageStat

from tests.support.golden_metrics import frame_dhash, hamming_distance
from video_engine.api.engine import VideoEngine
from video_engine.cli.main import main
from video_engine.core.schema import (
    AdjustmentClip,
    AdjustmentTrack,
    AudioBus,
    AudioClip,
    AudioTrack,
    CaptionCue,
    CaptionStyle,
    CaptionStyleOverride,
    CaptionTrack,
    CaptionWord,
    Clip,
    ColorSpace,
    DeliveryProfile,
    Effect,
    EffectKind,
    GraphicsTrack,
    Interpolation,
    Keyframe,
    NestedSequenceClip,
    Retime,
    Sequence,
    SequenceSnapshot,
    SpeedRampPoint,
    Timeline,
    Transition,
    TransitionKind,
    VideoTrack,
)
from video_engine.core.time import FrameRate, RationalRate, RationalTime, TimeRange
from video_engine.errors import EngineError, ErrorCode
from video_engine.media import identity as source_identity_module
from video_engine.render.backends.base import BackendExecution, RenderBackend
from video_engine.render.backends.ffmpeg import FFmpegBackend
from video_engine.render.backends.registry import BackendRegistry
from video_engine.render.checkpoints import RenderCheckpointStore
from video_engine.render.effects import parse_audio_processor
from video_engine.render.models import RenderArtifact, RenderMode, RenderRequest
from video_engine.render.nodes import (
    ALL_NODE_KINDS,
    ArtifactType,
    AudioProcessNode,
    RenderNode,
    SpeedRampNode,
)
from video_engine.render.service import RenderService
from video_engine.visual.models import (
    NormalizedBox,
    ReframeSettings,
    TrackingBinding,
    TrackingGeometry,
    TrackingObservation,
    TrackingRequest,
)


def rt(value: int, timescale: int = 24) -> RationalTime:
    return RationalTime(value=value, timescale=timescale)


def probe(path: Path) -> dict[str, Any]:
    result = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_format",
            "-show_streams",
            "-of",
            "json",
            str(path),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(result.stdout)


def create_color_source(path: Path, color: str) -> None:
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            f"color=c={color}:s=320x180:r=24:d=1",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(path),
        ],
        check=True,
    )


def create_fit_probe_source(path: Path) -> None:
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=c=black:s=240x240:r=24:d=1",
            "-vf",
            "drawbox=x=90:y=90:w=60:h=60:color=white:t=fill",
            "-c:v",
            "libx264",
            "-preset",
            "ultrafast",
            "-pix_fmt",
            "yuv420p",
            str(path),
        ],
        check=True,
    )


def create_hdr_color_source(path: Path, transfer: str) -> None:
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=c=gray:s=320x180:r=24:d=1",
            "-vf",
            "format=yuv420p10le",
            "-c:v",
            "ffv1",
            "-level",
            "3",
            "-pix_fmt",
            "yuv420p10le",
            "-color_primaries",
            "bt2020",
            "-color_trc",
            transfer,
            "-colorspace",
            "bt2020nc",
            str(path),
        ],
        check=True,
    )


def sample_rgb(path: Path, x: int, y: int, *, timestamp: float = 0.5) -> tuple[int, int, int]:
    result = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-ss",
            str(timestamp),
            "-i",
            str(path),
            "-vf",
            f"format=rgb24,crop=1:1:{x}:{y}",
            "-frames:v",
            "1",
            "-f",
            "rawvideo",
            "-",
        ],
        check=True,
        capture_output=True,
    )
    return tuple(result.stdout[:3])  # type: ignore[return-value]


def extract_frame(path: Path, timestamp: float, output: Path) -> None:
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-ss",
            str(timestamp),
            "-i",
            str(path),
            "-frames:v",
            "1",
            str(output),
        ],
        check=True,
    )


def decoded_frame_hashes(path: Path) -> list[str]:
    result = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(path),
            "-map",
            "0:v:0",
            "-f",
            "framemd5",
            "-",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    return [
        line.rsplit(",", 1)[-1].strip()
        for line in result.stdout.splitlines()
        if line and not line.startswith("#")
    ]


def decoded_rgb_frames(path: Path, width: int, height: int) -> list[bytes]:
    result = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(path),
            "-map",
            "0:v:0",
            "-vf",
            "format=rgb24",
            "-fps_mode",
            "passthrough",
            "-f",
            "rawvideo",
            "-",
        ],
        check=True,
        capture_output=True,
    )
    frame_bytes = width * height * 3
    assert len(result.stdout) % frame_bytes == 0
    return [
        result.stdout[offset : offset + frame_bytes]
        for offset in range(0, len(result.stdout), frame_bytes)
    ]


def rgb_frame_mae(left: bytes, right: bytes) -> float:
    assert len(left) == len(right)
    return sum(abs(a - b) for a, b in zip(left, right, strict=True)) / len(left)


def decode_audio(path: Path, output: Path) -> tuple[Any, int]:
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(path),
            "-map",
            "0:a:0",
            "-c:a",
            "pcm_f32le",
            str(output),
        ],
        check=True,
    )
    return sf.read(output, dtype="float32")


@pytest.fixture(scope="module")
def render_source(tmp_path_factory: pytest.TempPathFactory) -> Path:
    directory = tmp_path_factory.mktemp("render-source")
    output = directory / "source.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "testsrc2=size=320x180:rate=24:duration=2",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:sample_rate=48000:duration=2",
            "-filter_complex",
            "[1:a]aformat=channel_layouts=stereo[a]",
            "-map",
            "0:v:0",
            "-map",
            "[a]",
            "-c:v",
            "libx264",
            "-preset",
            "ultrafast",
            "-g",
            "48",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-ar",
            "48000",
            "-shortest",
            str(output),
        ],
        check=True,
    )
    return output


def build_project(engine: VideoEngine, source: Path):  # type: ignore[no-untyped-def]
    project = engine.create_project(
        "Render Integration",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    record = engine.media().import_media(source)
    project.media.append(engine.media().to_media_reference(record))
    clip_range = TimeRange(start=rt(0), duration=rt(36))
    clip = Clip(
        id="clip-main",
        media_reference_id=record.id,
        timeline_range=clip_range,
        source_range=TimeRange(start=rt(6), duration=rt(36)),
        effects=[
            Effect(
                id="grade",
                kind=EffectKind.COLOR_GRADE,
                parameters={"contrast": 1.04, "saturation": 0.96},
            )
        ],
    )
    captions = CaptionCue(
        id="caption-main",
        text="EXACT CUT\nCAPTION LAST",
        timeline_range=TimeRange(start=rt(6), duration=rt(18)),
    )
    project.sequence().timeline.tracks = [
        VideoTrack(id="v1", items=[clip]),
        CaptionTrack(id="c1", language="en", items=[captions]),
    ]
    return project


class FailOnceFFmpegBackend(RenderBackend):
    """Inject one failure without changing the backend's cache identity."""

    name = FFmpegBackend.name
    version = FFmpegBackend.version
    capabilities = ALL_NODE_KINDS

    def __init__(self, delegate: FFmpegBackend) -> None:
        self.delegate = delegate
        self.fail_node_id: str | None = None
        self.failed = False

    @property
    def tool_fingerprint(self) -> str:
        return self.delegate.tool_fingerprint

    def can_execute(self, node: RenderNode) -> bool:
        return self.delegate.can_execute(node)

    def output_suffix(self, node: RenderNode) -> str:
        return self.delegate.output_suffix(node)

    def execute(
        self,
        node: RenderNode,
        inputs: tuple[RenderArtifact, ...],
        output_path: Path,
        work_dir: Path,
    ) -> BackendExecution:
        if node.id == self.fail_node_id and not self.failed:
            self.failed = True
            raise EngineError(
                ErrorCode.RENDER_FAILED,
                "intentional real-backend recovery failure",
                context={"node_id": node.id},
            )
        return self.delegate.execute(node, inputs, output_path, work_dir)


@pytest.mark.integration
def test_ffmpeg_render_exact_metadata_caption_and_cache(
    tmp_path: Path,
    render_source: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    engine = VideoEngine(tmp_path)
    project = build_project(engine, render_source)
    project_path = engine.save_project(project)
    output = tmp_path / "preview.mp4"
    service = engine.renderer(project)
    request = RenderRequest(output_path=output, mode=RenderMode.PREVIEW)

    first = service.render(request)
    assert first.output_path.is_file()
    assert first.manifest_path.is_file()
    assert first.executed_nodes > 10
    assert first.cache_hits == 0
    metadata = probe(output)
    video = next(stream for stream in metadata["streams"] if stream["codec_type"] == "video")
    audio = next(stream for stream in metadata["streams"] if stream["codec_type"] == "audio")
    assert (video["width"], video["height"]) == (320, 180)
    assert video["avg_frame_rate"] == "24/1"
    assert video["pix_fmt"] == "yuv420p"
    assert audio["sample_rate"] == "48000"
    assert abs(float(metadata["format"]["duration"]) - 1.5) <= 0.03

    second = service.render(
        request.model_copy(update={"output_path": tmp_path / "preview-cached.mp4"})
    )
    assert second.cache_hits >= first.executed_nodes - 2
    assert second.executed_nodes == 2
    assert second.manifest.output_sha256 == first.manifest.output_sha256

    cli_output = tmp_path / "preview-cli.mp4"
    assert (
        main(
            [
                "render",
                "preview",
                str(project_path),
                str(cli_output),
                "--json",
            ]
        )
        == 0
    )
    cli_result = json.loads(capsys.readouterr().out)
    assert cli_result["ok"] is True
    assert cli_result["output_sha256"] == first.manifest.output_sha256
    assert cli_result["executed_nodes"] == 2


@pytest.mark.integration
def test_draft_cli_renders_bounded_delivery_profile(
    tmp_path: Path,
    render_source: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    engine = VideoEngine(tmp_path)
    project = build_project(engine, render_source)
    project.delivery_profiles = [
        profile.model_copy(update={"width": 1920, "height": 1080})
        for profile in project.delivery_profiles
    ]
    project_path = engine.save_project(project)
    output = tmp_path / "draft.mp4"

    assert main(["render", "draft", str(project_path), str(output), "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    metadata = probe(output)
    video = next(stream for stream in metadata["streams"] if stream["codec_type"] == "video")
    manifest = json.loads(Path(payload["manifest"]).read_text(encoding="utf-8"))

    assert payload["ok"] is True
    assert (video["width"], video["height"]) == (1280, 720)
    assert video["avg_frame_rate"] == "24/1"
    assert manifest["mode"] == "draft"
    assert manifest["metadata"]["delivery_profile"]["id"] == "preview-draft"


@pytest.mark.integration
def test_freeze_frame_is_exact_across_full_sectioned_and_range_renders(
    tmp_path: Path,
    render_source: Path,
) -> None:
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Freeze Integration",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    record = engine.media().import_media(render_source)
    project.media.append(engine.media().to_media_reference(record))
    item_range = TimeRange(start=rt(0), duration=rt(24))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="picture",
            items=[
                Clip(
                    id="freeze-source",
                    media_reference_id=record.id,
                    timeline_range=item_range,
                    source_range=item_range,
                    effects=[
                        Effect(
                            id="hold-frame",
                            kind=EffectKind.FREEZE,
                            parameters={
                                "frame_time": rt(8).model_dump(mode="json"),
                                "duration": rt(24).model_dump(mode="json"),
                            },
                        )
                    ],
                )
            ],
        )
    ]
    reference_project = project.model_copy(deep=True)
    reference_track = reference_project.sequence().timeline.tracks[0]
    assert isinstance(reference_track, VideoTrack)
    reference_clip = reference_track.items[0]
    assert isinstance(reference_clip, Clip)
    reference_clip.effects = []
    reference = engine.renderer(reference_project).render(
        RenderRequest(
            output_path=tmp_path / "freeze-reference.mp4",
            sectioning=False,
            use_cache=False,
        )
    )
    service = engine.renderer(project)
    full = service.render(
        RenderRequest(
            output_path=tmp_path / "freeze-full.mp4",
            sectioning=False,
            use_cache=False,
        )
    )
    sectioned = service.render(
        RenderRequest(
            output_path=tmp_path / "freeze-sectioned.mp4",
            section_duration=rt(12),
            use_cache=False,
        )
    )
    ranged = service.render(
        RenderRequest(
            output_path=tmp_path / "freeze-range.mp4",
            mode=RenderMode.RANGE,
            timeline_range=TimeRange(start=rt(6), duration=rt(12)),
            sectioning=False,
            use_cache=False,
        )
    )

    full_hashes = [frame_dhash(full.output_path, index) for index in range(24)]
    sectioned_hashes = [frame_dhash(sectioned.output_path, index) for index in range(24)]
    range_hashes = [frame_dhash(ranged.output_path, index) for index in range(12)]
    assert len(set(full_hashes)) == 1
    reference_rgb = decoded_rgb_frames(reference.output_path, 320, 180)
    frozen_rgb = decoded_rgb_frames(full.output_path, 320, 180)
    distances = [rgb_frame_mae(frozen_rgb[0], frame) for frame in reference_rgb]
    assert min(range(len(distances)), key=distances.__getitem__) == 8
    assert distances[8] < distances[7]
    assert full_hashes[0] == frame_dhash(reference.output_path, 8)
    assert sectioned_hashes == full_hashes
    assert range_hashes == full_hashes[6:18]
    full_freeze = next(
        record for record in full.manifest.records if record.node_type.value == "freeze"
    )
    assert full_freeze.artifact_path is not None
    assert len(set(decoded_frame_hashes(full_freeze.artifact_path))) == 1

    changed = project.model_copy(deep=True)
    changed_track = changed.sequence().timeline.tracks[0]
    assert isinstance(changed_track, VideoTrack)
    changed_clip = changed_track.items[0]
    assert isinstance(changed_clip, Clip)
    changed_clip.effects[0] = changed_clip.effects[0].model_copy(
        update={
            "parameters": {
                "frame_time": rt(16).model_dump(mode="json"),
                "duration": rt(24).model_dump(mode="json"),
            }
        }
    )
    changed_result = engine.renderer(changed).render(
        RenderRequest(
            output_path=tmp_path / "freeze-changed.mp4",
            sectioning=False,
        )
    )
    changed_hashes = [frame_dhash(changed_result.output_path, index) for index in range(24)]
    assert len(set(changed_hashes)) == 1
    assert changed_hashes[0] != full_hashes[0]
    changed_freeze = next(
        record for record in changed_result.manifest.records if record.node_type.value == "freeze"
    )
    assert not changed_freeze.cached


@pytest.mark.integration
@pytest.mark.parametrize(
    ("retime", "source_duration"),
    [
        pytest.param(Retime(), rt(24), id="constant-one"),
        pytest.param(Retime(reverse=True), rt(24), id="reverse"),
        pytest.param(
            Retime(rate=RationalRate(numerator=3, denominator=2)),
            rt(36),
            id="constant-three-halves",
        ),
        pytest.param(
            Retime(
                speed_ramp=(
                    SpeedRampPoint(
                        time=rt(0),
                        rate=RationalRate(numerator=1),
                    ),
                    SpeedRampPoint(
                        time=rt(24),
                        rate=RationalRate(numerator=2),
                    ),
                )
            ),
            rt(36),
            id="linear-speed-ramp",
        ),
    ],
)
def test_freeze_selects_the_exact_rendered_frame_through_retime(
    tmp_path: Path,
    render_source: Path,
    retime: Retime,
    source_duration: RationalTime,
) -> None:
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Freeze Retime",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    media = engine.media().import_media(render_source)
    project.media.append(engine.media().to_media_reference(media))
    clip = Clip(
        id="retimed-source",
        media_reference_id=media.id,
        timeline_range=TimeRange(start=rt(0), duration=rt(24)),
        source_range=TimeRange(start=rt(0), duration=source_duration),
        source_audio_enabled=False,
        retime=retime,
    )
    project.sequence().timeline.tracks = [VideoTrack(id="picture", items=[clip])]
    reference = engine.renderer(project).render(
        RenderRequest(
            output_path=tmp_path / "reference.mp4",
            sectioning=False,
            use_cache=False,
        )
    )

    frozen_project = project.model_copy(deep=True)
    frozen_track = frozen_project.sequence().timeline.tracks[0]
    assert isinstance(frozen_track, VideoTrack)
    frozen_clip = frozen_track.items[0]
    assert isinstance(frozen_clip, Clip)
    frozen_clip.effects = [
        Effect(
            id="hold",
            kind=EffectKind.FREEZE,
            parameters={
                "frame_time": rt(8).model_dump(mode="json"),
                "duration": rt(24).model_dump(mode="json"),
            },
        )
    ]
    frozen = engine.renderer(frozen_project).render(
        RenderRequest(
            output_path=tmp_path / "frozen.mp4",
            sectioning=False,
            use_cache=False,
        )
    )
    reference_rgb = decoded_rgb_frames(reference.output_path, 320, 180)
    frozen_rgb = decoded_rgb_frames(frozen.output_path, 320, 180)
    distances = [rgb_frame_mae(frozen_rgb[0], frame) for frame in reference_rgb]
    assert min(range(len(distances)), key=distances.__getitem__) == 8
    assert distances[8] < distances[7]
    assert len({frame_dhash(frozen.output_path, frame) for frame in range(24)}) == 1


@pytest.mark.integration
@pytest.mark.parametrize(
    ("profile_id", "dimensions", "fit"),
    [
        ("horizontal", (320, 180), "stretch"),
        ("vertical", (180, 320), "cover"),
        ("square", (180, 180), "contain"),
    ],
)
def test_horizontal_vertical_and_square_delivery_profiles_render_exactly(
    tmp_path: Path,
    render_source: Path,
    profile_id: str,
    dimensions: tuple[int, int],
    fit: str,
) -> None:
    engine = VideoEngine(tmp_path / profile_id)
    project = engine.create_project(
        "Delivery Formats",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    source = render_source
    if profile_id in {"horizontal", "vertical"}:
        source = tmp_path / f"{profile_id}-fit-probe.mp4"
        create_fit_probe_source(source)
    record = engine.media().import_media(source)
    project.media.append(engine.media().to_media_reference(record))
    item_range = TimeRange(start=rt(0), duration=rt(24))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="picture",
            items=[
                Clip(
                    id="format-source",
                    media_reference_id=record.id,
                    timeline_range=item_range,
                    source_range=item_range,
                    source_audio_enabled=False,
                )
            ],
        )
    ]
    project.delivery_profiles = [
        DeliveryProfile(
            id=profile_id,
            name=profile_id.title(),
            width=dimensions[0],
            height=dimensions[1],
            frame_rate=FrameRate(numerator=24),
            fit=fit,  # type: ignore[arg-type]
        )
    ]
    output = tmp_path / f"{profile_id}.mp4"
    result = engine.renderer(project).render(
        RenderRequest(
            output_path=output,
            delivery_profile_id=profile_id,
            sectioning=False,
        )
    )

    video = next(
        stream for stream in probe(result.output_path)["streams"] if stream["codec_type"] == "video"
    )
    assert (video["width"], video["height"]) == dimensions
    assert video["avg_frame_rate"] == "24/1"
    assert video["sample_aspect_ratio"] == "1:1"
    assert len(decoded_frame_hashes(result.output_path)) == 24
    center = sample_rgb(
        result.output_path,
        dimensions[0] // 2,
        dimensions[1] // 2,
    )
    assert max(center) > 40
    if profile_id == "square":
        top_padding = sample_rgb(result.output_path, dimensions[0] // 2, 10)
        assert max(top_padding) < 12
    elif profile_id == "vertical":
        cover_only = sample_rgb(result.output_path, 120, 160)
        assert min(cover_only) > 180
    else:
        stretched_width = sample_rgb(result.output_path, 190, 90)
        stretched_height = sample_rgb(result.output_path, 160, 125)
        assert min(stretched_width) > 180
        assert max(stretched_height) < 30


@pytest.mark.integration
def test_real_ffmpeg_render_recovers_from_completed_section_cache(
    tmp_path: Path, render_source: Path
) -> None:
    engine = VideoEngine(tmp_path)
    engine.config.max_workers = 1
    project = build_project(engine, render_source)
    request = RenderRequest(
        output_path=tmp_path / "failed.mp4",
        section_duration=rt(12),
        use_cache=False,
        resume=True,
    )
    delegate = FFmpegBackend(engine.config.materialize(tmp_path))
    injected = FailOnceFFmpegBackend(delegate)
    registry = BackendRegistry()
    registry.register(injected)
    failing_service = RenderService(project, tmp_path, engine.config, registry=registry)
    compiled = failing_service.compile(request)
    assert len(compiled.section_outputs) == 3
    injected.fail_node_id = compiled.section_outputs[1].video_node_id

    with pytest.raises(EngineError, match="render graph execution failed"):
        failing_service.render(request)

    recovery_service = RenderService(project, tmp_path, engine.config)
    recovered = recovery_service.render(
        request.model_copy(update={"output_path": tmp_path / "recovered.mp4"})
    )
    checkpoint_metadata = recovered.manifest.metadata["checkpoint"]
    assert isinstance(checkpoint_metadata, dict)
    checkpoint = RenderCheckpointStore(
        engine.config.materialize(tmp_path).cache_dir / "render-checkpoints"
    ).load(str(checkpoint_metadata["identity"]))
    assert checkpoint is not None
    assert [attempt.status for attempt in checkpoint.attempts] == [
        "failed",
        "succeeded",
    ]
    assert recovered.cache_hits > 0
    assert recovered.manifest.output_sha256 == checkpoint.output_sha256

    clean = recovery_service.render(
        request.model_copy(
            update={
                "output_path": tmp_path / "clean.mp4",
                "resume": False,
            }
        )
    )
    assert recovered.manifest.output_sha256 == clean.manifest.output_sha256
    assert recovered.output_path.read_bytes() == clean.output_path.read_bytes()


@pytest.mark.integration
def test_sectioned_render_matches_unsectioned_video_and_audio_boundaries(
    tmp_path: Path, render_source: Path
) -> None:
    engine = VideoEngine(tmp_path)
    project = build_project(engine, render_source)
    service = engine.renderer(project)
    unsectioned = tmp_path / "unsectioned.mp4"
    sectioned = tmp_path / "sectioned.mp4"

    service.render(RenderRequest(output_path=unsectioned, sectioning=False, use_cache=False))
    result = service.render(
        RenderRequest(
            output_path=sectioned,
            section_duration=rt(12),
            use_cache=False,
        )
    )

    sections = result.manifest.metadata["sections"]
    assert isinstance(sections, list)
    assert len(sections) == 3
    assert probe(sectioned)["format"]["duration"] == probe(unsectioned)["format"]["duration"]
    for timestamp in (0.25, 0.49, 0.5, 0.51, 0.99, 1.0, 1.01, 1.25):
        assert sample_rgb(sectioned, 160, 90, timestamp=timestamp) == pytest.approx(
            sample_rgb(unsectioned, 160, 90, timestamp=timestamp), abs=3
        )
    sectioned_audio, sectioned_rate = decode_audio(sectioned, tmp_path / "sectioned-audio.wav")
    unsectioned_audio, unsectioned_rate = decode_audio(
        unsectioned, tmp_path / "unsectioned-audio.wav"
    )
    assert sectioned_rate == unsectioned_rate == 48_000
    assert sectioned_audio.shape == unsectioned_audio.shape
    assert abs(sectioned_audio - unsectioned_audio).max() < 1e-5


@pytest.mark.integration
def test_caption_edit_invalidates_only_its_render_section(
    tmp_path: Path,
    render_source: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    engine = VideoEngine(tmp_path)
    original = build_project(engine, render_source)
    caption_track = next(
        track for track in original.sequence().timeline.tracks if isinstance(track, CaptionTrack)
    )
    cue = next(item for item in caption_track.items if isinstance(item, CaptionCue))
    cue.timeline_range = TimeRange(start=rt(12), duration=rt(12))
    first_request = RenderRequest(
        output_path=tmp_path / "caption-sections-first.mp4",
        section_duration=rt(12),
    )
    first_service = engine.renderer(original)
    first_result = first_service.render(first_request)
    source_identity_path = tmp_path / ".video-engine" / "source-identities.json"
    source_identity_before = source_identity_path.read_bytes()

    def reject_rehash(path: Path) -> str:
        raise AssertionError(f"unchanged source was redundantly rehashed: {path}")

    monkeypatch.setattr(source_identity_module, "_sha256_file", reject_rehash)

    changed = original.model_copy(deep=True)
    changed_caption_track = next(
        track for track in changed.sequence().timeline.tracks if isinstance(track, CaptionTrack)
    )
    changed_cue = next(item for item in changed_caption_track.items if isinstance(item, CaptionCue))
    changed_cue.text = "ONLY THE MIDDLE SECTION CHANGED"
    second_request = first_request.model_copy(
        update={"output_path": tmp_path / "caption-sections-second.mp4"}
    )
    second_service = engine.renderer(changed)
    compiled = second_service.compile(second_request)

    result = second_service.render(second_request)

    records = {record.node_id: record for record in result.manifest.records}
    video_roots = [output.video_node_id for output in compiled.section_outputs]
    audio_roots = [output.audio_node_id for output in compiled.section_outputs]
    assert [records[node_id].cached for node_id in video_roots] == [True, False, True]
    assert all(records[node_id].cached for node_id in audio_roots)
    assert result.executed_nodes > 0
    first_hashes = [frame_dhash(first_result.output_path, index) for index in (6, 18, 30)]
    second_hashes = [frame_dhash(result.output_path, index) for index in (6, 18, 30)]
    assert second_hashes[0] == first_hashes[0]
    assert hamming_distance(second_hashes[1], first_hashes[1]) > 0
    assert second_hashes[2] == first_hashes[2]
    assert source_identity_path.read_bytes() == source_identity_before

    partial_project = changed.model_copy(deep=True)
    partial_caption_track = next(
        track
        for track in partial_project.sequence().timeline.tracks
        if isinstance(track, CaptionTrack)
    )
    partial_cue = next(item for item in partial_caption_track.items if isinstance(item, CaptionCue))
    partial_cue.text = "A SECOND MIDDLE-SECTION REVISION"
    partial_service = engine.renderer(partial_project)
    partial_compiled = partial_service.compile(second_request)
    partial_target = partial_compiled.section_outputs[1].video_node_id
    partial = partial_service.execute_partial(second_request, (partial_target,))
    closure = partial_compiled.graph.ancestor_closure((partial_target,))
    assert {record.node_id for record in partial.records} == closure
    target_record = next(record for record in partial.records if record.node_id == partial_target)
    assert not target_record.cached
    caption_nodes = [
        node
        for node in partial_compiled.graph.nodes
        if node.id in closure and node.node_type.value == "caption"
    ]
    assert len(caption_nodes) == 1
    caption_node = caption_nodes[0]
    caption_upstream: set[str] = set()
    for input_id in caption_node.inputs:
        caption_upstream.update(partial_compiled.graph.ancestor_closure((input_id,)))
    assert all(records_id in closure for records_id in caption_upstream)
    partial_records = {record.node_id: record for record in partial.records}
    upstream_misses = {
        node_id: partial_compiled.graph.node(node_id).node_type.value
        for node_id in caption_upstream
        if not partial_records[node_id].cached
    }
    # Decode is a zero-copy source reference and intentionally noncacheable; the
    # patched hash function above proves it did not reread the unchanged source.
    assert set(upstream_misses.values()) <= {"decode"}
    assert len(upstream_misses) == 1
    caption_dependents = {
        node_id
        for node_id in closure
        if caption_node.id in partial_compiled.graph.ancestor_closure((node_id,))
    }
    executed = {record.node_id for record in partial.records if not record.cached}
    assert executed == caption_dependents | set(upstream_misses)
    assert partial.executed_nodes == len(executed)
    repeated = partial_service.execute_partial(second_request, (partial_target,))
    repeated_target = next(
        record for record in repeated.records if record.node_id == partial_target
    )
    assert repeated_target.cached
    assert source_identity_path.read_bytes() == source_identity_before


@pytest.mark.integration
def test_pinned_nested_sequence_renders_historical_revision(tmp_path: Path) -> None:
    red_source = tmp_path / "nested-v1-red.mp4"
    blue_source = tmp_path / "nested-v2-blue.mp4"
    create_color_source(red_source, "red")
    create_color_source(blue_source, "blue")
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Versioned Nested Sequence",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    red = engine.media().import_media(red_source)
    blue = engine.media().import_media(blue_source)
    project.media.extend(
        [engine.media().to_media_reference(red), engine.media().to_media_reference(blue)]
    )
    item_range = TimeRange(start=rt(0), duration=rt(24))
    child_v1 = Sequence(
        id="child",
        name="Reusable Child",
        revision=1,
        timeline=Timeline(
            tracks=[
                VideoTrack(
                    id="child-video",
                    items=[
                        Clip(
                            id="red-v1",
                            media_reference_id=red.id,
                            timeline_range=item_range,
                            source_range=item_range,
                            source_audio_enabled=False,
                        )
                    ],
                )
            ]
        ),
    )
    child_v2 = Sequence(
        id="child",
        name="Reusable Child",
        revision=2,
        timeline=Timeline(
            tracks=[
                VideoTrack(
                    id="child-video",
                    items=[
                        Clip(
                            id="blue-v2",
                            media_reference_id=blue.id,
                            timeline_range=item_range,
                            source_range=item_range,
                            source_audio_enabled=False,
                        )
                    ],
                )
            ]
        ),
    )
    project.sequences.append(child_v2)
    project.sequence_versions.append(SequenceSnapshot.from_sequence(child_v1))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="parent-video",
            items=[
                NestedSequenceClip(
                    id="nested-child",
                    sequence_id="child",
                    sequence_version=1,
                    timeline_range=item_range,
                    source_range=item_range,
                )
            ],
        )
    ]
    project = type(project).model_validate(project.model_dump(mode="python"))
    pinned_output = tmp_path / "pinned-v1.mp4"

    engine.renderer(project).render(RenderRequest(output_path=pinned_output, sectioning=False))

    pinned = sample_rgb(pinned_output, 160, 90)
    assert pinned[0] > 180 and pinned[2] < 30
    parent_track = project.sequence().timeline.tracks[0]
    nested = parent_track.items[0]
    assert isinstance(nested, NestedSequenceClip)
    nested.sequence_version = None
    current_output = tmp_path / "unpinned-v2.mp4"
    engine.renderer(project).render(RenderRequest(output_path=current_output, sectioning=False))
    current = sample_rgb(current_output, 160, 90)
    assert current[2] > 180 and current[0] < 30


@pytest.mark.integration
def test_tracking_split_screen_fallback_renders_subject_panels(tmp_path: Path) -> None:
    source = tmp_path / "split-subjects.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=green:s=320x180:r=24:d=1,drawbox=x=0:y=0:w=160:h=180:color=red:t=fill",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(source),
        ],
        check=True,
    )
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Tracked Split Screen",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    media = engine.media().import_media(source)
    project.media.append(engine.media().to_media_reference(media))
    clip_range = TimeRange(start=rt(0), duration=rt(24))
    clip = Clip(
        id="subjects",
        media_reference_id=media.id,
        timeline_range=clip_range,
        source_range=clip_range,
        source_audio_enabled=False,
    )
    tracking = engine.visual().track(
        TrackingRequest(
            id="two-subjects",
            media_reference_id=media.id,
            source_range=clip_range,
            sample_interval=rt(24),
            manual_observations=(
                TrackingObservation(
                    time=rt(0),
                    subject_id="left",
                    confidence=1,
                    box=NormalizedBox(x=0.05, y=0.1, width=0.35, height=0.8),
                    manual=True,
                ),
                TrackingObservation(
                    time=rt(0),
                    subject_id="right",
                    confidence=1,
                    box=NormalizedBox(x=0.6, y=0.1, width=0.35, height=0.8),
                    manual=True,
                ),
            ),
        )
    )
    plan = engine.visual().plan_reframe(
        tracking,
        source_width=320,
        source_height=180,
        output_width=320,
        output_height=180,
        settings=ReframeSettings(
            multi_subject_fallback="split_screen",
            multi_subject_max_span=0.5,
            smoothing=0,
        ),
    )
    project.sequence().timeline.tracks = list(engine.visual().split_screen_tracks(plan, clip))
    output = tmp_path / "tracked-split-screen.mp4"

    engine.renderer(project).render(RenderRequest(output_path=output))

    left = sample_rgb(output, 80, 90)
    right = sample_rgb(output, 240, 90)
    assert left[0] > 180 and left[1] < 40
    assert right[1] > 80 and right[0] < 40


@pytest.mark.integration
def test_native_word_caption_is_styled_positioned_and_burned(tmp_path: Path) -> None:
    source = tmp_path / "black.mp4"
    create_color_source(source, "black")
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Caption Burn",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    media = engine.media().import_media(source)
    project.media.append(engine.media().to_media_reference(media))
    clip_range = TimeRange(start=rt(0), duration=rt(24))
    project.caption_styles = [
        CaptionStyle(
            id="accent",
            name="Accent",
            primary_color="#FFFFFF",
            highlight_color="#00FF00",
        )
    ]
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="video",
            items=[
                Clip(
                    id="black",
                    media_reference_id=media.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                )
            ],
        ),
        CaptionTrack(
            id="english",
            language="en",
            default_style_id="accent",
            items=[
                CaptionCue(
                    id="visible",
                    text="VISIBLE",
                    timeline_range=TimeRange(start=rt(3), duration=rt(18)),
                    words=[
                        CaptionWord(
                            text="VISIBLE",
                            range=TimeRange(start=rt(3), duration=rt(18)),
                            highlight=True,
                        )
                    ],
                    style_id="accent",
                    position="custom",
                    position_x=0.5,
                    position_y=0.35,
                    style_overrides=CaptionStyleOverride(font_size_px=42),
                )
            ],
        ),
    ]
    output = tmp_path / "caption-burn.mp4"
    engine.renderer(project).render(
        RenderRequest(output_path=output, caption_track_ids=("english",))
    )
    frame = tmp_path / "caption-frame.png"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-ss",
            "0.5",
            "-i",
            str(output),
            "-frames:v",
            "1",
            str(frame),
        ],
        check=True,
    )
    with Image.open(frame).convert("RGB") as image:
        pixels = list(image.crop((50, 10, 270, 90)).getdata())
    green_pixels = sum(1 for red, green, blue in pixels if green > 100 and green > red * 1.4)
    assert green_pixels > 30


@pytest.mark.integration
def test_caption_range_render_matches_full_timeline_state(
    tmp_path: Path, render_source: Path
) -> None:
    engine = VideoEngine(tmp_path)
    project = build_project(engine, render_source)
    caption_track = project.sequence().timeline.tracks[1]
    assert isinstance(caption_track, CaptionTrack)
    caption_track.items = [
        CaptionCue(
            id="karaoke",
            text="ONE, TWO!",
            timeline_range=TimeRange(start=rt(0), duration=rt(36)),
            words=[
                CaptionWord(text="ONE", range=TimeRange(start=rt(0), duration=rt(12))),
                CaptionWord(
                    text="TWO",
                    range=TimeRange(start=rt(12), duration=rt(24)),
                    highlight=True,
                ),
            ],
        )
    ]
    full = tmp_path / "caption-full.mp4"
    range_output = tmp_path / "caption-range.mp4"
    engine.renderer(project).render(RenderRequest(output_path=full))
    engine.renderer(project).render(
        RenderRequest(
            output_path=range_output,
            mode=RenderMode.RANGE,
            timeline_range=TimeRange(start=rt(12), duration=rt(12)),
        )
    )
    full_frame = tmp_path / "caption-full.png"
    range_frame = tmp_path / "caption-range.png"
    extract_frame(full, 0.75, full_frame)
    extract_frame(range_output, 0.25, range_frame)
    with Image.open(full_frame).convert("RGB") as full_image:
        full_pixels = list(full_image.getdata())
    with Image.open(range_frame).convert("RGB") as range_image:
        range_pixels = list(range_image.getdata())
    mean_absolute_error = sum(
        abs(left - right)
        for full_pixel, range_pixel in zip(full_pixels, range_pixels, strict=True)
        for left, right in zip(full_pixel, range_pixel, strict=True)
    ) / (len(full_pixels) * 3)
    assert mean_absolute_error < 2


@pytest.mark.integration
def test_range_render_rebases_timeline_and_source_time(tmp_path: Path, render_source: Path) -> None:
    engine = VideoEngine(tmp_path)
    project = build_project(engine, render_source)
    request = RenderRequest(
        output_path=tmp_path / "range.mp4",
        mode=RenderMode.RANGE,
        timeline_range=TimeRange(start=rt(12), duration=rt(12)),
    )
    result = engine.renderer(project).render(request)
    metadata = probe(result.output_path)
    assert abs(float(metadata["format"]["duration"]) - 0.5) <= 0.03
    assert result.manifest.metadata["timeline_range"] == {
        "start": {"value": 12, "timescale": 24},
        "duration": {"value": 12, "timescale": 24},
    }


@pytest.mark.integration
def test_fixed_canvas_scale_and_position_preserve_transparent_pixels(tmp_path: Path) -> None:
    source = tmp_path / "red.mp4"
    create_color_source(source, "red")
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Fixed Canvas Transform",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    media = engine.media().import_media(source)
    project.media.append(engine.media().to_media_reference(media))
    clip_range = TimeRange(start=rt(0), duration=rt(24))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="video",
            items=[
                Clip(
                    id="transformed",
                    media_reference_id=media.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                    effects=[
                        Effect(
                            id="half-size",
                            kind=EffectKind.SCALE,
                            parameters={"x": 0.5, "y": 0.5},
                        ),
                        Effect(
                            id="move-right",
                            kind=EffectKind.POSITION,
                            parameters={"x": 60, "y": 0},
                        ),
                    ],
                )
            ],
        )
    ]
    output = tmp_path / "transformed.mp4"

    engine.renderer(project).render(RenderRequest(output_path=output))

    red = sample_rgb(output, 200, 90)
    transparent_region = sample_rgb(output, 50, 90)
    assert red[0] > 200 and red[1] < 40 and red[2] < 40
    assert max(transparent_region) < 30


@pytest.mark.integration
def test_visual_position_and_opacity_keyframes_render_at_rational_times(
    tmp_path: Path,
) -> None:
    blue_source = tmp_path / "blue.mp4"
    red_source = tmp_path / "red-animated.mp4"
    create_color_source(blue_source, "blue")
    create_color_source(red_source, "red")
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Visual Automation",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    blue = engine.media().import_media(blue_source)
    red = engine.media().import_media(red_source)
    project.media.extend(
        [engine.media().to_media_reference(blue), engine.media().to_media_reference(red)]
    )
    clip_range = TimeRange(start=rt(0), duration=rt(24))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="base",
            items=[
                Clip(
                    id="blue",
                    media_reference_id=blue.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                )
            ],
        ),
        VideoTrack(
            id="foreground",
            items=[
                Clip(
                    id="red",
                    media_reference_id=red.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                    effects=[
                        Effect(
                            id="quarter-size",
                            kind=EffectKind.SCALE,
                            parameters={"x": 0.25, "y": 0.25},
                        ),
                        Effect(
                            id="animated-position",
                            kind=EffectKind.POSITION,
                            parameters={"x": -100, "y": 0},
                            keyframes=[
                                Keyframe(
                                    id="left",
                                    property_path="x",
                                    time=rt(0),
                                    value=-100,
                                ),
                                Keyframe(
                                    id="right",
                                    property_path="x",
                                    time=rt(24),
                                    value=100,
                                ),
                            ],
                        ),
                        Effect(
                            id="animated-opacity",
                            kind=EffectKind.OPACITY,
                            parameters={"value": 0},
                            keyframes=[
                                Keyframe(
                                    id="transparent",
                                    property_path="value",
                                    time=rt(0),
                                    value=0,
                                ),
                                Keyframe(
                                    id="opaque",
                                    property_path="value",
                                    time=rt(24),
                                    value=1,
                                ),
                            ],
                        ),
                    ],
                )
            ],
        ),
    ]
    output = tmp_path / "visual-automation.mp4"

    engine.renderer(project).render(RenderRequest(output_path=output))

    early_inside = sample_rgb(output, 100, 90, timestamp=0.25)
    early_right = sample_rgb(output, 220, 90, timestamp=0.25)
    late_left = sample_rgb(output, 100, 90, timestamp=0.75)
    late_inside = sample_rgb(output, 220, 90, timestamp=0.75)
    assert early_inside[0] > 30 and early_inside[2] > early_inside[0]
    assert early_right[2] > 180 and early_right[0] < 40
    assert late_left[2] > 180 and late_left[0] < 40
    assert late_inside[0] > late_inside[2] * 2


@pytest.mark.integration
def test_blend_mode_and_time_bounded_adjustment_layers_render(
    tmp_path: Path,
) -> None:
    blue_source = tmp_path / "blend-blue.mp4"
    red_source = tmp_path / "blend-red.mp4"
    create_color_source(blue_source, "blue")
    create_color_source(red_source, "red")
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Blend and Adjustment",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    blue = engine.media().import_media(blue_source)
    red = engine.media().import_media(red_source)
    project.media.extend(
        [engine.media().to_media_reference(blue), engine.media().to_media_reference(red)]
    )
    clip_range = TimeRange(start=rt(0), duration=rt(24))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="base",
            items=[
                Clip(
                    id="blue",
                    media_reference_id=blue.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                )
            ],
        ),
        VideoTrack(
            id="screen",
            items=[
                Clip(
                    id="red",
                    media_reference_id=red.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                    effects=[
                        Effect(
                            id="screen-mode",
                            kind=EffectKind.BLEND_MODE,
                            parameters={"mode": "screen"},
                        )
                    ],
                )
            ],
        ),
        AdjustmentTrack(
            id="adjustments",
            items=[
                AdjustmentClip(
                    id="first-half-brighter",
                    timeline_range=TimeRange(start=rt(0), duration=rt(12)),
                    effects=[
                        Effect(
                            id="brightness",
                            kind=EffectKind.COLOR_GRADE,
                            parameters={"exposure_stops": 1},
                        )
                    ],
                )
            ],
        ),
    ]
    output = tmp_path / "blend-adjustment.mp4"

    engine.renderer(project).render(RenderRequest(output_path=output))

    adjusted = sample_rgb(output, 160, 90, timestamp=0.25)
    boundary = sample_rgb(output, 160, 90, timestamp=0.5)
    unadjusted = sample_rgb(output, 160, 90, timestamp=0.75)
    assert adjusted[0] > 200 and adjusted[2] > 200
    assert sum(adjusted) > sum(unadjusted) + 20
    assert boundary == pytest.approx(unadjusted, abs=3)


@pytest.mark.integration
def test_discrete_blend_mode_automation_renders_exact_segments(tmp_path: Path) -> None:
    blue_source = tmp_path / "animated-blend-blue.mp4"
    red_source = tmp_path / "animated-blend-red.mp4"
    create_color_source(blue_source, "blue")
    create_color_source(red_source, "red")
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Animated Blend",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    blue = engine.media().import_media(blue_source)
    red = engine.media().import_media(red_source)
    project.media.extend(
        [engine.media().to_media_reference(blue), engine.media().to_media_reference(red)]
    )
    clip_range = TimeRange(start=rt(0), duration=rt(24))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="base",
            items=[
                Clip(
                    id="blue",
                    media_reference_id=blue.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                )
            ],
        ),
        VideoTrack(
            id="blend",
            items=[
                Clip(
                    id="red",
                    media_reference_id=red.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                    effects=[
                        Effect(
                            id="mode",
                            kind=EffectKind.BLEND_MODE,
                            parameters={"mode": "multiply"},
                            keyframes=[
                                Keyframe(
                                    id="screen",
                                    property_path="mode",
                                    time=rt(12),
                                    value="screen",
                                    interpolation=Interpolation.HOLD,
                                )
                            ],
                        )
                    ],
                )
            ],
        ),
    ]
    output = tmp_path / "animated-blend.mp4"

    engine.renderer(project).render(RenderRequest(output_path=output))

    multiply = sample_rgb(output, 160, 90, timestamp=0.25)
    screen = sample_rgb(output, 160, 90, timestamp=0.75)
    assert max(multiply) < 25
    assert screen[0] > 180 and screen[2] > 180 and screen[1] < 40


@pytest.mark.integration
def test_chroma_key_composites_foreground_over_a_plate(tmp_path: Path) -> None:
    plate_source = tmp_path / "chroma-plate.mp4"
    keyed_source = tmp_path / "chroma-foreground.mp4"
    create_color_source(plate_source, "blue")
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=green:s=320x180:r=24:d=1,drawbox=x=110:y=40:w=100:h=100:color=red:t=fill",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(keyed_source),
        ],
        check=True,
    )
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Chroma Key",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    plate = engine.media().import_media(plate_source)
    keyed = engine.media().import_media(keyed_source)
    project.media.extend(
        [engine.media().to_media_reference(plate), engine.media().to_media_reference(keyed)]
    )
    clip_range = TimeRange(start=rt(0), duration=rt(24))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="plate",
            items=[
                Clip(
                    id="blue",
                    media_reference_id=plate.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                )
            ],
        ),
        VideoTrack(
            id="keyed",
            items=[
                Clip(
                    id="green-screen",
                    media_reference_id=keyed.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                    effects=[
                        Effect(
                            id="remove-green",
                            kind=EffectKind.CHROMA_KEY,
                            parameters={
                                "key_color": "0x00FF00",
                                "similarity": 0.2,
                                "blend": 0.05,
                            },
                        )
                    ],
                )
            ],
        ),
    ]
    output = tmp_path / "chroma-key.mp4"

    engine.renderer(project).render(RenderRequest(output_path=output))

    corner = sample_rgb(output, 20, 20)
    subject = sample_rgb(output, 160, 90)
    assert corner[2] > 180 and corner[0] < 50
    assert subject[0] > 180 and subject[1] < 60 and subject[2] < 60


@pytest.mark.integration
def test_typed_blur_shadow_glow_perspective_and_distortion_chain(
    tmp_path: Path,
) -> None:
    plate_source = tmp_path / "effects-plate.mp4"
    subject_source = tmp_path / "effects-subject.mp4"
    create_color_source(plate_source, "blue")
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=green:s=320x180:r=24:d=1,drawbox=x=110:y=40:w=100:h=100:color=red:t=fill",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(subject_source),
        ],
        check=True,
    )
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Typed Visual Filters",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    plate = engine.media().import_media(plate_source)
    subject = engine.media().import_media(subject_source)
    project.media.extend(
        [engine.media().to_media_reference(plate), engine.media().to_media_reference(subject)]
    )
    clip_range = TimeRange(start=rt(0), duration=rt(24))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="plate",
            items=[
                Clip(
                    id="blurred-blue",
                    media_reference_id=plate.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                    effects=[
                        Effect(
                            id="blur",
                            kind=EffectKind.BACKGROUND_BLUR,
                            parameters={"sigma": 2, "steps": 1},
                        )
                    ],
                )
            ],
        ),
        VideoTrack(
            id="subject",
            items=[
                Clip(
                    id="styled-subject",
                    media_reference_id=subject.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                    effects=[
                        Effect(
                            id="key",
                            kind=EffectKind.CHROMA_KEY,
                            parameters={"similarity": 0.2, "blend": 0.03},
                        ),
                        Effect(
                            id="shadow",
                            kind=EffectKind.DROP_SHADOW,
                            parameters={
                                "offset_x": 12,
                                "offset_y": 8,
                                "blur_sigma": 4,
                                "opacity": 0.6,
                            },
                        ),
                        Effect(
                            id="glow",
                            kind=EffectKind.GLOW,
                            parameters={"blur_sigma": 3, "intensity": 0.3},
                        ),
                        Effect(
                            id="perspective",
                            kind=EffectKind.PERSPECTIVE,
                            parameters={"top_left_y": 0.02, "top_right_y": 0.05},
                            keyframes=[
                                Keyframe(
                                    id="perspective-start",
                                    property_path="top_left_x",
                                    time=rt(0),
                                    value=0,
                                ),
                                Keyframe(
                                    id="perspective-end",
                                    property_path="top_left_x",
                                    time=rt(24),
                                    value=0.05,
                                ),
                            ],
                        ),
                        Effect(
                            id="distort",
                            kind=EffectKind.DISTORTION,
                            parameters={"quadratic": 0.03, "double_quadratic": -0.01},
                        ),
                    ],
                )
            ],
        ),
    ]
    output = tmp_path / "typed-visual-filters.mp4"

    result = engine.renderer(project).render(RenderRequest(output_path=output))

    succeeded_types = {
        record.node_type.value for record in result.manifest.records if record.status == "succeeded"
    }
    center = sample_rgb(output, 160, 90)
    assert {"blur", "shadow", "glow", "perspective", "distortion"} <= succeeded_types
    assert center[0] > center[2]


@pytest.mark.integration
def test_animated_shape_mask_and_selective_blur_render_decoded_geometry(
    tmp_path: Path,
) -> None:
    blue_source = tmp_path / "mask-blue.mp4"
    red_source = tmp_path / "mask-red.mp4"
    pattern_source = tmp_path / "blur-pattern.mp4"
    create_color_source(blue_source, "blue")
    create_color_source(red_source, "red")
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=black:s=320x180:r=24:d=1,drawgrid=w=8:h=180:t=4:c=white",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(pattern_source),
        ],
        check=True,
    )
    engine = VideoEngine(tmp_path)
    clip_range = TimeRange(start=rt(0), duration=rt(24))
    blue = engine.media().import_media(blue_source)
    red = engine.media().import_media(red_source)
    pattern = engine.media().import_media(pattern_source)

    mask_project = engine.create_project(
        "Animated Mask", width=320, height=180, frame_rate=FrameRate(numerator=24)
    )
    mask_project.media.extend(
        [engine.media().to_media_reference(blue), engine.media().to_media_reference(red)]
    )
    mask_project.sequence().timeline.tracks = [
        VideoTrack(
            id="plate",
            items=[
                Clip(
                    id="blue",
                    media_reference_id=blue.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                )
            ],
        ),
        VideoTrack(
            id="foreground",
            items=[
                Clip(
                    id="red",
                    media_reference_id=red.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                )
            ],
        ),
    ]
    mask_tracking = engine.visual().track(
        TrackingRequest(
            id="mask-tracking",
            media_reference_id=red.id,
            source_range=clip_range,
            sample_interval=rt(24),
            manual_observations=(
                TrackingObservation(
                    time=rt(0),
                    subject_id="subject",
                    confidence=1,
                    box=NormalizedBox(x=0, y=0, width=0.25, height=1),
                    manual=True,
                ),
                TrackingObservation(
                    time=rt(24),
                    subject_id="subject",
                    confidence=1,
                    box=NormalizedBox(x=0.75, y=0, width=0.25, height=1),
                    manual=True,
                ),
            ),
        )
    )
    mask_application = engine.visual().materialize_binding(
        mask_project,
        mask_tracking,
        TrackingBinding(
            id="tracked-mask",
            tracking_result_id=mask_tracking.id,
            source_item_id="red",
            target_item_id="red",
            driver="mask",
            geometry=TrackingGeometry(
                source_width=320,
                source_height=180,
                canvas_width=320,
                canvas_height=180,
            ),
            timeline_frame_rate=FrameRate(numerator=24),
            subject_id="subject",
        ),
    )
    mask_editor = engine.editor(mask_project)
    mask_editor.apply_patch(mask_application.patch)
    mask_project = mask_editor.project
    mask_output = tmp_path / "animated-mask.mp4"
    engine.renderer(mask_project).render(RenderRequest(output_path=mask_output, sectioning=False))
    assert sample_rgb(mask_output, 40, 90, timestamp=0.1)[0] > 180
    assert sample_rgb(mask_output, 280, 90, timestamp=0.1)[2] > 180
    assert sample_rgb(mask_output, 40, 90, timestamp=0.9)[2] > 180
    assert sample_rgb(mask_output, 280, 90, timestamp=0.9)[0] > 180

    blur_project = engine.create_project(
        "Selective Blur", width=320, height=180, frame_rate=FrameRate(numerator=24)
    )
    blur_project.media.append(engine.media().to_media_reference(pattern))
    blur_project.sequence().timeline.tracks = [
        VideoTrack(
            id="pattern",
            items=[
                Clip(
                    id="selective-blur",
                    media_reference_id=pattern.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                )
            ],
        )
    ]
    blur_tracking = engine.visual().track(
        TrackingRequest(
            id="blur-tracking",
            media_reference_id=pattern.id,
            source_range=clip_range,
            sample_interval=rt(24),
            manual_observations=(
                TrackingObservation(
                    time=rt(0),
                    subject_id="subject",
                    confidence=1,
                    box=NormalizedBox(x=0.1, y=0, width=0.3, height=1),
                    manual=True,
                ),
                TrackingObservation(
                    time=rt(24),
                    subject_id="subject",
                    confidence=1,
                    box=NormalizedBox(x=0.6, y=0, width=0.3, height=1),
                    manual=True,
                ),
            ),
        )
    )
    blur_application = engine.visual().materialize_binding(
        blur_project,
        blur_tracking,
        TrackingBinding(
            id="tracked-blur",
            tracking_result_id=blur_tracking.id,
            source_item_id="selective-blur",
            target_item_id="selective-blur",
            driver="blur",
            geometry=TrackingGeometry(
                source_width=320,
                source_height=180,
                canvas_width=320,
                canvas_height=180,
            ),
            timeline_frame_rate=FrameRate(numerator=24),
            subject_id="subject",
            blur_region="inside",
            blur_sigma=8,
            blur_steps=2,
            feather=0.02,
        ),
    )
    blur_editor = engine.editor(blur_project)
    blur_editor.apply_patch(blur_application.patch)
    blur_project = blur_editor.project
    blur_output = tmp_path / "selective-blur.mp4"
    engine.renderer(blur_project).render(RenderRequest(output_path=blur_output, sectioning=False))
    blur_early = tmp_path / "selective-blur-early.png"
    blur_late = tmp_path / "selective-blur-late.png"
    extract_frame(blur_output, 0.1, blur_early)
    extract_frame(blur_output, 0.9, blur_late)
    early = Image.open(blur_early).convert("L")
    late = Image.open(blur_late).convert("L")
    early_left = ImageStat.Stat(early.crop((40, 20, 100, 160))).stddev[0]
    early_right = ImageStat.Stat(early.crop((220, 20, 285, 160))).stddev[0]
    late_left = ImageStat.Stat(late.crop((40, 20, 100, 160))).stddev[0]
    late_right = ImageStat.Stat(late.crop((220, 20, 285, 160))).stddev[0]
    assert early_left < early_right * 0.55
    assert late_right < late_left * 0.55


@pytest.mark.integration
def test_tracked_crop_patch_centers_subject_in_full_and_range_renders(tmp_path: Path) -> None:
    source = tmp_path / "tracked-crop-source.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=blue:s=320x180:r=24:d=1,drawbox=x=16:y=45:w=64:h=90:color=red:t=fill",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(source),
        ],
        check=True,
    )
    engine = VideoEngine(tmp_path)
    media = engine.media().import_media(source)
    project = engine.create_project(
        "Tracked crop", width=180, height=180, frame_rate=FrameRate(numerator=24)
    )
    project.media.append(engine.media().to_media_reference(media))
    clip_range = TimeRange(start=rt(0), duration=rt(24))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="video",
            items=[
                Clip(
                    id="subject",
                    media_reference_id=media.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                )
            ],
        )
    ]
    tracking = engine.visual().track(
        TrackingRequest(
            id="subject-track",
            media_reference_id=media.id,
            source_range=clip_range,
            sample_interval=rt(24),
            manual_observations=(
                TrackingObservation(
                    time=rt(0),
                    subject_id="product",
                    confidence=1,
                    box=NormalizedBox(x=0.05, y=0.25, width=0.2, height=0.5),
                    manual=True,
                ),
            ),
        )
    )
    application = engine.visual().materialize_binding(
        project,
        tracking,
        TrackingBinding(
            id="product-crop",
            tracking_result_id=tracking.id,
            source_item_id="subject",
            target_item_id="subject",
            driver="crop",
            geometry=TrackingGeometry(
                source_width=320,
                source_height=180,
                canvas_width=180,
                canvas_height=180,
            ),
            timeline_frame_rate=FrameRate(numerator=24),
            subject_id="product",
        ),
    )
    editor = engine.editor(project)
    editor.apply_patch(application.patch)
    full_output = tmp_path / "tracked-crop-full.mp4"
    range_output = tmp_path / "tracked-crop-range.mp4"
    engine.renderer(editor.project).render(RenderRequest(output_path=full_output, sectioning=False))
    engine.renderer(editor.project).render(
        RenderRequest(
            output_path=range_output,
            mode=RenderMode.RANGE,
            timeline_range=TimeRange(start=rt(6), duration=rt(12)),
            sectioning=False,
        )
    )

    for name, output, timestamp in (
        ("full", full_output, 0.5),
        ("range", range_output, 0.2),
    ):
        frame = tmp_path / f"tracked-crop-{name}.png"
        extract_frame(output, timestamp, frame)
        image = Image.open(frame).convert("RGB")
        red_x = [
            x
            for y in range(image.height)
            for x in range(image.width)
            if image.getpixel((x, y))[0] > 150 and image.getpixel((x, y))[2] < 100
        ]
        assert red_x
        assert sum(red_x) / len(red_x) == pytest.approx(90, abs=4)
    assert len(decoded_frame_hashes(range_output)) == 12


@pytest.mark.integration
def test_referenced_track_matte_multiplies_alpha_preserves_gaps_and_range_parity(
    tmp_path: Path,
) -> None:
    plate_source = tmp_path / "referenced-matte-plate.mp4"
    subject_source = tmp_path / "referenced-matte-subject.mp4"
    matte_source = tmp_path / "referenced-matte-luma.mp4"
    create_color_source(plate_source, "blue")
    create_color_source(subject_source, "red")
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=black:s=320x180:r=24:d=1,drawbox=x=0:y=0:w=160:h=180:color=white:t=fill",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(matte_source),
        ],
        check=True,
    )
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Referenced Track Matte",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    plate = engine.media().import_media(plate_source)
    subject = engine.media().import_media(subject_source)
    matte_record = engine.media().import_media(matte_source)
    project.media.extend(
        [
            engine.media().to_media_reference(plate),
            engine.media().to_media_reference(subject),
            engine.media().to_media_reference(matte_record),
        ]
    )
    clip_range = TimeRange(start=rt(0), duration=rt(24))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="plate",
            items=[
                Clip(
                    id="plate-item",
                    media_reference_id=plate.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                )
            ],
        ),
        VideoTrack(
            id="subject",
            items=[
                Clip(
                    id="subject-item",
                    media_reference_id=subject.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                    effects=[
                        Effect(
                            id="half-opacity",
                            kind=EffectKind.OPACITY,
                            parameters={"value": 0.5},
                        ),
                        Effect(
                            id="moving-matte",
                            kind=EffectKind.TRACK_MATTE,
                            parameters={"track_id": "matte-only", "channel": "luma"},
                        ),
                    ],
                )
            ],
        ),
        GraphicsTrack(
            id="matte-only",
            enabled=False,
            items=[
                Clip(
                    id="matte-item-a",
                    media_reference_id=matte_record.id,
                    timeline_range=TimeRange(start=rt(0), duration=rt(8)),
                    source_range=TimeRange(start=rt(0), duration=rt(8)),
                    source_audio_enabled=False,
                ),
                Clip(
                    id="matte-item-b",
                    media_reference_id=matte_record.id,
                    timeline_range=TimeRange(start=rt(16), duration=rt(8)),
                    source_range=TimeRange(start=rt(16), duration=rt(8)),
                    source_audio_enabled=False,
                ),
            ],
        ),
    ]
    full_output = tmp_path / "matte-full.mp4"
    range_output = tmp_path / "matte-range.mp4"
    engine.renderer(project).render(RenderRequest(output_path=full_output, sectioning=False))
    engine.renderer(project).render(
        RenderRequest(
            output_path=range_output,
            mode=RenderMode.RANGE,
            timeline_range=TimeRange(start=rt(6), duration=rt(12)),
            sectioning=False,
        )
    )

    matte_side = sample_rgb(full_output, 80, 90, timestamp=0.25)
    clear_side = sample_rgb(full_output, 240, 90, timestamp=0.25)
    gap_side = sample_rgb(full_output, 80, 90, timestamp=0.5)
    assert 70 < matte_side[0] < 190
    assert 70 < matte_side[2] < 190
    assert clear_side[2] > 180 and clear_side[0] < 50
    assert gap_side[2] > 180 and gap_side[0] < 50
    assert len(decoded_frame_hashes(range_output)) == 12
    for index, (full_time, range_time) in enumerate(((0.25, 0.0), (0.5, 0.25))):
        full_frame = tmp_path / f"matte-full-parity-{index}.png"
        range_frame = tmp_path / f"matte-range-parity-{index}.png"
        extract_frame(full_output, full_time, full_frame)
        extract_frame(range_output, range_time, range_frame)
        difference = ImageChops.difference(
            Image.open(full_frame).convert("RGB"),
            Image.open(range_frame).convert("RGB"),
        )
        assert max(ImageStat.Stat(difference).mean) < 3


@pytest.mark.integration
def test_luma_matte_and_rounded_mask_preserve_alpha_compositing(tmp_path: Path) -> None:
    plate_source = tmp_path / "matte-plate.mp4"
    foreground_source = tmp_path / "matte-foreground.mp4"
    matte_path = tmp_path / "left-half-matte.png"
    create_color_source(plate_source, "blue")
    create_color_source(foreground_source, "red")
    matte = Image.new("L", (320, 180), color=0)
    matte.paste(255, (0, 0, 160, 180))
    matte.save(matte_path)
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Track Matte",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    plate = engine.media().import_media(plate_source)
    foreground = engine.media().import_media(foreground_source)
    project.media.extend(
        [
            engine.media().to_media_reference(plate),
            engine.media().to_media_reference(foreground),
        ]
    )
    clip_range = TimeRange(start=rt(0), duration=rt(24))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="plate",
            items=[
                Clip(
                    id="blue",
                    media_reference_id=plate.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                )
            ],
        ),
        VideoTrack(
            id="foreground",
            items=[
                Clip(
                    id="red",
                    media_reference_id=foreground.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                    effects=[
                        Effect(
                            id="left-half",
                            kind=EffectKind.TRACK_MATTE,
                            parameters={"path": str(matte_path), "channel": "luma"},
                        ),
                        Effect(
                            id="rounded",
                            kind=EffectKind.CORNER_RADIUS,
                            parameters={"radius": 40},
                        ),
                    ],
                )
            ],
        ),
    ]
    output = tmp_path / "matte-rounded.mp4"

    engine.renderer(project).render(RenderRequest(output_path=output))

    rounded_corner = sample_rgb(output, 5, 5)
    matte_inside = sample_rgb(output, 80, 90)
    matte_outside = sample_rgb(output, 240, 90)
    assert rounded_corner[2] > 180 and rounded_corner[0] < 50
    assert matte_inside[0] > 180 and matte_inside[2] < 60
    assert matte_outside[2] > 180 and matte_outside[0] < 50


@pytest.mark.integration
def test_tracking_reframe_moves_horizontal_focus_on_the_timeline(tmp_path: Path) -> None:
    source = tmp_path / "two-subjects.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=red:s=320x180:r=24:d=1,drawbox=x=160:y=0:w=160:h=180:color=green:t=fill",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(source),
        ],
        check=True,
    )
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Tracked Reframe",
        width=180,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    media = engine.media().import_media(source)
    project.media.append(engine.media().to_media_reference(media))
    tracking = engine.visual().track(
        TrackingRequest(
            id="pan",
            media_reference_id=media.id,
            source_range=TimeRange(start=rt(0), duration=rt(24)),
            sample_interval=rt(24),
            manual_observations=(
                TrackingObservation(
                    time=rt(0),
                    subject_id="left",
                    box=NormalizedBox(x=0, y=0, width=0.5, height=1),
                    manual=True,
                ),
                TrackingObservation(
                    time=rt(24),
                    subject_id="right",
                    box=NormalizedBox(x=0.5, y=0, width=0.5, height=1),
                    manual=True,
                ),
            ),
        )
    )
    plan = engine.visual().plan_reframe(
        tracking,
        source_width=320,
        source_height=180,
        output_width=180,
        output_height=180,
        settings=ReframeSettings(subject_margin=0, smoothing=0),
    )
    clip_range = TimeRange(start=rt(0), duration=rt(24))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="video",
            items=[
                Clip(
                    id="tracked",
                    media_reference_id=media.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                    effects=[engine.visual().reframe_effect(plan)],
                )
            ],
        )
    ]
    output = tmp_path / "tracked-reframe.mp4"
    range_output = tmp_path / "tracked-reframe-range.mp4"

    engine.renderer(project).render(RenderRequest(output_path=output))
    engine.renderer(project).render(
        RenderRequest(
            output_path=range_output,
            mode=RenderMode.RANGE,
            timeline_range=TimeRange(start=rt(12), duration=rt(12)),
        )
    )

    early = sample_rgb(output, 90, 90, timestamp=0.2)
    late = sample_rgb(output, 90, 90, timestamp=0.8)
    ranged_late = sample_rgb(range_output, 90, 90, timestamp=0.3)
    assert early[0] > 180 and early[1] < 70
    assert late[1] > 80 and late[0] < 80
    assert ranged_late[1] > 80 and ranged_late[0] < 80


@pytest.mark.integration
@pytest.mark.parametrize("reverse", [False, True])
def test_retime_full_and_range_outputs_share_visual_time_mapping(
    tmp_path: Path, render_source: Path, reverse: bool
) -> None:
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Retime Integration",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    media = engine.media().import_media(render_source)
    project.media.append(engine.media().to_media_reference(media))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="video",
            items=[
                Clip(
                    id="retimed",
                    media_reference_id=media.id,
                    timeline_range=TimeRange(start=rt(0), duration=rt(24)),
                    source_range=TimeRange(start=rt(0), duration=rt(48)),
                    retime=Retime(rate="2", reverse=reverse),
                )
            ],
        )
    ]
    full = tmp_path / f"retime-full-{reverse}.mp4"
    ranged = tmp_path / f"retime-range-{reverse}.mp4"
    full_result = engine.renderer(project).render(RenderRequest(output_path=full))
    range_result = engine.renderer(project).render(
        RenderRequest(
            output_path=ranged,
            mode=RenderMode.RANGE,
            timeline_range=TimeRange(start=rt(12), duration=rt(6)),
        )
    )
    full_frame = tmp_path / f"retime-full-{reverse}.png"
    range_frame = tmp_path / f"retime-range-{reverse}.png"
    extract_frame(full, 0.625, full_frame)
    extract_frame(ranged, 0.125, range_frame)

    with Image.open(full_frame).convert("RGB") as full_image:
        full_pixels = list(full_image.getdata())
    with Image.open(range_frame).convert("RGB") as range_image:
        range_pixels = list(range_image.getdata())
    mean_absolute_error = sum(
        abs(left - right)
        for full_pixel, range_pixel in zip(full_pixels, range_pixels, strict=True)
        for left, right in zip(full_pixel, range_pixel, strict=True)
    ) / (len(full_pixels) * 3)
    assert mean_absolute_error < 6

    full_master = next(
        record for record in full_result.manifest.records if record.node_id == "audio-master-mix"
    )
    range_master = next(
        record for record in range_result.manifest.records if record.node_id == "audio-master-mix"
    )
    assert full_master.artifact_path is not None
    assert range_master.artifact_path is not None
    full_samples, full_rate = sf.read(full_master.artifact_path, dtype="float32")
    range_samples, range_rate = sf.read(range_master.artifact_path, dtype="float32")
    assert full_rate == range_rate == 48_000
    assert len(full_samples) == 48_000
    assert len(range_samples) == 12_000


@pytest.mark.integration
@pytest.mark.parametrize("reverse", [False, True])
def test_speed_ramp_full_and_range_outputs_share_exact_video_and_audio_mapping(
    tmp_path: Path, render_source: Path, reverse: bool
) -> None:
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Speed Ramp Integration",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    media = engine.media().import_media(render_source)
    project.media.append(engine.media().to_media_reference(media))
    ramp = Retime(
        reverse=reverse,
        speed_ramp=(
            SpeedRampPoint(time=rt(0), rate=1),
            SpeedRampPoint(time=rt(24), rate=2),
        ),
    )
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="video",
            items=[
                Clip(
                    id="ramped",
                    media_reference_id=media.id,
                    timeline_range=TimeRange(start=rt(0), duration=rt(24)),
                    source_range=TimeRange(start=rt(0), duration=rt(36)),
                    retime=ramp,
                )
            ],
        )
    ]
    full = tmp_path / f"ramp-full-{reverse}.mp4"
    ranged = tmp_path / f"ramp-range-{reverse}.mp4"
    full_result = engine.renderer(project).render(RenderRequest(output_path=full))
    range_result = engine.renderer(project).render(
        RenderRequest(
            output_path=ranged,
            mode=RenderMode.RANGE,
            timeline_range=TimeRange(start=rt(12), duration=rt(6)),
        )
    )

    full_frame = tmp_path / f"ramp-full-{reverse}.png"
    range_frame = tmp_path / f"ramp-range-{reverse}.png"
    extract_frame(full, 0.625, full_frame)
    extract_frame(ranged, 0.125, range_frame)
    with Image.open(full_frame).convert("RGB") as full_image:
        full_pixels = list(full_image.getdata())
    with Image.open(range_frame).convert("RGB") as range_image:
        range_pixels = list(range_image.getdata())
    mean_absolute_error = sum(
        abs(left - right)
        for full_pixel, range_pixel in zip(full_pixels, range_pixels, strict=True)
        for left, right in zip(full_pixel, range_pixel, strict=True)
    ) / (len(full_pixels) * 3)
    assert mean_absolute_error < 6

    full_metadata = probe(full)
    range_metadata = probe(ranged)
    full_video = next(
        stream for stream in full_metadata["streams"] if stream["codec_type"] == "video"
    )
    range_video = next(
        stream for stream in range_metadata["streams"] if stream["codec_type"] == "video"
    )
    assert int(full_video["nb_frames"]) == 24
    assert int(range_video["nb_frames"]) == 6
    full_master = next(
        record for record in full_result.manifest.records if record.node_id == "audio-master-mix"
    )
    range_master = next(
        record for record in range_result.manifest.records if record.node_id == "audio-master-mix"
    )
    assert full_master.artifact_path is not None
    assert range_master.artifact_path is not None
    full_samples, full_rate = sf.read(full_master.artifact_path, dtype="float32")
    range_samples, range_rate = sf.read(range_master.artifact_path, dtype="float32")
    assert full_rate == range_rate == 48_000
    assert len(full_samples) == 48_000
    assert len(range_samples) == 12_000


@pytest.mark.integration
@pytest.mark.parametrize(
    "retime",
    [
        Retime(rate=RationalRate(numerator=2)),
        Retime(rate=RationalRate(numerator=3, denominator=2)),
        Retime(rate=RationalRate(numerator=1_001, denominator=1_000)),
        Retime(
            speed_ramp=(
                SpeedRampPoint(time=rt(0), rate=1),
                SpeedRampPoint(time=rt(18), rate=2),
            )
        ),
    ],
    ids=["2x", "three-halves", "fractional-1001", "ramp"],
)
def test_retimed_visual_transition_and_audio_crossfade_render(
    tmp_path: Path, render_source: Path, retime: Retime
) -> None:
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Retimed Transitions",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    media = engine.media().import_media(render_source)
    project.media.append(engine.media().to_media_reference(media))
    source_duration = retime.source_offset_at(rt(18))
    left_video = Clip(
        id="left-video",
        media_reference_id=media.id,
        timeline_range=TimeRange(start=rt(0), duration=rt(18)),
        source_range=TimeRange(start=rt(6), duration=source_duration),
        source_audio_enabled=False,
        retime=retime,
    )
    right_video = left_video.model_copy(
        deep=True,
        update={
            "id": "right-video",
            "timeline_range": TimeRange(start=rt(18), duration=rt(18)),
        },
    )
    left_audio = AudioClip(
        id="left-audio-retimed",
        media_reference_id=media.id,
        timeline_range=TimeRange(start=rt(0), duration=rt(18)),
        source_range=TimeRange(start=rt(6), duration=source_duration),
        retime=retime,
    )
    right_audio = left_audio.model_copy(
        deep=True,
        update={
            "id": "right-audio-retimed",
            "timeline_range": TimeRange(start=rt(18), duration=rt(18)),
        },
    )
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="video",
            items=[left_video, right_video],
            transitions=[
                Transition(
                    id="retimed-dissolve",
                    kind=TransitionKind.DISSOLVE,
                    from_item_id=left_video.id,
                    to_item_id=right_video.id,
                    duration=rt(6),
                )
            ],
        ),
        AudioTrack(
            id="audio",
            items=[left_audio, right_audio],
            transitions=[
                Transition(
                    id="retimed-crossfade",
                    kind=TransitionKind.AUDIO_CROSSFADE,
                    from_item_id=left_audio.id,
                    to_item_id=right_audio.id,
                    duration=rt(6),
                )
            ],
        ),
    ]

    result = engine.renderer(project).render(
        RenderRequest(output_path=tmp_path / "retimed-transitions.mp4")
    )
    metadata = probe(result.output_path)
    video = next(stream for stream in metadata["streams"] if stream["codec_type"] == "video")
    assert int(video["nb_frames"]) == 36
    master = next(
        record for record in result.manifest.records if record.node_id == "audio-master-mix"
    )
    assert master.artifact_path is not None
    samples, sample_rate = sf.read(master.artifact_path, dtype="float32")
    assert sample_rate == 48_000
    assert len(samples) == 72_000
    transition_records = [
        record for record in result.manifest.records if record.node_type.value == "transition"
    ]
    assert len(transition_records) == 2
    assert all(record.status == "succeeded" for record in transition_records)


@pytest.mark.integration
def test_audio_speed_ramp_uses_sample_clock_for_non_frame_aligned_duration(
    tmp_path: Path,
) -> None:
    source = tmp_path / "audio-ramp-source.wav"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:sample_rate=48000:duration=0.5",
            "-c:a",
            "pcm_f32le",
            str(source),
        ],
        check=True,
    )
    duration = RationalTime(value=4_800, timescale=48_000)
    node = SpeedRampNode(
        id="sample-clock-ramp",
        inputs=("source",),
        artifact_type=ArtifactType.AUDIO,
        points=(
            SpeedRampPoint(time=RationalTime.zero(), rate=1),
            SpeedRampPoint(time=duration, rate=2),
        ),
        duration=duration,
        frame_rate=FrameRate(numerator=24),
        sample_rate=48_000,
    )
    artifact = RenderArtifact(
        node_id="source",
        cache_key="source",
        artifact_type=ArtifactType.AUDIO,
        path=source,
        size_bytes=source.stat().st_size,
    )
    output = tmp_path / "audio-ramp-output.wav"

    FFmpegBackend(VideoEngine(tmp_path).config).execute(
        node, (artifact,), output, tmp_path / "work"
    )

    samples, sample_rate = sf.read(output, dtype="float32")
    assert sample_rate == 48_000
    assert len(samples) == 4_800
    assert float(abs(samples).max()) > 0.01
    assert not list((tmp_path / "work").glob("*.commands"))


@pytest.mark.integration
def test_slow_motion_retimes_60fps_source_before_30fps_conform(tmp_path: Path) -> None:
    source = tmp_path / "source-60fps.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "testsrc2=size=320x180:rate=60:duration=1",
            "-c:v",
            "libx264",
            "-preset",
            "ultrafast",
            "-g",
            "60",
            "-pix_fmt",
            "yuv420p",
            str(source),
        ],
        check=True,
    )
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Slow Motion Conform Order",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=30),
    )
    media = engine.media().import_media(source)
    project.media.append(engine.media().to_media_reference(media))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="video",
            items=[
                Clip(
                    id="slow",
                    media_reference_id=media.id,
                    timeline_range=TimeRange(
                        start=RationalTime.zero(),
                        duration=RationalTime(value=1, timescale=1),
                    ),
                    source_range=TimeRange(
                        start=RationalTime.zero(),
                        duration=RationalTime(value=1, timescale=2),
                    ),
                    source_audio_enabled=False,
                    retime=Retime(rate=RationalRate(numerator=1, denominator=2)),
                )
            ],
        )
    ]
    output = tmp_path / "slow-motion.mp4"

    engine.renderer(project).render(RenderRequest(output_path=output))

    hashes = decoded_frame_hashes(output)
    assert len(hashes) == 30
    assert len(set(hashes)) >= 28


@pytest.mark.integration
@pytest.mark.parametrize(
    ("kind", "parameters"),
    (
        (TransitionKind.DISSOLVE, {}),
        (TransitionKind.DIP_TO_COLOR, {"color": "black"}),
        (TransitionKind.WIPE, {"direction": "right"}),
        (TransitionKind.SLIDE, {"direction": "up"}),
        (TransitionKind.PUSH, {"direction": "down"}),
        (TransitionKind.ZOOM, {"direction": "in"}),
    ),
)
def test_visual_transition_preserves_total_frame_count(
    tmp_path: Path,
    render_source: Path,
    kind: TransitionKind,
    parameters: dict[str, str],
) -> None:
    engine = VideoEngine(tmp_path)
    project = build_project(engine, render_source)
    track = project.sequence().timeline.tracks[0]
    assert isinstance(track, VideoTrack)
    first = track.items[0]
    assert isinstance(first, Clip)
    first = first.model_copy(
        update={
            "timeline_range": TimeRange(start=rt(0), duration=rt(18)),
            "source_range": TimeRange(start=rt(6), duration=rt(18)),
            "source_audio_enabled": False,
        }
    )
    track.items[0] = first
    second = first.model_copy(
        deep=True,
        update={
            "id": "clip-second",
            "timeline_range": TimeRange(start=rt(18), duration=rt(18)),
            "source_range": TimeRange(start=rt(24), duration=rt(18)),
        },
    )
    track.items.append(second)
    track.transitions.append(
        Transition(
            id=f"transition-{kind.value}",
            kind=kind,
            from_item_id=first.id,
            to_item_id=second.id,
            duration=rt(6),
            parameters=parameters,
        )
    )
    result = engine.renderer(project).render(RenderRequest(output_path=tmp_path / "transition.mp4"))
    metadata = probe(result.output_path)
    video = next(stream for stream in metadata["streams"] if stream["codec_type"] == "video")
    assert int(video["nb_frames"]) == 36
    assert abs(float(metadata["format"]["duration"]) - 1.5) <= 0.03


@pytest.mark.integration
def test_audio_crossfade_renders_exact_master_sample_count(
    tmp_path: Path, render_source: Path
) -> None:
    engine = VideoEngine(tmp_path)
    project = build_project(engine, render_source)
    video_track = project.sequence().timeline.tracks[0]
    assert isinstance(video_track, VideoTrack)
    video = video_track.items[0]
    assert isinstance(video, Clip)
    video = video.model_copy(
        update={
            "timeline_range": TimeRange(start=rt(0), duration=rt(48)),
            "source_range": TimeRange(start=rt(0), duration=rt(48)),
            "source_audio_enabled": False,
        }
    )
    video_track.items[0] = video
    left = AudioClip(
        id="left-audio",
        media_reference_id=video.media_reference_id,
        timeline_range=TimeRange(start=rt(0), duration=rt(24)),
        source_range=TimeRange(start=rt(6), duration=rt(24)),
    )
    right = AudioClip(
        id="right-audio",
        media_reference_id=video.media_reference_id,
        timeline_range=TimeRange(start=rt(24), duration=rt(24)),
        source_range=TimeRange(start=rt(12), duration=rt(24)),
    )
    project.sequence().timeline.tracks.append(
        AudioTrack(
            id="a1",
            items=[left, right],
            transitions=[
                Transition(
                    id="audio-crossfade",
                    kind=TransitionKind.AUDIO_CROSSFADE,
                    from_item_id=left.id,
                    to_item_id=right.id,
                    duration=rt(12),
                )
            ],
        )
    )
    result = engine.renderer(project).render(
        RenderRequest(output_path=tmp_path / "audio-crossfade.mp4")
    )
    transition_record = next(
        record
        for record in result.manifest.records
        if record.node_type.value == "transition" and "audio" in record.node_id
    )
    assert transition_record.status == "succeeded"
    master = next(
        record for record in result.manifest.records if record.node_id == "audio-master-mix"
    )
    assert master.artifact_path is not None
    samples, sample_rate = sf.read(master.artifact_path, dtype="float32")
    assert sample_rate == 48_000
    assert len(samples) == 96_000


@pytest.mark.integration
def test_gain_automation_is_evaluated_across_audio_samples(
    tmp_path: Path, render_source: Path
) -> None:
    engine = VideoEngine(tmp_path)
    project = build_project(engine, render_source)
    video_track = project.sequence().timeline.tracks[0]
    assert isinstance(video_track, VideoTrack)
    video = video_track.items[0]
    assert isinstance(video, Clip)
    video = video.model_copy(
        update={
            "timeline_range": TimeRange(start=rt(0), duration=rt(48)),
            "source_range": TimeRange(start=rt(0), duration=rt(48)),
        }
    )
    video_track.items[0] = video
    project.sequence().timeline.audio_buses = [
        AudioBus(
            id="master",
            name="Master",
            effects=[
                Effect(
                    id="gain-envelope",
                    kind=EffectKind.GAIN,
                    parameters={"db": 0},
                    keyframes=[
                        Keyframe(
                            id="start",
                            property_path="db",
                            time=rt(0),
                            value=0,
                        ),
                        Keyframe(
                            id="quiet",
                            property_path="db",
                            time=rt(24),
                            value=-20,
                        ),
                    ],
                )
            ],
        )
    ]
    result = engine.renderer(project).render(
        RenderRequest(output_path=tmp_path / "gain-automation.mp4")
    )
    processed = next(
        record for record in result.manifest.records if record.node_id == "audio-bus-master-process"
    )
    assert processed.artifact_path is not None
    samples, sample_rate = sf.read(processed.artifact_path, dtype="float32")
    early = float((samples[4_800:9_600] ** 2).mean()) ** 0.5
    late = float((samples[81_600:91_200] ** 2).mean()) ** 0.5
    assert sample_rate == 48_000
    assert late < early * 0.2

    range_result = engine.renderer(project).render(
        RenderRequest(
            output_path=tmp_path / "gain-automation-range.mp4",
            mode=RenderMode.RANGE,
            timeline_range=TimeRange(start=rt(24), duration=rt(24)),
        )
    )
    range_processed = next(
        record
        for record in range_result.manifest.records
        if record.node_id == "audio-bus-master-process"
    )
    assert range_processed.artifact_path is not None
    range_samples, range_rate = sf.read(range_processed.artifact_path, dtype="float32")
    assert range_rate == sample_rate
    assert len(range_samples) == 48_000
    assert abs(range_samples - samples[48_000:]).max() < 1e-5


@pytest.mark.integration
@pytest.mark.parametrize(
    ("effect_kind", "parameters", "expected_channels"),
    [
        (EffectKind.EQ, {"frequency": 440, "q": 1, "gain_db": -12}, 2),
        (
            EffectKind.COMPRESSION,
            {"threshold_db": -40, "ratio": 10, "attack_ms": 5, "release_ms": 50},
            2,
        ),
        (EffectKind.LIMITER, {"linear_peak": 0.1}, 2),
        (EffectKind.GATE, {"threshold_db": -10}, 2),
        (EffectKind.DE_ESSER, {"intensity": 1}, 2),
        (EffectKind.NOISE_REDUCTION, {"reduction_db": 24}, 2),
        (EffectKind.CHANNEL_MAP, {"layout": "mono"}, 1),
        (EffectKind.SAMPLE_RATE_CONVERT, {"sample_rate": 44_100}, 2),
    ],
)
def test_required_audio_processors_execute_on_real_samples(
    tmp_path: Path,
    effect_kind: EffectKind,
    parameters: dict[str, Any],
    expected_channels: int,
) -> None:
    source = tmp_path / "processor-source.wav"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:sample_rate=48000:duration=1",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=8000:sample_rate=48000:duration=1",
            "-f",
            "lavfi",
            "-i",
            "anoisesrc=color=white:amplitude=0.05:sample_rate=48000:duration=1",
            "-filter_complex",
            "[0:a][1:a][2:a]amix=inputs=3:duration=shortest:normalize=0,"
            "aformat=channel_layouts=stereo[outa]",
            "-map",
            "[outa]",
            "-c:a",
            "pcm_f32le",
            str(source),
        ],
        check=True,
    )
    source_samples, source_rate = sf.read(source, dtype="float32")
    engine = VideoEngine(tmp_path / "engine")
    backend = FFmpegBackend(engine.config)
    effect = Effect(id=f"processor-{effect_kind.value}", kind=effect_kind, parameters=parameters)
    node = AudioProcessNode(
        id=f"audio-{effect_kind.value}",
        inputs=("source",),
        artifact_type=ArtifactType.AUDIO,
        processors=(parse_audio_processor(effect),),
        sample_rate=48_000,
        channel_layout="stereo",
    )
    artifact = RenderArtifact(
        node_id="source",
        cache_key="source",
        artifact_type=ArtifactType.AUDIO,
        path=source,
        size_bytes=source.stat().st_size,
    )
    output = tmp_path / f"{effect_kind.value}.wav"

    execution = backend.execute(node, (artifact,), output, tmp_path / "work")
    output_samples, output_rate = sf.read(execution.path, dtype="float32", always_2d=True)
    source_2d = source_samples.reshape(-1, 2)

    assert output_rate == source_rate == 48_000
    assert len(output_samples) == len(source_2d) == 48_000
    assert output_samples.shape[1] == expected_channels
    if effect_kind is EffectKind.CHANNEL_MAP:
        assert abs(output_samples[:, 0] - source_2d[:, 0]).max() > 1e-5
    else:
        assert abs(output_samples[:, :2] - source_2d).max() > 1e-7


@pytest.mark.integration
def test_bus_sidechain_ducking_executes_as_two_input_audio_node(
    tmp_path: Path, render_source: Path
) -> None:
    engine = VideoEngine(tmp_path)
    project = build_project(engine, render_source)
    video_track = project.sequence().timeline.tracks[0]
    assert isinstance(video_track, VideoTrack)
    video = video_track.items[0]
    assert isinstance(video, Clip)
    video.source_audio_enabled = False
    project.sequence().timeline.audio_buses = [
        AudioBus(id="master", name="Master"),
        AudioBus(id="dialogue", name="Dialogue", parent_bus_id="master"),
        AudioBus(
            id="music",
            name="Music",
            parent_bus_id="master",
            effects=[
                Effect(
                    id="duck-under-dialogue",
                    kind=EffectKind.SIDECHAIN_DUCKING,
                    parameters={
                        "key_bus_id": "dialogue",
                        "threshold_db": -40,
                        "ratio": 10,
                        "attack_ms": 5,
                        "release_ms": 50,
                    },
                )
            ],
        ),
    ]
    project.sequence().timeline.tracks.extend(
        [
            AudioTrack(
                id="dialogue-track",
                bus_id="dialogue",
                items=[
                    AudioClip(
                        id="dialogue-audio",
                        media_reference_id=video.media_reference_id,
                        timeline_range=video.timeline_range,
                        source_range=video.source_range,
                    )
                ],
            ),
            AudioTrack(
                id="music-track",
                bus_id="music",
                items=[
                    AudioClip(
                        id="music-audio",
                        media_reference_id=video.media_reference_id,
                        timeline_range=video.timeline_range,
                        source_range=video.source_range,
                    )
                ],
            ),
        ]
    )
    result = engine.renderer(project).render(RenderRequest(output_path=tmp_path / "sidechain.mp4"))
    sidechain = next(
        record for record in result.manifest.records if record.node_type.value == "audio_sidechain"
    )
    assert sidechain.status == "succeeded"
    master = next(
        record for record in result.manifest.records if record.node_id == "audio-master-mix"
    )
    assert master.artifact_path is not None
    samples, sample_rate = sf.read(master.artifact_path, dtype="float32")
    assert sample_rate == 48_000
    assert len(samples) == 72_000


@pytest.mark.integration
def test_short_audio_is_padded_without_truncating_video(
    tmp_path: Path, render_source: Path
) -> None:
    engine = VideoEngine(tmp_path)
    project = build_project(engine, render_source)
    video_track = project.sequence().timeline.tracks[0]
    assert isinstance(video_track, VideoTrack)
    video = video_track.items[0]
    assert isinstance(video, Clip)
    video = video.model_copy(
        update={
            "timeline_range": TimeRange(start=rt(0), duration=rt(48)),
            "source_range": TimeRange(start=rt(0), duration=rt(48)),
            "source_audio_enabled": False,
        }
    )
    video_track.items[0] = video
    project.sequence().timeline.tracks.append(
        AudioTrack(
            id="a1",
            items=[
                AudioClip(
                    id="short-audio",
                    media_reference_id=video.media_reference_id,
                    timeline_range=TimeRange(start=rt(0), duration=rt(6)),
                    source_range=TimeRange(start=rt(0), duration=rt(6)),
                )
            ],
        )
    )
    result = engine.renderer(project).render(
        RenderRequest(output_path=tmp_path / "short-audio.mp4")
    )
    metadata = probe(result.output_path)
    output_video = next(stream for stream in metadata["streams"] if stream["codec_type"] == "video")
    assert int(output_video["nb_frames"]) == 48
    assert abs(float(metadata["format"]["duration"]) - 2.0) <= 0.03

    master_record = next(
        record for record in result.manifest.records if record.node_id == "audio-master-mix"
    )
    assert master_record.artifact_path is not None
    samples, sample_rate = sf.read(master_record.artifact_path, dtype="float32")
    assert sample_rate == 48_000
    assert len(samples) == 96_000
    assert abs(samples[24_000:]).max() < 1e-7


@pytest.mark.integration
def test_opacity_survives_lossless_intermediates(tmp_path: Path) -> None:
    blue_path = tmp_path / "blue.mp4"
    red_path = tmp_path / "red.mp4"
    create_color_source(blue_path, "blue")
    create_color_source(red_path, "red")
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Alpha Composite",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    blue = engine.media().import_media(blue_path)
    red = engine.media().import_media(red_path)
    project.media.extend(
        [engine.media().to_media_reference(blue), engine.media().to_media_reference(red)]
    )
    item_range = TimeRange(start=rt(0), duration=rt(24))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="base",
            items=[
                Clip(
                    id="blue",
                    media_reference_id=blue.id,
                    timeline_range=item_range,
                    source_range=item_range,
                    source_audio_enabled=False,
                )
            ],
        ),
        VideoTrack(
            id="top",
            items=[
                Clip(
                    id="red",
                    media_reference_id=red.id,
                    timeline_range=item_range,
                    source_range=item_range,
                    source_audio_enabled=False,
                    effects=[
                        Effect(
                            id="half-opacity",
                            kind=EffectKind.OPACITY,
                            parameters={"value": 0.5},
                        )
                    ],
                )
            ],
        ),
    ]
    output = (
        engine.renderer(project)
        .render(RenderRequest(output_path=tmp_path / "alpha.mp4"))
        .output_path
    )
    red_value, green_value, blue_value = sample_rgb(output, 160, 90)
    assert 105 <= red_value <= 150
    assert green_value <= 20
    assert 105 <= blue_value <= 150


@pytest.mark.integration
def test_non_normal_blend_respects_upstream_alpha(tmp_path: Path) -> None:
    blue_path = tmp_path / "alpha-blend-blue.mp4"
    red_path = tmp_path / "alpha-blend-red.mp4"
    create_color_source(blue_path, "blue")
    create_color_source(red_path, "red")
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Alpha Aware Blend",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    blue = engine.media().import_media(blue_path)
    red = engine.media().import_media(red_path)
    project.media.extend(
        [engine.media().to_media_reference(blue), engine.media().to_media_reference(red)]
    )
    item_range = TimeRange(start=rt(0), duration=rt(24))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="base",
            items=[
                Clip(
                    id="blue",
                    media_reference_id=blue.id,
                    timeline_range=item_range,
                    source_range=item_range,
                    source_audio_enabled=False,
                )
            ],
        ),
        VideoTrack(
            id="top",
            items=[
                Clip(
                    id="red",
                    media_reference_id=red.id,
                    timeline_range=item_range,
                    source_range=item_range,
                    source_audio_enabled=False,
                    effects=[
                        Effect(
                            id="transparent",
                            kind=EffectKind.OPACITY,
                            parameters={"value": 0},
                        ),
                        Effect(
                            id="screen",
                            kind=EffectKind.BLEND_MODE,
                            parameters={"mode": "screen"},
                        ),
                    ],
                )
            ],
        ),
    ]
    output = tmp_path / "alpha-aware-blend.mp4"

    engine.renderer(project).render(RenderRequest(output_path=output))

    pixel = sample_rgb(output, 160, 90)
    assert pixel[2] > 180 and pixel[0] < 30 and pixel[1] < 30


@pytest.mark.integration
def test_ten_bit_delivery_and_rec709_tags(tmp_path: Path, render_source: Path) -> None:
    engine = VideoEngine(tmp_path)
    project = build_project(engine, render_source)
    preview = next(profile for profile in project.delivery_profiles if profile.id == "preview")
    preview.pixel_format = "yuv420p10le"
    result = engine.renderer(project).render(RenderRequest(output_path=tmp_path / "ten-bit.mp4"))
    video = next(
        stream for stream in probe(result.output_path)["streams"] if stream["codec_type"] == "video"
    )
    assert video["pix_fmt"] == "yuv420p10le"
    assert video["color_primaries"] == "bt709"
    assert video["color_transfer"] == "bt709"
    assert video["color_space"] == "bt709"


@pytest.mark.integration
@pytest.mark.parametrize(
    ("transfer", "expected_rgb"),
    [("arib-std-b67", (50, 50, 50)), ("smpte2084", (64, 64, 64))],
)
def test_hdr_to_sdr_has_numeric_pixel_and_rec709_metadata_goldens(
    tmp_path: Path, transfer: str, expected_rgb: tuple[int, int, int]
) -> None:
    source = tmp_path / f"{transfer}.mkv"
    create_hdr_color_source(source, transfer)
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "HDR Numeric Golden",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    media = engine.media().import_media(source)
    assert media.probe.hdr
    project.media.append(engine.media().to_media_reference(media))
    clip_range = TimeRange(start=rt(0), duration=rt(24))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="video",
            items=[
                Clip(
                    id="hdr",
                    media_reference_id=media.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                )
            ],
        )
    ]
    output = tmp_path / f"{transfer}-rec709.mp4"

    engine.renderer(project).render(RenderRequest(output_path=output))

    video = next(stream for stream in probe(output)["streams"] if stream["codec_type"] == "video")
    pixel = sample_rgb(output, 160, 90)
    assert pixel == pytest.approx(expected_rgb, abs=3)
    assert video["color_primaries"] == "bt709"
    assert video["color_transfer"] == "bt709"
    assert video["color_space"] == "bt709"


@pytest.mark.integration
@pytest.mark.parametrize(
    ("output_space", "transfer"),
    [(ColorSpace.HLG, "arib-std-b67"), (ColorSpace.PQ, "smpte2084")],
)
def test_sdr_to_hdr_delivery_uses_valid_linear_conversion_and_tags(
    tmp_path: Path,
    render_source: Path,
    output_space: ColorSpace,
    transfer: str,
) -> None:
    engine = VideoEngine(tmp_path)
    project = build_project(engine, render_source)
    preview = next(profile for profile in project.delivery_profiles if profile.id == "preview")
    preview.pixel_format = "yuv420p10le"
    preview.output_color_space = output_space
    preview.video_codec = "libx265"
    output = tmp_path / f"rec709-to-{output_space.value}.mp4"

    engine.renderer(project).render(RenderRequest(output_path=output))

    video = next(stream for stream in probe(output)["streams"] if stream["codec_type"] == "video")
    pixel = sample_rgb(output, 160, 90)
    assert video["pix_fmt"] == "yuv420p10le"
    assert video["color_primaries"] == "bt2020"
    assert video["color_transfer"] == transfer
    assert video["color_space"] == "bt2020nc"
    assert max(pixel) > 5


@pytest.mark.integration
def test_unknown_metadata_uses_probed_source_rate_for_audio_trim(
    tmp_path: Path, render_source: Path
) -> None:
    impulse = tmp_path / "impulse-44100.wav"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            r"aevalsrc=if(between(t\,0.5\,0.51)\,0.9\,0):s=44100:d=1",
            "-c:a",
            "pcm_f32le",
            str(impulse),
        ],
        check=True,
    )
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Source Sample Rate",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    video_record = engine.media().import_media(render_source)
    audio_record = engine.media().import_media(impulse)
    project.media.extend(
        [
            engine.media().to_media_reference(video_record),
            engine.media().to_media_reference(audio_record).model_copy(update={"streams": []}),
        ]
    )
    half_second = RationalTime(value=1, timescale=2)
    timeline_range = TimeRange(start=rt(0), duration=rt(12))
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="v1",
            items=[
                Clip(
                    id="video",
                    media_reference_id=video_record.id,
                    timeline_range=timeline_range,
                    source_range=timeline_range,
                    source_audio_enabled=False,
                )
            ],
        ),
        AudioTrack(
            id="a1",
            items=[
                AudioClip(
                    id="impulse",
                    media_reference_id=audio_record.id,
                    timeline_range=timeline_range,
                    source_range=TimeRange(
                        start=half_second,
                        duration=half_second,
                    ),
                )
            ],
        ),
    ]
    result = engine.renderer(project).render(
        RenderRequest(output_path=tmp_path / "source-rate.mp4")
    )
    master = next(
        record for record in result.manifest.records if record.node_id == "audio-master-mix"
    )
    assert master.artifact_path is not None
    samples, sample_rate = sf.read(master.artifact_path, dtype="float32")
    assert sample_rate == 48_000
    assert abs(samples[:1_000]).max() > 0.5


@pytest.mark.integration
def test_render_rejects_input_collision_and_records_preflight_failure(
    tmp_path: Path, render_source: Path
) -> None:
    engine = VideoEngine(tmp_path)
    project = build_project(engine, render_source)
    before = render_source.read_bytes()
    with pytest.raises(EngineError, match="collides with an input") as raised:
        engine.renderer(project).render(RenderRequest(output_path=render_source))
    assert render_source.read_bytes() == before
    failure_path = Path(raised.value.context["manifest"])
    failure = json.loads(failure_path.read_text(encoding="utf-8"))
    assert failure["status"] == "failed"
    assert failure["failure"]["code"] == "storage_error"


@pytest.mark.integration
def test_compile_failure_always_produces_a_manifest(tmp_path: Path, render_source: Path) -> None:
    engine = VideoEngine(tmp_path)
    project = build_project(engine, render_source)
    with pytest.raises(EngineError, match="profile was not found") as raised:
        engine.renderer(project).render(
            RenderRequest(
                output_path=tmp_path / "never-written.mp4",
                delivery_profile_id="missing",
            )
        )
    failure = json.loads(Path(raised.value.context["manifest"]).read_text(encoding="utf-8"))
    assert failure["status"] == "failed"
    assert failure["failure"]["code"] == "invalid_project"
    assert failure["backend_version"] == "unresolved"
