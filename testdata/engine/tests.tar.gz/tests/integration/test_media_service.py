from __future__ import annotations

import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pytest
from PIL import Image

from video_engine.api.engine import VideoEngine
from video_engine.cli.main import main
from video_engine.core.time import RationalTime
from video_engine.errors import EngineError
from video_engine.media.models import DerivedAsset, DerivedAssetKind, MediaKind
from video_engine.media.probe import probe_media
from video_engine.media.service import sha256_file


@pytest.fixture(scope="module")
def source_video(tmp_path_factory: pytest.TempPathFactory) -> Path:
    directory = tmp_path_factory.mktemp("media-source")
    output = directory / "source.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "testsrc2=size=320x180:rate=30000/1001:duration=1.2",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:sample_rate=48000:duration=1.2",
            "-filter_complex",
            "[1:a]aformat=channel_layouts=stereo[a]",
            "-map",
            "0:v:0",
            "-map",
            "[a]",
            "-c:v",
            "libx264",
            "-preset",
            "ultrafast",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-ar",
            "48000",
            "-shortest",
            str(output),
        ],
        check=True,
    )
    return output


@pytest.fixture
def media_engine(tmp_path: Path) -> VideoEngine:
    return VideoEngine(tmp_path)


@pytest.mark.integration
def test_import_probe_validate_and_deduplicate(
    media_engine: VideoEngine, source_video: Path
) -> None:
    service = media_engine.media()
    first = service.import_media(source_video)
    second = service.import_media(source_video)

    assert first.id == second.id
    assert first.id == f"media-{first.sha256[:16]}"
    assert len(service.registry.data.records) == 1
    assert first.probe.variable_frame_rate is False
    assert first.probe.hdr is False
    assert [stream.kind for stream in first.probe.streams] == [MediaKind.VIDEO, MediaKind.AUDIO]
    assert first.probe.video_streams[0].average_frame_rate is not None
    assert first.probe.audio_streams[0].sample_rate == 48_000
    assert service.validate_source(first.id).valid


@pytest.mark.integration
def test_content_store_replaces_corruption_and_serializes_publication(
    media_engine: VideoEngine, source_video: Path
) -> None:
    digest = sha256_file(source_video)
    destination = media_engine.project_root / "media" / "sources" / f"{digest}{source_video.suffix}"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(b"partial prior import")

    def import_copy() -> tuple[Path, str]:
        record = media_engine.media().import_media(source_video, copy_into_store=True)
        return record.canonical_path, record.sha256

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda _: import_copy(), range(2)))

    assert results == [(destination, digest), (destination, digest)]
    assert sha256_file(destination) == digest
    assert destination.stat().st_mode & 0o222 == 0
    assert list(destination.parent.glob(f".{destination.name}.corrupt-*"))


@pytest.mark.integration
def test_cached_proxy_thumbnails_waveform_and_conform(
    media_engine: VideoEngine, source_video: Path
) -> None:
    service = media_engine.media()
    record = service.import_media(source_video)

    proxy = service.proxy(record.id, width=160, height=90, crf=30)
    proxy_again = service.proxy(record.id, width=160, height=90, crf=30)
    assert proxy.kind is DerivedAssetKind.PROXY
    assert proxy.paths == proxy_again.paths
    assert proxy.paths[0].exists()
    proxy_probe = probe_media(proxy.paths[0], media_engine.config, service.runner)
    assert (proxy_probe.video_streams[0].width, proxy_probe.video_streams[0].height) == (160, 90)

    thumbnails = service.thumbnails(record.id, count=3, width=120)
    assert thumbnails.kind is DerivedAssetKind.THUMBNAILS
    assert len(thumbnails.paths) == 3
    assert all(path.exists() for path in thumbnails.paths)

    waveform = service.waveform(record.id, width=400, height=100)
    assert waveform.kind is DerivedAssetKind.WAVEFORM
    assert [path.suffix for path in waveform.paths] == [".png", ".json"]
    assert all(path.exists() for path in waveform.paths)

    conformed = service.conform(
        record.id,
        width=160,
        height=90,
        frame_rate_numerator=24,
        sample_rate=48_000,
    )
    assert conformed.kind is DerivedAssetKind.CONFORMED
    conform_probe = probe_media(conformed.paths[0], media_engine.config, service.runner)
    assert conform_probe.video_streams[0].real_frame_rate is not None
    assert conform_probe.video_streams[0].real_frame_rate.numerator == 24

    looped = service.looped_conform(
        record.id,
        duration=RationalTime(value=2, timescale=1),
        frame_rate_numerator=24,
    )
    looped_again = service.looped_conform(
        record.id,
        duration=RationalTime(value=2, timescale=1),
        frame_rate_numerator=24,
    )
    assert looped.paths == looped_again.paths
    looped_probe = probe_media(looped.paths[0], media_engine.config, service.runner)
    assert looped_probe.duration == RationalTime(value=2, timescale=1)
    assert looped_probe.audio_streams == []


@pytest.mark.integration
def test_relink_requires_same_content(
    media_engine: VideoEngine, source_video: Path, tmp_path: Path
) -> None:
    service = media_engine.media()
    record = service.import_media(source_video)
    copy = tmp_path / "copy.mp4"
    shutil.copy2(source_video, copy)
    assert service.relink(record.id, copy).canonical_path == copy.resolve()

    different = tmp_path / "different.mp4"
    different.write_bytes(b"not the same content")
    with pytest.raises(EngineError, match="different SHA-256"):
        service.relink(record.id, different)


@pytest.mark.integration
def test_corrupt_derived_assets_are_rebuilt_with_verified_hashes(
    media_engine: VideoEngine, source_video: Path
) -> None:
    service = media_engine.media()
    record = service.import_media(source_video)
    proxy = service.proxy(record.id, width=160, height=90, crf=31)
    waveform = service.waveform(record.id, width=401, height=101)
    conformed = service.conform(
        record.id,
        width=162,
        height=92,
        frame_rate_numerator=24,
        sample_rate=48_000,
    )
    for asset in (proxy, waveform, conformed):
        asset.paths[0].write_bytes(b"truncated")

    fresh_service = media_engine.media()
    rebuilt = (
        fresh_service.proxy(record.id, width=160, height=90, crf=31),
        fresh_service.waveform(record.id, width=401, height=101),
        fresh_service.conform(
            record.id,
            width=162,
            height=92,
            frame_rate_numerator=24,
            sample_rate=48_000,
        ),
    )

    for asset in rebuilt:
        assert asset.sha256 == [sha256_file(path) for path in asset.paths]
        assert asset.size_bytes == [path.stat().st_size for path in asset.paths]
        assert all(path.read_bytes() != b"truncated" for path in asset.paths)
    assert probe_media(rebuilt[0].paths[0], media_engine.config, fresh_service.runner).video_streams
    with Image.open(rebuilt[1].paths[0]) as waveform_image:
        assert waveform_image.size == (401, 101)
    assert probe_media(rebuilt[2].paths[0], media_engine.config, fresh_service.runner).video_streams


@pytest.mark.integration
def test_derivative_rejects_source_mutation_before_ffmpeg(
    media_engine: VideoEngine, source_video: Path, tmp_path: Path
) -> None:
    mutable = tmp_path / "mutable.mp4"
    shutil.copy2(source_video, mutable)
    service = media_engine.media()
    record = service.import_media(mutable)
    mutable.write_bytes(b"mutated after import")

    with pytest.raises(EngineError, match="changed after import"):
        service.proxy(record.id, width=166, height=96, crf=33)


def test_derived_asset_requires_nonempty_complete_evidence() -> None:
    with pytest.raises(ValueError, match="at least 1 item"):
        DerivedAsset.model_validate(
            {
                "key": "a" * 64,
                "kind": "proxy",
                "paths": [],
                "parameters": {},
                "created_at": "2026-07-24T00:00:00Z",
                "tool_fingerprint": "test",
                "sha256": [],
                "size_bytes": [],
            }
        )


@pytest.mark.integration
def test_concurrent_derivative_generation_publishes_once_without_registry_loss(
    media_engine: VideoEngine, source_video: Path
) -> None:
    record = media_engine.media().import_media(source_video)

    def generate() -> tuple[list[Path], list[str]]:
        asset = media_engine.media().proxy(record.id, width=164, height=94, crf=32)
        return asset.paths, asset.sha256

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda _: generate(), range(2)))

    assert results[0] == results[1]
    registered = media_engine.media().inspect(record.id)
    matches = [
        item
        for item in registered.derivatives
        if item.paths == results[0][0] and item.sha256 == results[0][1]
    ]
    assert len(matches) == 1


@pytest.mark.integration
def test_media_cli_json(
    source_video: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    assert (
        main(
            [
                "media",
                "import",
                str(source_video),
                "--project-root",
                str(tmp_path),
                "--json",
            ]
        )
        == 0
    )
    imported = json.loads(capsys.readouterr().out)
    media_id = imported["media"][0]["id"]
    assert imported["ok"] is True

    assert (
        main(
            [
                "media",
                "inspect",
                media_id,
                "--project-root",
                str(tmp_path),
                "--json",
            ]
        )
        == 0
    )
    inspected = json.loads(capsys.readouterr().out)
    assert inspected["media"]["id"] == media_id
    assert inspected["validation"]["valid"] is True
