from __future__ import annotations

import hashlib
import subprocess
from pathlib import Path
from typing import Any

import pytest
from PIL import Image

from video_engine.api.engine import VideoEngine
from video_engine.color import ColorService
from video_engine.core.schema import Clip, FrameRate, VideoTrack
from video_engine.core.time import RationalTime, TimeRange
from video_engine.errors import EngineError
from video_engine.process import CommandRunner
from video_engine.render.models import RenderRequest
from video_engine.render.nodes import NodeKind


def create_gray_source(path: Path, *, pixel_format: str) -> None:
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=gray:s=160x90:r=24:d=1",
            "-vf",
            f"format={pixel_format}",
            "-c:v",
            "ffv1",
            "-level",
            "3",
            "-pix_fmt",
            pixel_format,
            str(path),
        ],
        check=True,
    )


def extract_frame(source: Path, destination: Path) -> None:
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-ss",
            "0.5",
            "-i",
            str(source),
            "-frames:v",
            "1",
            str(destination),
        ],
        check=True,
    )


@pytest.mark.integration
def test_color_analysis_normalizes_bit_depth_and_recovers_corrupt_cache(
    tmp_path: Path,
) -> None:
    source_8 = tmp_path / "gray-8.mkv"
    source_10 = tmp_path / "gray-10.mkv"
    create_gray_source(source_8, pixel_format="yuv420p")
    create_gray_source(source_10, pixel_format="yuv420p10le")
    engine = VideoEngine(tmp_path / "engine")
    service = engine.color()

    first = service.analyze(source_8, sample_count=4)
    cached = service.analyze(source_8, sample_count=4)
    ten_bit = service.analyze(source_10, sample_count=4)
    assert first.bit_depth == 8
    assert ten_bit.bit_depth == 10
    assert first.frames_analyzed == first.requested_samples == 4
    assert ten_bit.frames_analyzed == ten_bit.requested_samples == 4
    assert first.y_mean == pytest.approx(ten_bit.y_mean, abs=0.01)
    assert not first.cache_hit
    assert cached.cache_hit

    cache_path = engine.config.cache_dir / "color-analysis" / f"{first.cache_key}.json"
    cache_path.write_text("{corrupt", encoding="ascii")
    rebuilt = service.analyze(source_8, sample_count=4)
    assert not rebuilt.cache_hit
    assert rebuilt == first
    assert list(cache_path.parent.glob(f".{cache_path.name}.corrupt-*"))

    equivalent_range = TimeRange(
        start=RationalTime(value=0, timescale=24),
        duration=RationalTime(value=24, timescale=24),
    )
    equivalent = service.analyze(
        source_8,
        source_range=equivalent_range,
        sample_count=4,
    )
    assert equivalent.cache_key == first.cache_key
    assert equivalent.cache_hit

    with pytest.raises(EngineError, match="exceeds the source duration"):
        service.analyze(
            source_8,
            source_range=TimeRange(
                start=RationalTime(value=1, timescale=2),
                duration=RationalTime(value=1, timescale=1),
            ),
            sample_count=4,
        )


@pytest.mark.integration
def test_color_analysis_decodes_verified_snapshot_when_original_mutates(
    tmp_path: Path,
) -> None:
    source = tmp_path / "mutable-source.mkv"
    create_gray_source(source, pixel_format="yuv420p")
    original_sha256 = hashlib.sha256(source.read_bytes()).hexdigest()

    class MutatingRunner(CommandRunner):
        mutated = False

        def run(self, command: Any, **kwargs: Any) -> Any:
            if not self.mutated and any("signalstats" in str(part) for part in command):
                source.write_bytes(b"mutated after snapshot publication")
                self.mutated = True
            return super().run(command, **kwargs)

    runner = MutatingRunner()
    service = ColorService(tmp_path / "engine", runner=runner)
    measured = service.analyze(source, sample_count=2)

    assert runner.mutated
    assert measured.source_sha256 == original_sha256
    snapshot = (
        service.config.cache_dir
        / "source-snapshots"
        / original_sha256[:2]
        / f"{original_sha256}{source.suffix}"
    )
    assert snapshot.is_file()
    assert hashlib.sha256(snapshot.read_bytes()).hexdigest() == original_sha256
    assert measured.frames_analyzed == 2


@pytest.mark.integration
def test_measured_auto_grade_executes_typed_gamma_in_ffmpeg(tmp_path: Path) -> None:
    source = tmp_path / "dark-source.mkv"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=0x303030:s=160x90:r=24:d=1",
            "-c:v",
            "ffv1",
            "-pix_fmt",
            "yuv420p",
            str(source),
        ],
        check=True,
    )
    engine = VideoEngine(tmp_path / "render-engine")
    media = engine.media().import_media(source)
    project = engine.create_project(
        "Measured grade", width=160, height=90, frame_rate=FrameRate(numerator=24)
    )
    project.media.append(engine.media().to_media_reference(media))
    clip_range = TimeRange(
        start=RationalTime.zero(),
        duration=RationalTime(value=1, timescale=1),
    )
    measured = engine.color().auto_grade(source, source_range=clip_range, sample_count=4)
    assert measured.grade.gamma > 1
    assert measured.effect.extensions["auto_grade_policy"] == measured.policy.model_dump(
        mode="json"
    )
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="video",
            items=[
                Clip(
                    id="dark",
                    media_reference_id=media.id,
                    timeline_range=clip_range,
                    source_range=clip_range,
                    source_audio_enabled=False,
                    effects=[measured.effect],
                )
            ],
        )
    ]
    output = tmp_path / "measured-grade.mp4"
    result = engine.renderer(project).render(RenderRequest(output_path=output, sectioning=False))
    assert any(
        record.node_type is NodeKind.GRADE and record.status == "succeeded"
        for record in result.manifest.records
    )
    source_frame = tmp_path / "dark-source.png"
    output_frame = tmp_path / "measured-grade.png"
    extract_frame(source, source_frame)
    extract_frame(output, output_frame)
    source_pixel = Image.open(source_frame).convert("L").getpixel((80, 45))
    output_pixel = Image.open(output_frame).convert("L").getpixel((80, 45))
    assert output_pixel > source_pixel
