from __future__ import annotations

import os
import shutil
from pathlib import Path

import pytest

from video_engine.config import EngineConfig
from video_engine.core.time import FrameRate, RationalTime
from video_engine.graphics.models import GraphicAsset, GraphicRenderer
from video_engine.process import CommandRunner
from video_engine.render.backends.blender import BlenderBackend
from video_engine.render.cache import sha256_file
from video_engine.render.nodes import ArtifactType, MotionGraphicNode

pytestmark = pytest.mark.skipif(
    os.environ.get("VIDEO_ENGINE_RUN_BLENDER_INTEGRATION") != "1",
    reason="real Blender execution is opt-in",
)


def test_blender_backend_renders_valid_alpha_range(tmp_path: Path) -> None:
    configured_blender = os.environ["VIDEO_ENGINE_BLENDER"]
    discovered_blender = shutil.which(configured_blender)
    blender = Path(discovered_blender or configured_blender).resolve()
    assert blender.is_file()
    configured_fixture = os.environ.get("VIDEO_ENGINE_BLENDER_FIXTURE")
    if configured_fixture is not None:
        blend = Path(configured_fixture).resolve()
    else:
        blend = tmp_path / "scene.blend"
        fixture_script = ";".join(
            [
                "import bpy",
                "bpy.ops.wm.read_factory_settings(use_empty=False)",
                "bpy.ops.wm.save_as_mainfile(filepath=" + repr(str(blend)) + ")",
            ]
        )
        CommandRunner().run(
            [blender, "--background", "--factory-startup", "--python-expr", fixture_script],
            timeout=180,
        )
    assert blend.is_file()
    node = MotionGraphicNode(
        id="blender",
        artifact_type=ArtifactType.VIDEO,
        component_id="blender_scene",
        component_version="1.0.0",
        component_digest="a" * 64,
        renderer=GraphicRenderer.BLENDER,
        props={
            "source_asset_id": "source",
            "render_engine": "BLENDER_WORKBENCH",
            "samples": 8,
        },
        assets=(
            GraphicAsset(
                id="source",
                source_path=blend,
                sha256=sha256_file(blend),
                media_type="data",
                staged_name="scene.blend",
            ),
        ),
        duration=RationalTime(value=1, timescale=1),
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
        composition_duration_frames=24,
        render_duration_frames=24,
        transparent=True,
    )
    work_dir = tmp_path / "work"
    work_dir.mkdir()
    backend = BlenderBackend(EngineConfig(blender_path=str(blender)), Path.cwd())
    execution = backend.execute(node, (), work_dir / "output.mov", work_dir)
    assert execution.path.is_file()
    assert execution.metadata["renderer"] == "blender"
    assert execution.metadata["frame_count"] == 24
    assert execution.metadata["has_alpha"] is True
