from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.support.legacy_fixtures import build_legacy_workspace
from video_engine.api.engine import VideoEngine
from video_engine.cli.main import main
from video_engine.core.schema import (
    AudioRole,
    AudioTrack,
    CaptionCue,
    CaptionTrack,
    Clip,
    EffectKind,
    GeneratorClip,
    GraphicsTrack,
    VideoTrack,
)
from video_engine.core.time import RationalTime


@pytest.fixture(scope="module")
def adapter_workspace(tmp_path_factory: pytest.TempPathFactory) -> dict[str, Path]:
    return build_legacy_workspace(tmp_path_factory.mktemp("canonical-adapters"))


@pytest.mark.integration
def test_existing_edl_import_preserves_executable_tracks(
    adapter_workspace: dict[str, Path],
) -> None:
    root = adapter_workspace["root"] / "engine-existing"
    result = VideoEngine(root).adapters().import_legacy_edl(adapter_workspace["existing_edl"])
    project = result.project

    assert result.report.valid
    assert project.settings.frame_rate.numerator == 24
    assert project.settings.audio_sample_rate == 48_000
    assert (project.settings.width, project.settings.height) == (320, 180)
    assert project.sequence().timeline.duration == RationalTime(value=29, timescale=12)
    video = next(
        track for track in project.sequence().timeline.tracks if isinstance(track, VideoTrack)
    )
    assert len(video.items) == 3
    assert all(isinstance(item, Clip) and item.source_audio_enabled for item in video.items)
    assert any(isinstance(track, GraphicsTrack) for track in project.sequence().timeline.tracks)
    assert any(
        isinstance(track, AudioTrack) and track.role is AudioRole.SFX
        for track in project.sequence().timeline.tracks
    )
    captions = next(
        track for track in project.sequence().timeline.tracks if isinstance(track, CaptionTrack)
    )
    assert len(captions.items) == 2
    assert all(isinstance(cue, CaptionCue) for cue in captions.items)


@pytest.mark.integration
def test_existing_edl_adapter_handles_aliases_focus_zero_and_typed_grade(
    adapter_workspace: dict[str, Path], tmp_path: Path
) -> None:
    payload = json.loads(adapter_workspace["base_edl"].read_text(encoding="utf-8"))
    payload["ranges"] = [
        {
            "source": "a",
            "start": 0,
            "end": 1,
            "crop": {"left": 1, "top": 3, "width": 101, "height": 99},
        }
    ]
    payload["reframe"] = {"focus_x": "0", "focus_y": 1}
    payload["grade"] = "subtle"
    payload["sound_effects"] = []
    payload["sfx"] = [
        {
            "file": str(adapter_workspace["assets"] / "sfx.wav"),
            "start": 0.25,
            "volume": 0.5,
        }
    ]
    payload["subtitles"] = "missing.srt"
    path = tmp_path / "aliases.json"
    path.write_text(json.dumps(payload), encoding="utf-8")

    result = VideoEngine(tmp_path / "engine").adapters().import_legacy_edl(path)
    video = next(
        track
        for track in result.project.sequence().timeline.tracks
        if isinstance(track, VideoTrack)
    )
    clip = video.items[0]
    assert isinstance(clip, Clip)
    effects = {effect.kind: effect for effect in clip.effects}
    assert effects[EffectKind.REFRAME].parameters["focus_x"] == 0
    assert effects[EffectKind.REFRAME].parameters["focus_y"] == 1
    assert effects[EffectKind.CROP].parameters == {
        "width": 101,
        "height": 99,
        "x": 1,
        "y": 3,
        "space": "source",
    }
    assert effects[EffectKind.COLOR_GRADE].parameters == {
        "contrast": 1.03,
        "saturation": 0.98,
    }
    assert any(issue.code == "legacy.focus_zero_corrected" for issue in result.report.issues)
    assert any(issue.code == "legacy.subtitle_missing" for issue in result.report.issues)
    sfx_track = next(
        track
        for track in result.project.sequence().timeline.tracks
        if isinstance(track, AudioTrack) and track.role is AudioRole.SFX
    )
    assert sfx_track.items[0].timeline_range.start == RationalTime(value=1, timescale=4)


@pytest.mark.integration
def test_existing_edl_auto_grade_is_measured_per_source_range(
    adapter_workspace: dict[str, Path], tmp_path: Path
) -> None:
    payload = json.loads(adapter_workspace["base_edl"].read_text(encoding="utf-8"))
    payload["ranges"] = [{"source": "a", "start": 0, "end": 1}]
    payload["grade"] = "auto"
    payload["sound_effects"] = []
    payload["subtitles"] = ""
    path = tmp_path / "measured-auto.json"
    path.write_text(json.dumps(payload), encoding="utf-8")

    result = VideoEngine(tmp_path / "engine-auto").adapters().import_legacy_edl(path)
    video = next(
        track
        for track in result.project.sequence().timeline.tracks
        if isinstance(track, VideoTrack)
    )
    clip = video.items[0]
    assert isinstance(clip, Clip)
    grade = next(effect for effect in clip.effects if effect.kind is EffectKind.COLOR_GRADE)
    assert set(grade.parameters) == {
        "exposure_stops",
        "temperature",
        "tint",
        "contrast",
        "gamma",
        "saturation",
        "highlights",
        "shadows",
    }
    evidence = grade.extensions["color_measurements"]
    assert isinstance(evidence, dict)
    assert evidence["frames_analyzed"] > 0
    source_range = evidence["source_range"]
    assert isinstance(source_range, dict)
    duration = source_range["duration"]
    assert isinstance(duration, dict)
    assert duration["value"] / duration["timescale"] == 1
    issue = next(
        issue for issue in result.report.issues if issue.code == "legacy.auto_grade_measured"
    )
    assert issue.disposition.value == "improved"
    assert "storage pixel depth" in str(issue.details["improvement"])


@pytest.mark.integration
def test_faceless_import_materializes_deterministic_sfx_and_designed_captions(
    adapter_workspace: dict[str, Path],
) -> None:
    project_dir = adapter_workspace["faceless"]
    root = adapter_workspace["root"] / "engine-faceless"
    result = (
        VideoEngine(root)
        .adapters()
        .import_faceless(
            project_dir,
            voiceover=project_dir / "assets" / "audio" / "voiceover.wav",
        )
    )

    assert result.report.valid
    assert result.project.sequence().timeline.duration == RationalTime(value=2, timescale=1)
    sfx = next(
        track
        for track in result.project.sequence().timeline.tracks
        if isinstance(track, AudioTrack) and track.role is AudioRole.SFX
    )
    assert sfx.extensions["sha256"] == (
        "3e067bee0db92893bb0ad4a1feccd41186fe89397f3a3ca542b6d6c5c1f9571b"
    )
    caption_track = next(
        track
        for track in result.project.sequence().timeline.tracks
        if isinstance(track, CaptionTrack)
    )
    assert all(isinstance(cue, CaptionCue) and cue.suppressed for cue in caption_track.items)
    designed = [
        item
        for track in result.project.sequence().timeline.tracks
        if isinstance(track, GraphicsTrack)
        for item in track.items
        if isinstance(item, GeneratorClip) and item.generator_id == "kinetic_caption"
    ]
    assert len(designed) == 2
    assert any(issue.code == "faceless.rich_captions_remotion" for issue in result.report.issues)


@pytest.mark.integration
def test_migrate_cli_writes_project_and_loss_report(
    adapter_workspace: dict[str, Path], tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    project_path = tmp_path / "canonical.json"
    report_path = tmp_path / "migration.json"
    exit_code = main(
        [
            "migrate",
            "legacy-edl",
            str(adapter_workspace["base_edl"]),
            "--project-root",
            str(tmp_path / "engine"),
            "--output",
            str(project_path),
            "--report",
            str(report_path),
            "--json",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["ok"] is True
    assert payload["adapter"] == "legacy_edl"
    assert project_path.is_file()
    assert report_path.is_file()
    assert (
        json.loads(report_path.read_text(encoding="utf-8"))["source_sha256"]
        == payload["source_sha256"]
    )
