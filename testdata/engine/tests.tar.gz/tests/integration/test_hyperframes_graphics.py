from __future__ import annotations

import os
import shutil
from pathlib import Path

import pytest

from video_engine.config import EngineConfig
from video_engine.core.time import FrameRate, RationalTime
from video_engine.graphics.models import GraphicAsset, GraphicRenderer
from video_engine.render.backends.hyperframes import HyperFramesBackend
from video_engine.render.cache import sha256_file
from video_engine.render.nodes import ArtifactType, MotionGraphicNode

pytestmark = pytest.mark.skipif(
    os.environ.get("VIDEO_ENGINE_RUN_HYPERFRAMES_INTEGRATION") != "1",
    reason="real HyperFrames/Chrome execution is opt-in",
)


def test_hyperframes_backend_renders_valid_alpha_range(tmp_path: Path) -> None:
    entry = tmp_path / "entry.html"
    entry.write_text(
        """<!doctype html>
<html lang="en">
<head>
<meta name="viewport" content="width=320, height=180" />
<script src="gsap.min.js"></script>
<style>
html,body{margin:0;width:320px;height:180px;overflow:hidden;background:transparent}
.clip{visibility:hidden}
#title{position:absolute;left:24px;top:55px;color:#fff;font:700 32px sans-serif}
</style>
</head>
<body>
<div id="stage" data-composition-id="engine-test" data-start="0"
  data-width="320" data-height="180">
<div id="title" class="clip" data-start="0" data-duration="1" data-track-index="1">ENGINE</div>
</div>
<script>
const tl=gsap.timeline({paused:true});
tl.fromTo('#title',{opacity:0,x:-20},{opacity:1,x:0,duration:0.5},0);
tl.to('#title',{opacity:1,duration:0.5},0.5);
window.__timelines=window.__timelines||{};window.__timelines['engine-test']=tl;
</script></body></html>""",
        encoding="utf-8",
    )
    gsap = Path("node_modules/gsap/dist/gsap.min.js").resolve()
    browser = next(
        path.resolve()
        for root in (Path.home() / ".cache" / "ms-playwright", Path("node_modules/.remotion"))
        if root.is_dir()
        for path in root.glob("**/chrome-headless-shell")
    )
    node = MotionGraphicNode(
        id="hyperframes",
        artifact_type=ArtifactType.VIDEO,
        component_id="hyperframes_composition",
        component_version="1.0.0",
        component_digest="a" * 64,
        renderer=GraphicRenderer.HYPERFRAMES,
        props={
            "source_asset_id": "source",
            "asset_bindings": {"gsap.min.js": "gsap"},
            "quality": "draft",
            "workers": 1,
            "strictness": "best-effort",
        },
        assets=(
            GraphicAsset(
                id="source",
                source_path=entry,
                sha256=sha256_file(entry),
                media_type="data",
                staged_name="entry.html",
            ),
            GraphicAsset(
                id="gsap",
                source_path=gsap,
                sha256=sha256_file(gsap),
                media_type="data",
                staged_name="gsap.min.js",
            ),
        ),
        duration=RationalTime(value=1, timescale=1),
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
        composition_duration_frames=24,
        render_duration_frames=24,
        transparent=True,
    )
    work_dir = tmp_path / "work"
    work_dir.mkdir()
    backend = HyperFramesBackend(
        EngineConfig(hyperframes_browser_path=browser),
        Path.cwd(),
    )
    execution = backend.execute(node, (), work_dir / "output.mov", work_dir)
    assert execution.path.is_file()
    assert execution.metadata["renderer"] == "hyperframes"
    assert execution.metadata["frame_count"] == 24
    assert execution.metadata["has_alpha"] is True
    shutil.rmtree(work_dir)
