from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest

from video_engine.api.engine import VideoEngine
from video_engine.cli.main import main
from video_engine.core.schema import (
    CaptionCue,
    CaptionTrack,
    Clip,
    Marker,
    Transition,
    TransitionKind,
    VideoTrack,
)
from video_engine.core.time import FrameRate, RationalTime, TimeRange
from video_engine.inspection.models import InspectionKind, InspectionRequest, InspectionStatus


def rt(value: int, timescale: int = 24) -> RationalTime:
    return RationalTime(value=value, timescale=timescale)


@pytest.fixture
def inspection_fixture(tmp_path: Path) -> tuple[VideoEngine, Path, Path]:
    media = tmp_path / "inspection-source.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "testsrc2=size=320x180:rate=24:duration=1",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=880:sample_rate=48000:duration=1",
            "-filter_complex",
            "[1:a]aformat=channel_layouts=stereo[a]",
            "-map",
            "0:v:0",
            "-map",
            "[a]",
            "-c:v",
            "libx264",
            "-preset",
            "ultrafast",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-ar",
            "48000",
            "-shortest",
            media,
        ],
        check=True,
    )
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Inspection Integration",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    record = engine.media().import_media(media)
    project.media.append(engine.media().to_media_reference(record))
    first = Clip(
        id="first",
        media_reference_id=record.id,
        timeline_range=TimeRange(start=rt(0), duration=rt(12)),
        source_range=TimeRange(start=rt(0), duration=rt(12)),
    )
    second = Clip(
        id="second",
        media_reference_id=record.id,
        timeline_range=TimeRange(start=rt(12), duration=rt(12)),
        source_range=TimeRange(start=rt(12), duration=rt(12)),
    )
    project.sequence().timeline.tracks.extend(
        [
            VideoTrack(
                id="v1",
                items=[first, second],
                transitions=[
                    Transition(
                        id="cut-dissolve",
                        kind=TransitionKind.DISSOLVE,
                        from_item_id="first",
                        to_item_id="second",
                        duration=rt(4),
                    )
                ],
            ),
            CaptionTrack(
                id="captions",
                items=[
                    CaptionCue(
                        id="cue",
                        text="Inspection cue",
                        timeline_range=TimeRange(start=rt(4), duration=rt(12)),
                        speaker="Speaker",
                    )
                ],
            ),
        ]
    )
    project.sequence().timeline.markers.append(Marker(id="cut-marker", time=rt(12)))
    project_path = engine.save_project(project)
    return engine, project_path, media


@pytest.mark.integration
def test_all_inspection_modes_generate_real_hashed_artifacts(
    inspection_fixture: tuple[VideoEngine, Path, Path], tmp_path: Path
) -> None:
    engine, project_path, media = inspection_fixture
    project, _ = engine.load_project(project_path)
    requests = [
        InspectionRequest(kind=InspectionKind.TIMELINE, output_dir=tmp_path / "timeline"),
        InspectionRequest(
            kind=InspectionKind.RANGE,
            media_path=media,
            timeline_range=TimeRange(start=rt(0), duration=rt(24)),
            output_dir=tmp_path / "range",
            frame_count=6,
            peak_buckets=32,
        ),
        InspectionRequest(
            kind=InspectionKind.CUT,
            media_path=media,
            cut_time=rt(12),
            cut_window=rt(12),
            output_dir=tmp_path / "cut",
            frame_count=4,
            peak_buckets=32,
        ),
        InspectionRequest(
            kind=InspectionKind.AUDIO,
            media_path=media,
            output_dir=tmp_path / "audio",
            peak_buckets=32,
        ),
        InspectionRequest(kind=InspectionKind.CAPTIONS, output_dir=tmp_path / "captions"),
    ]
    results = [engine.inspection(project).inspect(request) for request in requests]

    assert all(result.status is InspectionStatus.COMPLETE for result in results)
    assert all(result.report_json.is_file() for result in results)
    assert all(result.report_markdown.is_file() for result in results)
    assert all(
        artifact.path.is_file() and artifact.size_bytes > 0
        for result in results
        for artifact in result.artifacts
    )
    range_contact_sheet = next(
        artifact for artifact in results[1].artifacts if artifact.kind == "inspection_contact_sheet"
    )
    assert range_contact_sheet.path.name == "inspection-contact-sheet.png"
    range_payload = json.loads((tmp_path / "range" / "range.json").read_text())
    assert [sample["frame_index"] for sample in range_payload["frame_samples"]] == [
        0,
        4,
        8,
        12,
        16,
        20,
    ]
    cut_payload = json.loads((tmp_path / "cut" / "cut.json").read_text())
    cut_frames = [sample["frame_index"] for sample in cut_payload["frame_samples"]]
    assert {10, 11, 12, 13}.issubset(cut_frames)
    peaks = json.loads((tmp_path / "audio" / "audio-peaks.json").read_text())
    assert peaks["sample_rate"] == 48_000
    assert peaks["channels"] == 2
    assert peaks["sample_count"] == 48_000
    assert len(peaks["absolute_peak"]) == 2


@pytest.mark.integration
def test_all_inspection_cli_commands_emit_json(
    inspection_fixture: tuple[VideoEngine, Path, Path],
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    _, project_path, media = inspection_fixture
    commands = [
        ["inspect", "timeline", str(project_path)],
        [
            "inspect",
            "range",
            str(project_path),
            str(media),
            "--start",
            "0",
            "--duration",
            "1",
            "--frames",
            "4",
            "--peak-buckets",
            "16",
        ],
        [
            "inspect",
            "cut",
            str(project_path),
            str(media),
            "--at",
            "1/2",
            "--window",
            "1",
            "--frames",
            "4",
            "--peak-buckets",
            "16",
        ],
        [
            "inspect",
            "audio",
            str(project_path),
            str(media),
            "--peak-buckets",
            "16",
        ],
        ["inspect", "captions", str(project_path)],
    ]
    for index, command in enumerate(commands):
        exit_code = main(
            [
                *command,
                "--output-dir",
                str(tmp_path / f"cli-{index}"),
                "--json",
            ]
        )
        payload = json.loads(capsys.readouterr().out)
        assert exit_code == 0
        assert payload["ok"] is True
        assert payload["status"] == "complete"
        assert Path(payload["report_json"]).is_file()
