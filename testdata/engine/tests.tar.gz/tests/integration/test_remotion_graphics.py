from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any

import pytest
from PIL import Image

from video_engine.api.engine import VideoEngine
from video_engine.core.schema import (
    GeneratorAssetReference,
    GeneratorClip,
    GraphicsTrack,
    MediaReference,
)
from video_engine.core.time import FrameRate, RationalTime, TimeRange
from video_engine.render.cache import sha256_file
from video_engine.render.models import RenderMode, RenderRequest


def frames(value: int) -> RationalTime:
    return RationalTime(value=value, timescale=24)


def probe(path: Path) -> dict[str, Any]:
    completed = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_format",
            "-show_streams",
            "-of",
            "json",
            str(path),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(completed.stdout)


@pytest.mark.integration
def test_remotion_range_render_preserves_alpha_and_composites_with_ffmpeg(
    tmp_path: Path,
) -> None:
    if os.environ.get("VIDEO_ENGINE_RUN_REMOTION_INTEGRATION") != "1":
        pytest.skip("set VIDEO_ENGINE_RUN_REMOTION_INTEGRATION=1 with a runnable browser")

    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Remotion Integration",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    project.sequence().timeline.tracks = [
        GraphicsTrack(
            id="graphics",
            items=[
                GeneratorClip(
                    id="title",
                    generator_id="title_card",
                    timeline_range=TimeRange(start=frames(0), duration=frames(48)),
                    properties={
                        "title": "RANGE FRAME 24",
                        "subtitle": "Structured Remotion props",
                        "accent_color": "#00C2A8",
                        "background_color": "#111111",
                    },
                    transparent=True,
                )
            ],
        )
    ]
    result = engine.renderer(project).render(
        RenderRequest(
            output_path=tmp_path / "mixed-range.mp4",
            mode=RenderMode.RANGE,
            timeline_range=TimeRange(start=frames(24), duration=frames(24)),
        )
    )

    assert {record.backend for record in result.manifest.records} == {"ffmpeg", "remotion"}
    motion_record = next(
        record for record in result.manifest.records if record.node_type.value == "motion_graphic"
    )
    assert motion_record.artifact_path is not None
    bounds = motion_record.artifact_metadata["content_bounds"]
    assert isinstance(bounds, dict)
    assert bounds["available"] is True
    assert bounds["frame_bounds_count"] > 0
    motion_metadata = probe(motion_record.artifact_path)
    motion_video = next(
        stream for stream in motion_metadata["streams"] if stream["codec_type"] == "video"
    )
    assert motion_video["codec_name"] == "prores"
    assert motion_video["pix_fmt"].startswith("yuva444p")
    assert int(motion_video["nb_frames"]) == 24
    assert abs(float(motion_metadata["format"]["duration"]) - 1.0) <= 0.01

    alpha = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(motion_record.artifact_path),
            "-vf",
            "alphaextract",
            "-frames:v",
            "1",
            "-pix_fmt",
            "gray",
            "-f",
            "rawvideo",
            "-",
        ],
        check=True,
        capture_output=True,
    ).stdout
    assert alpha
    assert min(alpha) == 0
    assert max(alpha) > 200
    width, height, safe_edge = 320, 180, 6
    edge_pixels = (
        alpha[: width * safe_edge]
        + alpha[width * (height - safe_edge) :]
        + b"".join(
            alpha[row * width : row * width + safe_edge]
            + alpha[(row + 1) * width - safe_edge : (row + 1) * width]
            for row in range(height)
        )
    )
    assert max(edge_pixels) == 0

    output_metadata = probe(result.output_path)
    output_video = next(
        stream for stream in output_metadata["streams"] if stream["codec_type"] == "video"
    )
    assert (output_video["width"], output_video["height"]) == (320, 180)
    assert output_video["avg_frame_rate"] == "24/1"
    assert abs(float(output_metadata["format"]["duration"]) - 1.0) <= 0.03

    rgb = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-ss",
            "0.5",
            "-i",
            str(result.output_path),
            "-frames:v",
            "1",
            "-pix_fmt",
            "rgb24",
            "-f",
            "rawvideo",
            "-",
        ],
        check=True,
        capture_output=True,
    ).stdout
    lower_text_region = rgb[width * 3 * 92 : width * 3 * 145]
    bright_pixels = sum(
        1
        for offset in range(0, len(lower_text_region), 3)
        if max(lower_text_region[offset : offset + 3]) > 210
    )
    assert bright_pixels > 20


@pytest.mark.integration
def test_asset_component_supports_aliases_and_render_cache(tmp_path: Path) -> None:
    if os.environ.get("VIDEO_ENGINE_RUN_REMOTION_INTEGRATION") != "1":
        pytest.skip("set VIDEO_ENGINE_RUN_REMOTION_INTEGRATION=1 with a runnable browser")

    image_path = tmp_path / "source.png"
    Image.new("RGB", (160, 90), (12, 190, 152)).save(image_path)
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Remotion Asset Integration",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    project.media = [
        MediaReference(
            id="shared-image",
            uri=str(image_path),
            sha256=sha256_file(image_path),
        )
    ]
    project.sequence().timeline.tracks = [
        GraphicsTrack(
            id="graphics",
            items=[
                GeneratorClip(
                    id="split",
                    generator_id="split_screen",
                    timeline_range=TimeRange(start=frames(0), duration=frames(12)),
                    properties={
                        "left_asset_id": "left",
                        "right_asset_id": "right",
                    },
                    assets=[
                        GeneratorAssetReference(id="left", media_reference_id="shared-image"),
                        GeneratorAssetReference(id="right", media_reference_id="shared-image"),
                    ],
                    transparent=False,
                )
            ],
        )
    ]
    service = engine.renderer(project)
    first = service.render(RenderRequest(output_path=tmp_path / "split-first.mp4"))
    first_motion = next(
        record for record in first.manifest.records if record.node_type.value == "motion_graphic"
    )
    assert first_motion.cached is False

    second = service.render(RenderRequest(output_path=tmp_path / "split-second.mp4"))
    second_motion = next(
        record for record in second.manifest.records if record.node_type.value == "motion_graphic"
    )
    assert second_motion.cached is True
    assert second_motion.artifact_metadata["content_bounds"] == (
        first_motion.artifact_metadata["content_bounds"]
    )
    assert second.manifest.output_sha256 == first.manifest.output_sha256
