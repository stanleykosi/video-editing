"""Small canonical projects exercising distinct professional editing workflows."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from scripts.baseline_bundle import materialize_baseline
from video_engine.api.engine import VideoEngine
from video_engine.core.schema import (
    AdjustmentClip,
    AdjustmentTrack,
    AudioBus,
    AudioClip,
    AudioRole,
    AudioTrack,
    CaptionCue,
    CaptionTrack,
    Clip,
    Effect,
    EffectKind,
    GeneratorClip,
    GraphicsTrack,
    Marker,
    NestedSequenceClip,
    Project,
    Sequence,
    Timeline,
    Transition,
    TransitionKind,
    VideoTrack,
)
from video_engine.core.time import FrameRate, RationalTime, TimeRange

ROOT = Path(__file__).resolve().parents[2]
ASSETS = materialize_baseline() / "workspace"


@dataclass(frozen=True)
class GoldenProject:
    id: str
    project: Project
    expected_frames: int
    expected_dimensions: tuple[int, int]
    required_node_kinds: tuple[str, ...]
    frame_samples: tuple[int, ...]
    audio_frequencies_hz: tuple[int, ...]
    browser_required: bool = False
    section_duration_frames: int | None = None
    audio_windows: tuple[AudioWindow, ...] = ()


@dataclass(frozen=True)
class AudioWindow:
    start_sample: int
    end_sample: int
    present_frequencies_hz: tuple[int, ...] = ()
    absent_frequencies_hz: tuple[int, ...] = ()
    present_minimum_db: float = -18
    absent_maximum_db: float = -28


def _rate(project: Project) -> FrameRate:
    return project.settings.frame_rate


def _frames(project: Project, value: int) -> RationalTime:
    return _rate(project).frames_to_time(value)


def _range(project: Project, start: int, duration: int) -> TimeRange:
    return TimeRange(start=_frames(project, start), duration=_frames(project, duration))


def _media(engine: VideoEngine, project: Project, path: Path) -> str:
    record = engine.media().import_media(path)
    if all(item.id != record.id for item in project.media):
        project.media.append(engine.media().to_media_reference(record))
    return record.id


def _clip(
    project: Project,
    *,
    clip_id: str,
    media_id: str,
    start: int,
    duration: int,
    source_start: int = 0,
    source_audio: bool = True,
) -> Clip:
    return Clip(
        id=clip_id,
        media_reference_id=media_id,
        timeline_range=_range(project, start, duration),
        source_range=_range(project, source_start, duration),
        source_audio_enabled=source_audio,
    )


def _audio(
    project: Project,
    *,
    clip_id: str,
    media_id: str,
    start: RationalTime,
    duration: RationalTime,
    role: AudioRole,
    bus_id: str,
    source_start: RationalTime | None = None,
    replaces: str | None = None,
) -> AudioClip:
    return AudioClip(
        id=clip_id,
        media_reference_id=media_id,
        timeline_range=TimeRange(start=start, duration=duration),
        source_range=TimeRange(start=source_start or RationalTime.zero(), duration=duration),
        role=role,
        bus_id=bus_id,
        replaces_embedded_audio_item_id=replaces,
    )


def build_podcast(engine: VideoEngine) -> GoldenProject:
    project = engine.create_project("Golden Podcast", width=180, height=320)
    portrait = _media(engine, project, ASSETS / "faceless" / "assets" / "footage" / "portrait.mp4")
    voice = _media(engine, project, ASSETS / "faceless" / "assets" / "audio" / "voiceover.wav")
    visual = _clip(
        project,
        clip_id="podcast-camera",
        media_id=portrait,
        start=0,
        duration=48,
    )
    project.sequence().timeline.audio_buses = [
        AudioBus(id="master", name="Master"),
        AudioBus(id="dialogue", name="Dialogue", parent_bus_id="master"),
    ]
    project.sequence().timeline.tracks = [
        VideoTrack(id="camera", items=[visual]),
        AudioTrack(
            id="voice-over",
            role=AudioRole.VOICE_OVER,
            bus_id="dialogue",
            items=[
                _audio(
                    project,
                    clip_id="voice",
                    media_id=voice,
                    start=RationalTime.zero(),
                    duration=_frames(project, 48),
                    role=AudioRole.VOICE_OVER,
                    bus_id="dialogue",
                    replaces=visual.id,
                )
            ],
        ),
        CaptionTrack(
            id="captions",
            language="en",
            items=[
                CaptionCue(
                    id="podcast-caption-one",
                    text="CLEAN PODCAST",
                    speaker="Host",
                    timeline_range=_range(project, 4, 18),
                ),
                CaptionCue(
                    id="podcast-caption-two",
                    text="EXACT AUDIO",
                    speaker="Host",
                    timeline_range=_range(project, 26, 18),
                ),
            ],
        ),
    ]
    return GoldenProject(
        "podcast_clip",
        project,
        48,
        (180, 320),
        ("scale", "caption", "audio_mix"),
        (4, 18, 32, 45),
        (330,),
    )


def build_interview(engine: VideoEngine) -> GoldenProject:
    project = engine.create_project("Golden Interview", width=320, height=180)
    first_id = _media(engine, project, ASSETS / "assets" / "landscape_a.mp4")
    second_id = _media(engine, project, ASSETS / "assets" / "landscape_b.mp4")
    first = _clip(
        project,
        clip_id="interview-a",
        media_id=first_id,
        start=0,
        duration=36,
    )
    second = _clip(
        project,
        clip_id="interview-b",
        media_id=second_id,
        start=36,
        duration=36,
        source_start=12,
    )
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="two-camera",
            items=[first, second],
            transitions=[
                Transition(
                    id="camera-dissolve",
                    kind=TransitionKind.DISSOLVE,
                    from_item_id=first.id,
                    to_item_id=second.id,
                    duration=_frames(project, 8),
                )
            ],
        )
    ]
    return GoldenProject(
        "interview_edit",
        project,
        72,
        (320, 180),
        ("transition", "audio_mix"),
        (3, 31, 36, 41, 68),
        (440, 554),
    )


def build_product_ad(engine: VideoEngine) -> GoldenProject:
    project = engine.create_project("Golden Product Ad", width=320, height=180)
    background = _media(engine, project, ASSETS / "assets" / "landscape_a.mp4")
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="background",
            items=[
                _clip(
                    project,
                    clip_id="product-background",
                    media_id=background,
                    start=0,
                    duration=48,
                )
            ],
        ),
        GraphicsTrack(
            id="product-graphics",
            items=[
                GeneratorClip(
                    id="feature-card",
                    generator_id="product_feature",
                    timeline_range=_range(project, 0, 24),
                    properties={
                        "title": "Studio Console",
                        "description": "One precise timeline for every format",
                        "bullets": ["Rational time", "Incremental render"],
                        "accent_color": "#18A999",
                    },
                ),
                GeneratorClip(
                    id="product-cta",
                    generator_id="call_to_action",
                    timeline_range=_range(project, 24, 24),
                    properties={
                        "title": "Shape the final cut",
                        "action": "START EDITING",
                        "detail": "Preview, review, deliver",
                        "accent_color": "#F4C95D",
                    },
                ),
            ],
        ),
    ]
    return GoldenProject(
        "product_ad",
        project,
        48,
        (320, 180),
        ("motion_graphic", "composite"),
        (3, 20, 27, 44),
        (440,),
        browser_required=True,
    )


def build_recap(engine: VideoEngine) -> GoldenProject:
    project = engine.create_project("Golden Recap", width=320, height=180)
    first_id = _media(engine, project, ASSETS / "assets" / "landscape_a.mp4")
    second_id = _media(engine, project, ASSETS / "assets" / "landscape_b.mp4")
    voice = _media(engine, project, ASSETS / "faceless" / "assets" / "audio" / "voiceover.wav")
    clips = [
        _clip(
            project,
            clip_id=f"recap-{index}",
            media_id=first_id if index % 2 == 0 else second_id,
            start=index * 12,
            duration=12,
            source_start=index * 4,
            source_audio=False,
        )
        for index in range(4)
    ]
    project.sequence().timeline.audio_buses = [
        AudioBus(id="master", name="Master"),
        AudioBus(id="dialogue", name="Dialogue", parent_bus_id="master"),
    ]
    project.sequence().timeline.tracks = [
        VideoTrack(id="recap-cuts", items=clips),
        AudioTrack(
            id="narration",
            role=AudioRole.VOICE_OVER,
            bus_id="dialogue",
            items=[
                _audio(
                    project,
                    clip_id="recap-voice",
                    media_id=voice,
                    start=RationalTime.zero(),
                    duration=_frames(project, 48),
                    role=AudioRole.VOICE_OVER,
                    bus_id="dialogue",
                )
            ],
        ),
        CaptionTrack(
            id="recap-captions",
            language="en",
            items=[
                CaptionCue(
                    id=f"recap-cue-{index}",
                    text=text,
                    timeline_range=_range(project, index * 12 + 1, 10),
                )
                for index, text in enumerate(("FIRST", "SECOND", "THIRD", "FINAL"))
            ],
        ),
        AdjustmentTrack(
            id="recap-grade",
            items=[
                AdjustmentClip(
                    id="recap-adjustment",
                    timeline_range=_range(project, 0, 48),
                    effects=[
                        Effect(
                            id="recap-color",
                            kind=EffectKind.COLOR_GRADE,
                            parameters={"contrast": 1.05, "saturation": 0.9},
                        )
                    ],
                )
            ],
        ),
    ]
    return GoldenProject(
        "recap",
        project,
        48,
        (320, 180),
        ("composite", "caption", "grade", "audio_mix"),
        (2, 13, 25, 37, 46),
        (330,),
    )


def build_documentary(engine: VideoEngine) -> GoldenProject:
    project = engine.create_project("Golden Documentary", width=320, height=180)
    first_id = _media(engine, project, ASSETS / "assets" / "landscape_a.mp4")
    second_id = _media(engine, project, ASSETS / "assets" / "landscape_b.mp4")
    chapter_a = Sequence(
        id="chapter-a",
        name="Chapter A",
        timeline=Timeline(
            tracks=[
                VideoTrack(
                    id="chapter-a-video",
                    items=[
                        _clip(
                            project,
                            clip_id="chapter-a-clip",
                            media_id=first_id,
                            start=0,
                            duration=24,
                        )
                    ],
                )
            ]
        ),
    )
    chapter_b = Sequence(
        id="chapter-b",
        name="Chapter B",
        timeline=Timeline(
            tracks=[
                VideoTrack(
                    id="chapter-b-video",
                    items=[
                        _clip(
                            project,
                            clip_id="chapter-b-clip",
                            media_id=second_id,
                            start=0,
                            duration=24,
                            source_start=12,
                        )
                    ],
                )
            ]
        ),
    )
    project.sequences.extend([chapter_a, chapter_b])
    project.sequence().timeline = Timeline(
        tracks=[
            VideoTrack(
                id="documentary-sections",
                items=[
                    NestedSequenceClip(
                        id="documentary-a",
                        sequence_id="chapter-a",
                        timeline_range=_range(project, 0, 24),
                        source_range=_range(project, 0, 24),
                    ),
                    NestedSequenceClip(
                        id="documentary-b",
                        sequence_id="chapter-b",
                        timeline_range=_range(project, 24, 24),
                        source_range=_range(project, 0, 24),
                    ),
                ],
            )
        ],
        markers=[
            Marker(
                id="opening",
                name="Opening",
                time=_frames(project, 0),
                extensions={"kind": "chapter"},
            ),
            Marker(
                id="evidence",
                name="Evidence",
                time=_frames(project, 24),
                extensions={"kind": "chapter"},
            ),
        ],
    )
    return GoldenProject(
        "documentary",
        project,
        48,
        (320, 180),
        ("concat", "audio_mix"),
        (3, 21, 27, 44),
        (440, 554),
    )


def build_motion_graphics(engine: VideoEngine) -> GoldenProject:
    project = engine.create_project("Golden Motion Graphics", width=320, height=180)
    project.sequence().timeline.tracks = [
        GraphicsTrack(
            id="graphics-led",
            items=[
                GeneratorClip(
                    id="motion-title",
                    generator_id="title_card",
                    timeline_range=_range(project, 0, 16),
                    properties={
                        "title": "MOTION SYSTEM",
                        "subtitle": "Structured and cacheable",
                        "alignment": "center",
                    },
                ),
                GeneratorClip(
                    id="motion-stat",
                    generator_id="stat_card",
                    timeline_range=_range(project, 16, 16),
                    properties={"value": "24/1", "label": "Exact frame clock"},
                ),
                GeneratorClip(
                    id="motion-countdown",
                    generator_id="countdown",
                    timeline_range=_range(project, 32, 16),
                    properties={"from_number": 3, "label": "Deliver"},
                ),
            ],
        )
    ]
    return GoldenProject(
        "motion_graphics_video",
        project,
        48,
        (320, 180),
        ("motion_graphic", "composite"),
        (3, 18, 34, 46),
        (),
        browser_required=True,
    )


def build_long_form(engine: VideoEngine) -> GoldenProject:
    project = engine.create_project("Golden Long Form", width=320, height=180)
    source_id = _media(engine, project, ASSETS / "assets" / "landscape_a.mp4")
    reusable = Sequence(
        id="reusable-section",
        name="Reusable Section",
        timeline=Timeline(
            tracks=[
                VideoTrack(
                    id="section-video",
                    items=[
                        _clip(
                            project,
                            clip_id="section-source",
                            media_id=source_id,
                            start=0,
                            duration=24,
                        )
                    ],
                )
            ]
        ),
    )
    project.sequences.append(reusable)
    project.sequence().timeline = Timeline(
        tracks=[
            VideoTrack(
                id="long-form-sections",
                items=[
                    NestedSequenceClip(
                        id=f"long-section-{index}",
                        sequence_id=reusable.id,
                        timeline_range=_range(project, index * 24, 24),
                        source_range=_range(project, 0, 24),
                    )
                    for index in range(6)
                ],
            )
        ],
        markers=[
            Marker(
                id=f"chapter-{index}",
                name=f"Chapter {index + 1}",
                time=_frames(project, index * 48),
                extensions={"kind": "chapter"},
            )
            for index in range(3)
        ],
    )
    return GoldenProject(
        "long_form_sequence",
        project,
        144,
        (320, 180),
        ("concat", "audio_mix"),
        (3, 47, 71, 95, 140),
        (440,),
        section_duration_frames=48,
    )


def build_hdr_to_sdr(engine: VideoEngine) -> GoldenProject:
    project = engine.create_project("Golden HDR to SDR", width=320, height=180)
    source_id = _media(engine, project, ASSETS / "assets" / "hlg.mkv")
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="hdr-source",
            items=[
                _clip(
                    project,
                    clip_id="hlg-clip",
                    media_id=source_id,
                    start=0,
                    duration=24,
                )
            ],
        )
    ]
    return GoldenProject(
        "hdr_to_sdr_project",
        project,
        24,
        (320, 180),
        ("color_conversion", "output_transform"),
        (2, 8, 16, 22),
        (300,),
    )


def build_mixed_frame_rate(engine: VideoEngine) -> GoldenProject:
    rate = FrameRate.fps_23_976()
    project = engine.create_project(
        "Golden Mixed Frame Rate", width=320, height=180, frame_rate=rate
    )
    thirty = _media(engine, project, ASSETS / "assets" / "landscape_a.mp4")
    twenty_four = _media(engine, project, ASSETS / "assets" / "hlg.mkv")
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="mixed-sources",
            items=[
                _clip(
                    project,
                    clip_id="thirty-fps",
                    media_id=thirty,
                    start=0,
                    duration=24,
                ),
                _clip(
                    project,
                    clip_id="twenty-four-fps",
                    media_id=twenty_four,
                    start=24,
                    duration=24,
                ),
            ],
        )
    ]
    return GoldenProject(
        "mixed_frame_rate_project",
        project,
        48,
        (320, 180),
        ("conform", "composite"),
        (2, 20, 27, 45),
        (440, 300),
    )


def build_multitrack_audio(engine: VideoEngine) -> GoldenProject:
    project = engine.create_project("Golden Multitrack Audio", width=320, height=180)
    visual_id = _media(engine, project, ASSETS / "assets" / "landscape_a.mp4")
    music_id = _media(engine, project, ASSETS / "assets" / "landscape_b.mp4")
    voice_id = _media(engine, project, ASSETS / "faceless" / "assets" / "audio" / "voiceover.wav")
    sfx_id = _media(engine, project, ASSETS / "assets" / "sfx.wav")
    project.sequence().timeline.audio_buses = [
        AudioBus(id="master", name="Master"),
        AudioBus(id="dialogue", name="Dialogue", parent_bus_id="master"),
        AudioBus(
            id="music",
            name="Music",
            parent_bus_id="master",
            gain_db=-12,
            effects=[
                Effect(
                    id="duck-music",
                    kind=EffectKind.SIDECHAIN_DUCKING,
                    parameters={
                        "key_bus_id": "dialogue",
                        "threshold_db": -40,
                        "ratio": 8,
                        "attack_ms": 5,
                        "release_ms": 60,
                    },
                )
            ],
        ),
        AudioBus(id="sfx", name="SFX", parent_bus_id="master", gain_db=-6),
    ]
    exact_sfx_start = RationalTime(value=24_001, timescale=48_000)
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="picture",
            items=[
                _clip(
                    project,
                    clip_id="audio-picture",
                    media_id=visual_id,
                    start=0,
                    duration=48,
                    source_audio=False,
                )
            ],
        ),
        AudioTrack(
            id="dialogue-track",
            role=AudioRole.DIALOGUE,
            bus_id="dialogue",
            items=[
                _audio(
                    project,
                    clip_id="dialogue",
                    media_id=voice_id,
                    start=RationalTime.zero(),
                    duration=_frames(project, 48),
                    role=AudioRole.DIALOGUE,
                    bus_id="dialogue",
                )
            ],
        ),
        AudioTrack(
            id="music-track",
            role=AudioRole.MUSIC,
            bus_id="music",
            items=[
                _audio(
                    project,
                    clip_id="music",
                    media_id=music_id,
                    start=RationalTime.zero(),
                    duration=_frames(project, 48),
                    role=AudioRole.MUSIC,
                    bus_id="music",
                )
            ],
        ),
        AudioTrack(
            id="sfx-track",
            role=AudioRole.SFX,
            bus_id="sfx",
            items=[
                _audio(
                    project,
                    clip_id="sample-24001-sfx",
                    media_id=sfx_id,
                    start=exact_sfx_start,
                    duration=RationalTime(value=12_000, timescale=48_000),
                    role=AudioRole.SFX,
                    bus_id="sfx",
                )
            ],
        ),
    ]
    return GoldenProject(
        "multitrack_audio_project",
        project,
        48,
        (320, 180),
        ("audio_process", "audio_sidechain", "audio_mix"),
        (3, 20, 30, 45),
        (330, 554, 880),
        audio_windows=(
            AudioWindow(
                start_sample=2_000,
                end_sample=20_000,
                absent_frequencies_hz=(880,),
            ),
            AudioWindow(
                start_sample=26_000,
                end_sample=34_000,
                present_frequencies_hz=(880,),
            ),
        ),
    )


BUILDERS = {
    "podcast_clip": build_podcast,
    "interview_edit": build_interview,
    "product_ad": build_product_ad,
    "recap": build_recap,
    "documentary": build_documentary,
    "motion_graphics_video": build_motion_graphics,
    "long_form_sequence": build_long_form,
    "hdr_to_sdr_project": build_hdr_to_sdr,
    "mixed_frame_rate_project": build_mixed_frame_rate,
    "multitrack_audio_project": build_multitrack_audio,
}
