"""Decoded essence measurements used by portable golden-project gates."""

from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path
from typing import Any

import numpy as np


def probe(path: Path) -> dict[str, Any]:
    completed = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-count_frames",
            "-show_format",
            "-show_streams",
            "-of",
            "json",
            str(path),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(completed.stdout)


def media_tool_fingerprint() -> str:
    payload = []
    for executable in ("ffmpeg", "ffprobe"):
        completed = subprocess.run(
            [executable, "-version"],
            check=True,
            capture_output=True,
            text=True,
        )
        payload.append(completed.stdout)
    return hashlib.sha256("\n---\n".join(payload).encode("utf-8")).hexdigest()


def frame_dhash(path: Path, frame_index: int) -> str:
    completed = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(path),
            "-vf",
            f"select=eq(n\\,{frame_index}),scale=9:8,format=gray",
            "-frames:v",
            "1",
            "-fps_mode",
            "passthrough",
            "-f",
            "rawvideo",
            "-",
        ],
        check=True,
        capture_output=True,
    )
    pixels = np.frombuffer(completed.stdout, dtype=np.uint8)
    if pixels.size != 72:
        raise AssertionError(f"frame {frame_index} did not decode to a 9x8 hash input")
    image = pixels.reshape(8, 9)
    bits = image[:, 1:] > image[:, :-1]
    value = 0
    for bit in bits.flat:
        value = (value << 1) | int(bit)
    return f"{value:016x}"


def frame_dhash_sequence(path: Path) -> tuple[str, ...]:
    completed = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(path),
            "-map",
            "0:v:0",
            "-vf",
            "scale=9:8,format=gray",
            "-fps_mode",
            "passthrough",
            "-f",
            "rawvideo",
            "-",
        ],
        check=True,
        capture_output=True,
    )
    pixels = np.frombuffer(completed.stdout, dtype=np.uint8)
    if pixels.size == 0 or pixels.size % 72:
        raise AssertionError("decoded video did not contain complete 9x8 hash frames")
    images = pixels.reshape(-1, 8, 9)
    hashes: list[str] = []
    for image in images:
        bits = image[:, 1:] > image[:, :-1]
        value = 0
        for bit in bits.flat:
            value = (value << 1) | int(bit)
        hashes.append(f"{value:016x}")
    return tuple(hashes)


def frame_dhash_digest(path: Path) -> str:
    sequence = frame_dhash_sequence(path)
    return hashlib.sha256(("\n".join(sequence) + "\n").encode("ascii")).hexdigest()


def hamming_distance(left: str, right: str) -> int:
    return (int(left, 16) ^ int(right, 16)).bit_count()


def decode_audio(path: Path, *, sample_rate: int = 48_000) -> np.ndarray:
    completed = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(path),
            "-map",
            "0:a:0",
            "-ac",
            "1",
            "-ar",
            str(sample_rate),
            "-f",
            "f32le",
            "-",
        ],
        check=True,
        capture_output=True,
    )
    return np.frombuffer(completed.stdout, dtype="<f4")


def decoded_pcm_sha256(
    path: Path,
    *,
    sample_rate: int = 48_000,
    channels: int = 2,
) -> str:
    completed = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(path),
            "-map",
            "0:a:0",
            "-ac",
            str(channels),
            "-ar",
            str(sample_rate),
            "-f",
            "f32le",
            "-",
        ],
        check=True,
        capture_output=True,
    )
    return hashlib.sha256(completed.stdout).hexdigest()


def audio_summary(samples: np.ndarray) -> dict[str, float | int]:
    if samples.size == 0:
        return {"samples": 0, "rms": 0.0, "peak": 0.0, "dc_offset": 0.0}
    values = samples.astype(np.float64, copy=False)
    return {
        "samples": int(values.size),
        "rms": float(np.sqrt(np.mean(np.square(values)))),
        "peak": float(np.max(np.abs(values))),
        "dc_offset": float(np.mean(values)),
    }


def frequency_levels_db(samples: np.ndarray, frequencies: tuple[int, ...]) -> dict[str, float]:
    if samples.size == 0:
        return {str(value): float("-inf") for value in frequencies}
    window = np.hanning(samples.size)
    spectrum = np.abs(np.fft.rfft(samples * window))
    bins = np.fft.rfftfreq(samples.size, d=1 / 48_000)
    peak = max(float(spectrum.max()), 1e-12)
    levels: dict[str, float] = {}
    for frequency in frequencies:
        neighborhood = np.abs(bins - frequency) <= 3
        magnitude = float(spectrum[neighborhood].max()) if neighborhood.any() else 0.0
        levels[str(frequency)] = float(20 * np.log10(max(magnitude / peak, 1e-12)))
    return levels
