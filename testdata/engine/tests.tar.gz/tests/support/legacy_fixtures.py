"""Synthetic fixtures used to freeze the pre-engine renderer behavior."""

from __future__ import annotations

import copy
import json
import subprocess
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]


def run(command: list[str], *, capture: bool = False) -> subprocess.CompletedProcess[bytes]:
    return subprocess.run(
        command,
        check=True,
        stdout=subprocess.PIPE if capture else subprocess.DEVNULL,
        stderr=subprocess.PIPE,
    )


def ffmpeg(*arguments: str) -> None:
    run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", *arguments])


def probe(path: Path) -> dict[str, Any]:
    result = run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_format",
            "-show_streams",
            "-of",
            "json",
            str(path),
        ],
        capture=True,
    )
    return json.loads(result.stdout)


def _make_landscape(path: Path, pattern: str, frequency: int) -> None:
    ffmpeg(
        "-f",
        "lavfi",
        "-i",
        f"{pattern}=size=320x180:rate=30:duration=3",
        "-f",
        "lavfi",
        "-i",
        f"sine=frequency={frequency}:sample_rate=48000:duration=3",
        "-filter_complex",
        "[1:a]aformat=channel_layouts=stereo[a]",
        "-map",
        "0:v:0",
        "-map",
        "[a]",
        "-c:v",
        "libx264",
        "-preset",
        "ultrafast",
        "-g",
        "60",
        "-pix_fmt",
        "yuv420p",
        "-c:a",
        "aac",
        "-ar",
        "48000",
        "-shortest",
        str(path),
    )


def _make_portrait(path: Path) -> None:
    ffmpeg(
        "-f",
        "lavfi",
        "-i",
        "color=c=0x17324d:size=180x320:rate=30:duration=3",
        "-f",
        "lavfi",
        "-i",
        "sine=frequency=660:sample_rate=48000:duration=3",
        "-vf",
        "drawbox=x='20+40*t':y=95:w=44:h=90:color=0xf43f5e:t=fill",
        "-filter_complex",
        "[1:a]aformat=channel_layouts=stereo[a]",
        "-map",
        "0:v:0",
        "-map",
        "[a]",
        "-c:v",
        "libx264",
        "-preset",
        "ultrafast",
        "-pix_fmt",
        "yuv420p",
        "-c:a",
        "aac",
        "-ar",
        "48000",
        "-shortest",
        str(path),
    )


def _make_hdr(path: Path, transfer: str) -> None:
    ffmpeg(
        "-f",
        "lavfi",
        "-i",
        "testsrc2=size=320x180:rate=24:duration=1.5",
        "-f",
        "lavfi",
        "-i",
        "sine=frequency=300:sample_rate=48000:duration=1.5",
        "-filter_complex",
        "[0:v]format=yuv420p10le[v];[1:a]aformat=channel_layouts=stereo[a]",
        "-map",
        "[v]",
        "-map",
        "[a]",
        "-c:v",
        "ffv1",
        "-level",
        "3",
        "-pix_fmt",
        "yuv420p10le",
        "-color_primaries",
        "bt2020",
        "-color_trc",
        transfer,
        "-colorspace",
        "bt2020nc",
        "-c:a",
        "pcm_s16le",
        "-ar",
        "48000",
        "-shortest",
        str(path),
    )


def build_legacy_workspace(root: Path) -> dict[str, Path]:
    """Create all small media and JSON inputs needed by legacy regression tests."""
    root.mkdir(parents=True, exist_ok=True)
    assets = root / "assets"
    assets.mkdir(exist_ok=True)
    existing = root / "existing"
    existing.mkdir(exist_ok=True)
    faceless = root / "faceless"
    (faceless / "assets" / "footage").mkdir(parents=True, exist_ok=True)
    (faceless / "assets" / "images").mkdir(parents=True, exist_ok=True)
    (faceless / "assets" / "audio").mkdir(parents=True, exist_ok=True)
    (faceless / "captions").mkdir(parents=True, exist_ok=True)

    source_a = assets / "landscape_a.mp4"
    source_b = assets / "landscape_b.mp4"
    portrait = assets / "portrait.mp4"
    overlay = assets / "overlay.mp4"
    sfx = assets / "sfx.wav"
    voiceover = faceless / "assets" / "audio" / "voiceover.wav"
    still = faceless / "assets" / "images" / "still.png"
    faceless_video = faceless / "assets" / "footage" / "portrait.mp4"
    hlg = assets / "hlg.mkv"
    pq = assets / "pq.mkv"

    _make_landscape(source_a, "testsrc2", 440)
    _make_landscape(source_b, "smptebars", 554)
    _make_portrait(portrait)
    ffmpeg(
        "-f",
        "lavfi",
        "-i",
        "color=c=0x3f3f46:size=320x180:rate=24:duration=0.75",
        "-vf",
        "drawbox=x=20:y=115:w=280:h=50:color=0x18181b:t=fill",
        "-an",
        "-c:v",
        "libx264",
        "-preset",
        "ultrafast",
        "-pix_fmt",
        "yuv420p",
        str(overlay),
    )
    ffmpeg(
        "-f",
        "lavfi",
        "-i",
        "sine=frequency=880:sample_rate=48000:duration=0.25",
        "-c:a",
        "pcm_s16le",
        str(sfx),
    )
    ffmpeg(
        "-f",
        "lavfi",
        "-i",
        "sine=frequency=330:sample_rate=48000:duration=2",
        "-c:a",
        "pcm_s16le",
        str(voiceover),
    )
    ffmpeg(
        "-f",
        "lavfi",
        "-i",
        "testsrc2=size=180x320:rate=1:duration=1",
        "-frames:v",
        "1",
        str(still),
    )
    faceless_video.write_bytes(portrait.read_bytes())
    _make_hdr(hlg, "arib-std-b67")
    _make_hdr(pq, "smpte2084")

    subtitles = existing / "master.ass"
    subtitles.write_text(
        "[Script Info]\n"
        "ScriptType: v4.00+\nPlayResX: 320\nPlayResY: 180\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, "
        "OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, "
        "ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
        "Alignment, MarginL, MarginR, MarginV, Encoding\n"
        "Style: Default,DejaVu Sans,20,&H00FFFFFF,&H0000FFFF,&H00000000,"
        "&H80000000,-1,0,0,0,100,100,0,0,1,2,0,2,10,10,15,1\n"
        "[Events]\n"
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, "
        "Effect, Text\n"
        "Dialogue: 0,0:00:00.35,0:00:01.25,Default,,0,0,0,,CAPTION\\NABOVE OVERLAY\n"
        "Dialogue: 0,0:00:01.45,0:00:02.25,Default,,0,0,0,,SECOND CUE\n",
        encoding="utf-8",
    )

    existing_edl = existing / "edl.json"
    existing_edl.write_text(
        json.dumps(
            {
                "version": 1,
                "sources": {"a": str(source_a), "b": str(source_b)},
                "ranges": [
                    {"source": "a", "start": 0.37, "end": 1.17},
                    {"source": "b", "start": 0.22, "end": 1.12},
                    {"source": "a", "start": 1.53, "end": 2.23},
                ],
                "resolution": "320x180",
                "output_fit": "cover",
                "grade": "",
                "overlays": [{"file": str(overlay), "start_in_output": 0.55, "duration": 0.70}],
                "sound_effects": [
                    {
                        "file": str(sfx),
                        "start_in_output": 1.45,
                        "duration": 0.20,
                        "gain": 0.35,
                    }
                ],
                "subtitles": str(subtitles),
                "total_duration_s": 2.4,
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    existing_data = json.loads(existing_edl.read_text(encoding="utf-8"))
    variant_paths: dict[str, Path] = {}
    for name, removals in {
        "base": ("overlays", "sound_effects", "subtitles"),
        "caption": ("overlays", "sound_effects"),
        "overlay": ("sound_effects", "subtitles"),
        "sfx": ("overlays", "subtitles"),
    }.items():
        variant = copy.deepcopy(existing_data)
        for field in removals:
            variant.pop(field, None)
        path = existing / f"{name}_edl.json"
        path.write_text(json.dumps(variant, indent=2) + "\n", encoding="utf-8")
        variant_paths[name] = path

    vertical_edl = existing / "vertical_edl.json"
    vertical_edl.write_text(
        json.dumps(
            {
                "version": 1,
                "sources": {"landscape": str(source_a)},
                "ranges": [
                    {
                        "source": "landscape",
                        "start": 0.2,
                        "end": 1.2,
                        "focus_x": 0.0,
                        "focus_y": 0.5,
                    }
                ],
                "resolution": "180x320",
                "output_fit": "cover",
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    hdr_edl = existing / "hdr_edl.json"
    hdr_edl.write_text(
        json.dumps(
            {
                "version": 1,
                "sources": {"hlg": str(hlg)},
                "ranges": [{"source": "hlg", "start": 0.1, "end": 1.1}],
                "resolution": "320x180",
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    faceless_timeline = {
        "schema_version": 1,
        "project": {
            "title": "legacy faceless baseline",
            "resolution": {"width": 160, "height": 284},
            "fps": 24,
            "audio_sample_rate": 48000,
            "target_duration_seconds": 2.0,
        },
        "tracks": {"voiceover": [], "captions": [], "overlays": []},
        "beats": [
            {
                "beat_id": "B01",
                "start": 0.0,
                "end": 1.0,
                "script_text": "First synthetic beat",
                "primary_asset_path": "assets/images/still.png",
                "layers": [
                    {
                        "type": "emphasis_text",
                        "start": 0.15,
                        "end": 0.8,
                        "text": "FIRST",
                        "effect": "capcut_highlight_wipe",
                    },
                    {
                        "type": "visual_motion_overlay",
                        "start": 0.1,
                        "end": 0.9,
                        "effect": "arrow_trace",
                    },
                    {
                        "type": "sound_cue",
                        "start": 0.2,
                        "effect": "tick",
                        "level": "low_under_voice",
                    },
                ],
            },
            {
                "beat_id": "B02",
                "start": 1.0,
                "end": 2.0,
                "script_text": "Second synthetic beat",
                "primary_asset_path": "assets/footage/portrait.mp4",
                "layers": [
                    {
                        "type": "emphasis_text",
                        "start": 1.1,
                        "end": 1.8,
                        "text": "SECOND",
                        "effect": "staggered_glitch_reveal",
                    },
                    {
                        "type": "visual_motion_overlay",
                        "start": 1.1,
                        "end": 1.9,
                        "effect": "outline_trace",
                    },
                ],
            },
        ],
        "render": {"subtitles_last": True},
    }
    (faceless / "edit_decision_list.json").write_text(
        json.dumps(faceless_timeline, indent=2) + "\n", encoding="utf-8"
    )
    (faceless / "creative_directive.json").write_text(
        json.dumps(
            {
                "style": {
                    "accent_color": "#22d3ee",
                    "secondary_accent": "#facc15",
                }
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (faceless / "captions" / "captions.json").write_text(
        json.dumps(
            {
                "cues": [
                    {
                        "beat_id": "B01",
                        "start": 0.05,
                        "end": 0.95,
                        "text": "FIRST SYNTHETIC",
                        "style_id": "two_word_pop_highlight_glow",
                        "emphasis_terms": ["first"],
                    },
                    {
                        "beat_id": "B02",
                        "start": 1.05,
                        "end": 1.95,
                        "text": "SECOND SYNTHETIC",
                        "style_id": "two_word_pop_highlight_glow",
                        "emphasis_terms": ["second"],
                    },
                ]
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (faceless / "captions" / "master.srt").write_text(
        "1\n00:00:00,050 --> 00:00:00,950\nFIRST SYNTHETIC\n\n"
        "2\n00:00:01,050 --> 00:00:01,950\nSECOND SYNTHETIC\n",
        encoding="utf-8",
    )

    return {
        "root": root,
        "assets": assets,
        "existing": existing,
        "existing_edl": existing_edl,
        "base_edl": variant_paths["base"],
        "caption_edl": variant_paths["caption"],
        "overlay_edl": variant_paths["overlay"],
        "sfx_edl": variant_paths["sfx"],
        "vertical_edl": vertical_edl,
        "hdr_edl": hdr_edl,
        "faceless": faceless,
        "hlg": hlg,
        "pq": pq,
    }
