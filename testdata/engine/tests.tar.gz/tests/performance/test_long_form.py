from __future__ import annotations

import resource
import time
from pathlib import Path

import pytest

from video_engine.api.engine import VideoEngine
from video_engine.config import EngineConfig
from video_engine.core.schema import Clip, MediaReference, VideoTrack
from video_engine.core.time import FrameRate, RationalTime, TimeRange
from video_engine.render.models import RenderRequest
from video_engine.render.nodes import AudioMixNode, CompositeNode, ConcatNode, DecodeNode


@pytest.mark.performance
def test_two_thousand_item_long_form_compile_is_bounded(tmp_path: Path) -> None:
    source = tmp_path / "shared-master.bin"
    source.write_bytes(b"shared source")
    config = EngineConfig(
        render_section_duration_seconds=30,
        max_render_inputs=32,
    )
    engine = VideoEngine(tmp_path, config)
    project = engine.create_project(
        "Two Thousand Items",
        width=64,
        height=64,
        frame_rate=FrameRate(numerator=24),
    )
    frame = RationalTime(value=1, timescale=24)
    project.media.append(
        MediaReference(
            id="master",
            uri=str(source),
            available_range=TimeRange(start=RationalTime.zero(), duration=frame),
        )
    )
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="video",
            items=[
                Clip(
                    id=f"clip-{index}",
                    media_reference_id="master",
                    timeline_range=TimeRange(
                        start=RationalTime(value=index, timescale=24),
                        duration=frame,
                    ),
                    source_range=TimeRange(start=RationalTime.zero(), duration=frame),
                    source_audio_enabled=False,
                )
                for index in range(2_000)
            ],
        )
    ]
    before_memory_kib = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    started = time.monotonic()

    compiled = engine.renderer(project).compile(
        RenderRequest(output_path=tmp_path / "long-form.mp4")
    )

    elapsed = time.monotonic() - started
    memory_growth_kib = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss - before_memory_kib
    fan_in_nodes = [
        node
        for node in compiled.graph.nodes
        if isinstance(node, (CompositeNode, AudioMixNode, ConcatNode))
    ]
    decodes = [node for node in compiled.graph.nodes if isinstance(node, DecodeNode)]
    assert len(compiled.section_outputs) == 3
    assert len(decodes) == 1
    assert max(len(node.inputs) for node in fan_in_nodes) <= 32
    assert elapsed < 20
    assert memory_growth_kib < 512 * 1024
