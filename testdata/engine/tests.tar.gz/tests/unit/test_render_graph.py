from __future__ import annotations

import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pytest
from pydantic import ValidationError

from video_engine.core.time import FrameRate, RationalRate, RationalTime, TimeRange
from video_engine.errors import EngineError
from video_engine.render.backends.base import BackendExecution, RenderBackend
from video_engine.render.backends.registry import BackendRegistry
from video_engine.render.cache import RenderCache, cache_key_for_node
from video_engine.render.graph import RenderGraph, optimize_graph
from video_engine.render.models import RenderArtifact
from video_engine.render.nodes import (
    ALL_NODE_KINDS,
    ArtifactType,
    CompositeLayer,
    CompositeNode,
    CropNode,
    DecodeNode,
    EncodeNode,
    MotionGraphicNode,
    MuxNode,
    NodeKind,
    RenderNode,
    SpeedNode,
    TransformNode,
    TrimNode,
    VisualAutomationPoint,
)
from video_engine.render.scheduler import RenderScheduler


def seconds(value: int) -> RationalTime:
    return RationalTime(value=value, timescale=1)


def speed_node(**values: object) -> SpeedNode:
    return SpeedNode.model_validate(
        {
            "duration": seconds(1),
            "frame_rate": FrameRate(numerator=24),
            "sample_rate": 48_000,
            **values,
        }
    )


def source_node(node_id: str, source: Path) -> DecodeNode:
    return DecodeNode(id=node_id, artifact_type=ArtifactType.VIDEO, source_uri=str(source))


class FakeBackend(RenderBackend):
    name = "fake"
    version = "1"
    capabilities = ALL_NODE_KINDS

    def __init__(self, *, delay: float = 0.0) -> None:
        self.delay = delay
        self.executions: list[str] = []
        self.work_dirs: list[Path] = []
        self._lock = threading.Lock()
        self.active = 0
        self.max_active = 0

    @property
    def tool_fingerprint(self) -> str:
        return "fake-tool-1"

    def output_suffix(self, node: RenderNode) -> str:
        return ".bin"

    def execute(
        self,
        node: RenderNode,
        inputs: tuple[RenderArtifact, ...],
        output_path: Path,
        work_dir: Path,
    ) -> BackendExecution:
        with self._lock:
            self.active += 1
            self.max_active = max(self.max_active, self.active)
            self.executions.append(node.id)
            self.work_dirs.append(work_dir)
        try:
            if self.delay:
                time.sleep(self.delay)
            if isinstance(node, DecodeNode):
                return BackendExecution(path=Path(node.source_uri))
            content = "|".join(item.path.read_text(encoding="utf-8") for item in inputs)
            output_path.write_text(f"{content}>{node.node_type.value}", encoding="utf-8")
            return BackendExecution(path=output_path)
        finally:
            with self._lock:
                self.active -= 1


def test_render_nodes_are_strict_and_frozen(tmp_path: Path) -> None:
    node = source_node("decode", tmp_path / "source")
    with pytest.raises(ValidationError):
        DecodeNode.model_validate(
            {
                **node.model_dump(mode="json"),
                "unknown": True,
            }
        )
    with pytest.raises(ValidationError):
        node.source_uri = "other"  # type: ignore[misc]


def test_fixed_canvas_crop_rejects_rectangles_outside_the_frame() -> None:
    with pytest.raises(ValidationError, match="outside the fixed canvas"):
        CropNode(
            id="bad-crop",
            inputs=("source",),
            artifact_type=ArtifactType.VIDEO,
            width=100,
            height=100,
            x=250,
            y=100,
            canvas_width=320,
            canvas_height=180,
        )


def test_graph_rejects_missing_inputs_cycles_and_bad_arity(tmp_path: Path) -> None:
    source = source_node("decode", tmp_path / "source")
    with pytest.raises(ValidationError, match="missing inputs"):
        RenderGraph(
            nodes=(
                speed_node(
                    id="speed",
                    inputs=("missing",),
                    artifact_type=ArtifactType.VIDEO,
                    rate=2,
                ),
            ),
            outputs={"main": "speed"},
        )
    with pytest.raises(ValidationError, match="cycle"):
        RenderGraph(
            nodes=(
                speed_node(id="a", inputs=("b",), artifact_type=ArtifactType.VIDEO, rate=2),
                speed_node(id="b", inputs=("a",), artifact_type=ArtifactType.VIDEO, rate=2),
            ),
            outputs={"main": "a"},
        )
    with pytest.raises(ValidationError, match="exactly one input"):
        RenderGraph(
            nodes=(
                source,
                speed_node(id="speed", artifact_type=ArtifactType.VIDEO, rate=2),
            ),
            outputs={"main": "speed"},
        )


def test_graph_validates_artifact_edges_and_zero_input_graphics(tmp_path: Path) -> None:
    audio = DecodeNode(
        id="audio", artifact_type=ArtifactType.AUDIO, source_uri=str(tmp_path / "audio")
    )
    with pytest.raises(ValidationError, match="requires a visual input"):
        RenderGraph(
            nodes=(
                audio,
                TransformNode(
                    id="bad-transform",
                    inputs=(audio.id,),
                    artifact_type=ArtifactType.VIDEO,
                ),
            ),
            outputs={"main": "bad-transform"},
        )

    graphic = MotionGraphicNode(
        id="graphic",
        artifact_type=ArtifactType.VIDEO,
        component_id="title_card",
        component_version="1.0.0",
        component_digest="a" * 64,
        props={"title": "Test"},
        duration=seconds(1),
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
        composition_duration_frames=24,
        render_duration_frames=24,
    )
    assert RenderGraph(nodes=(graphic,), outputs={"main": graphic.id}).node(graphic.id) == graphic


def test_topology_partial_closure_and_identity_optimization(tmp_path: Path) -> None:
    first = source_node("first", tmp_path / "first")
    second = source_node("second", tmp_path / "second")
    speed = speed_node(
        id="identity-speed",
        inputs=("first",),
        artifact_type=ArtifactType.VIDEO,
        rate=1,
    )
    transform = TransformNode(
        id="identity-transform",
        inputs=(speed.id,),
        artifact_type=ArtifactType.VIDEO,
    )
    graph = RenderGraph(
        nodes=(first, second, speed, transform),
        outputs={"main": transform.id, "unused": second.id},
    )
    assert graph.topological_order((transform.id,)) == (
        "first",
        "identity-speed",
        "identity-transform",
    )
    assert graph.ancestor_closure((transform.id,)) == {
        "first",
        "identity-speed",
        "identity-transform",
    }
    optimized = optimize_graph(graph)
    assert optimized.removed_nodes == ("identity-speed", "identity-transform")
    assert optimized.graph.outputs["main"] == "first"


def test_composite_requires_layer_input_order(tmp_path: Path) -> None:
    first = source_node("first", tmp_path / "first")
    second = source_node("second", tmp_path / "second")
    with pytest.raises(ValidationError, match="layer input ids"):
        CompositeNode(
            id="composite",
            inputs=(first.id, second.id),
            artifact_type=ArtifactType.VIDEO,
            width=1920,
            height=1080,
            frame_rate=FrameRate(numerator=24),
            duration=seconds(2),
            layers=(
                CompositeLayer(
                    input_id=second.id,
                    timeline_range=TimeRange(start=seconds(0), duration=seconds(2)),
                ),
                CompositeLayer(
                    input_id=first.id,
                    timeline_range=TimeRange(start=seconds(0), duration=seconds(2)),
                ),
            ),
        )


def test_optimizer_preserves_animated_identity_transform_and_composite_links(
    tmp_path: Path,
) -> None:
    source = source_node("source", tmp_path / "source")
    identity = TransformNode(
        id="static-identity",
        inputs=(source.id,),
        artifact_type=ArtifactType.VIDEO,
    )
    animated = TransformNode(
        id="animated-identity-base",
        inputs=(identity.id,),
        artifact_type=ArtifactType.VIDEO,
        canvas_width=320,
        canvas_height=180,
        automation=(
            VisualAutomationPoint(
                property_path="scale_x",
                time=seconds(0),
                value=1,
            ),
            VisualAutomationPoint(
                property_path="scale_x",
                time=seconds(1),
                value=1.1,
            ),
        ),
    )
    item_range = TimeRange(start=seconds(0), duration=seconds(1))
    composite = CompositeNode(
        id="composite",
        inputs=(animated.id,),
        artifact_type=ArtifactType.VIDEO,
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
        duration=seconds(1),
        layers=(CompositeLayer(input_id=animated.id, timeline_range=item_range),),
    )

    optimized = optimize_graph(
        RenderGraph(nodes=(source, identity, animated, composite), outputs={"main": composite.id})
    )

    assert optimized.removed_nodes == (identity.id,)
    optimized_animated = optimized.graph.node(animated.id)
    optimized_composite = optimized.graph.node(composite.id)
    assert optimized_animated.inputs == (source.id,)
    assert optimized_composite.inputs == (animated.id,)
    assert isinstance(optimized_composite, CompositeNode)
    assert optimized_composite.layers[0].input_id == animated.id


def test_registry_reports_unsupported_nodes(tmp_path: Path) -> None:
    class DecodeOnly(FakeBackend):
        name = "decode-only"
        capabilities = frozenset({NodeKind.DECODE})

    source = source_node("decode", tmp_path / "source")
    trim = TrimNode(
        id="trim",
        inputs=(source.id,),
        artifact_type=ArtifactType.VIDEO,
        source_range=TimeRange(start=seconds(0), duration=seconds(1)),
    )
    graph = RenderGraph(nodes=(source, trim), outputs={"main": trim.id})
    registry = BackendRegistry()
    registry.register(DecodeOnly())
    with pytest.raises(EngineError) as raised:
        registry.resolve(graph, "decode-only")
    assert raised.value.code.value == "unsupported_capability"
    assert raised.value.context["unsupported"] == [{"node_id": "trim", "node_type": "trim"}]


def test_registry_and_scheduler_support_mixed_backend_graphs(tmp_path: Path) -> None:
    class MediaBackend(FakeBackend):
        name = "media"
        capabilities = ALL_NODE_KINDS - {NodeKind.MOTION_GRAPHIC}

    class GraphicBackend(FakeBackend):
        name = "graphics"
        capabilities = frozenset({NodeKind.MOTION_GRAPHIC})

    graphic = MotionGraphicNode(
        id="graphic",
        artifact_type=ArtifactType.VIDEO,
        component_id="title_card",
        component_version="1.0.0",
        component_digest="a" * 64,
        props={"title": "Mixed"},
        duration=seconds(1),
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
        composition_duration_frames=24,
        render_duration_frames=24,
    )
    transform = TransformNode(
        id="transform",
        inputs=(graphic.id,),
        artifact_type=ArtifactType.VIDEO,
        opacity=0.75,
    )
    graph = RenderGraph(nodes=(graphic, transform), outputs={"main": transform.id})
    media = MediaBackend()
    graphics = GraphicBackend()
    registry = BackendRegistry()
    registry.register(media)
    registry.register(graphics)

    plan = registry.plan(graph, "media")

    assert plan.name == "graphics+media"
    assert plan.by_node_id == {"graphic": graphics, "transform": media}
    scheduled = RenderScheduler(
        plan.by_node_id,
        RenderCache(tmp_path / "mixed-cache"),
        max_workers=2,
    ).execute(graph, tmp_path / "mixed-work")
    assert scheduled.artifacts[transform.id].path.read_text(encoding="utf-8") == (
        ">motion_graphic>transform"
    )
    assert [(record.node_id, record.backend) for record in scheduled.records] == [
        ("graphic", "graphics"),
        ("transform", "media"),
    ]


def test_cache_key_ignores_node_id_but_tracks_parameters_and_inputs(tmp_path: Path) -> None:
    first = speed_node(id="one", inputs=("source",), artifact_type=ArtifactType.VIDEO, rate=2)
    renamed = first.model_copy(update={"id": "two"})
    changed = first.model_copy(update={"rate": RationalRate(numerator=3)})

    def key(node: SpeedNode, inputs: tuple[str, ...] = ("upstream",)) -> str:
        return cache_key_for_node(
            node,
            inputs,
            backend_name="fake",
            backend_version="1",
            tool_fingerprint="tool",
        )

    assert key(first) == key(renamed)
    upstream_renamed = renamed.model_copy(update={"inputs": ("renamed-source",)})
    assert key(first) == key(upstream_renamed)
    assert key(first) != key(changed)
    assert key(first) != key(first, ("different",))


def test_decode_cache_key_uses_compiler_verified_source_identity(tmp_path: Path) -> None:
    source = tmp_path / "source.bin"
    source.write_bytes(b"current")
    decode = DecodeNode(
        id="decode",
        artifact_type=ArtifactType.VIDEO,
        source_uri=str(source),
        source_sha256="0" * 64,
    )
    first = cache_key_for_node(
        decode,
        (),
        backend_name="fake",
        backend_version="1",
        tool_fingerprint="tool",
    )
    source.write_bytes(b"changed without a cache-key file read")
    second = cache_key_for_node(
        decode,
        (),
        backend_name="fake",
        backend_version="1",
        tool_fingerprint="tool",
    )
    changed_identity = cache_key_for_node(
        decode.model_copy(update={"source_sha256": "1" * 64}),
        (),
        backend_name="fake",
        backend_version="1",
        tool_fingerprint="tool",
    )
    assert first == second
    assert changed_identity != first


def test_scheduler_runs_parallel_branches_and_reuses_valid_cache(tmp_path: Path) -> None:
    source_a = tmp_path / "a.txt"
    source_b = tmp_path / "b.txt"
    source_a.write_text("a", encoding="utf-8")
    source_b.write_text("b", encoding="utf-8")
    decode_a = source_node("decode-a", source_a)
    decode_b = DecodeNode(id="decode-b", artifact_type=ArtifactType.AUDIO, source_uri=str(source_b))
    speed_a = speed_node(
        id="speed-a", inputs=(decode_a.id,), artifact_type=ArtifactType.VIDEO, rate=2
    )
    speed_b = speed_node(
        id="speed-b", inputs=(decode_b.id,), artifact_type=ArtifactType.AUDIO, rate=3
    )
    encode_a = EncodeNode(
        id="encode-a",
        inputs=(speed_a.id,),
        artifact_type=ArtifactType.ENCODED_VIDEO,
        codec="fake-video",
    )
    encode_b = EncodeNode(
        id="encode-b",
        inputs=(speed_b.id,),
        artifact_type=ArtifactType.ENCODED_AUDIO,
        codec="fake-audio",
    )
    mux = MuxNode(
        id="mux",
        inputs=(encode_a.id, encode_b.id),
        artifact_type=ArtifactType.CONTAINER,
    )
    graph = RenderGraph(
        nodes=(decode_a, decode_b, speed_a, speed_b, encode_a, encode_b, mux),
        outputs={"main": mux.id},
    )
    backend = FakeBackend(delay=0.03)
    scheduler = RenderScheduler(backend, RenderCache(tmp_path / "cache"), max_workers=2)

    first = scheduler.execute(graph, tmp_path / "work-1")
    assert first.artifacts[mux.id].path.read_text(encoding="utf-8").endswith(">mux")
    assert backend.max_active == 2
    assert sum(record.cached for record in first.records) == 0

    second = scheduler.execute(graph, tmp_path / "work-2")
    assert sum(record.cached for record in second.records) == 5
    assert backend.executions.count("speed-a") == 1
    assert backend.executions.count("speed-b") == 1
    assert backend.executions.count("mux") == 1

    cached_speed = second.artifacts["speed-a"].path
    cached_speed.write_text("corrupt", encoding="utf-8")
    third = scheduler.execute(graph, tmp_path / "work-3")
    assert next(record for record in third.records if record.node_id == "speed-a").cached is False
    assert backend.executions.count("speed-a") == 2


def test_shared_cache_lock_prevents_duplicate_execution(tmp_path: Path) -> None:
    source_path = tmp_path / "source.txt"
    source_path.write_text("source", encoding="utf-8")
    decode = source_node("decode", source_path)
    speed = speed_node(id="speed", inputs=(decode.id,), artifact_type=ArtifactType.VIDEO, rate=2)
    encode = EncodeNode(
        id="encode",
        inputs=(speed.id,),
        artifact_type=ArtifactType.ENCODED_VIDEO,
        codec="fake",
    )
    mux = MuxNode(
        id="mux",
        inputs=(encode.id,),
        artifact_type=ArtifactType.CONTAINER,
    )
    graph = RenderGraph(nodes=(decode, speed, encode, mux), outputs={"main": mux.id})
    cache = RenderCache(tmp_path / "cache")
    backends = (FakeBackend(delay=0.03), FakeBackend(delay=0.03))
    schedulers = tuple(RenderScheduler(backend, cache, max_workers=1) for backend in backends)
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = tuple(
            pool.submit(scheduler.execute, graph, tmp_path / f"work-{index}")
            for index, scheduler in enumerate(schedulers)
        )
        completed = tuple(result.result() for result in results)
    executions = backends[0].executions + backends[1].executions
    assert executions.count("decode") == 2
    assert executions.count("speed") == 1
    assert executions.count("encode") == 1
    assert executions.count("mux") == 1
    assert sum(record.cached for result in completed for record in result.records) == 3


def test_scheduler_never_uses_node_ids_as_paths(tmp_path: Path) -> None:
    source_path = tmp_path / "source.txt"
    source_path.write_text("source", encoding="utf-8")
    decode = source_node("decode", source_path)
    speed = speed_node(
        id="../../outside",
        inputs=(decode.id,),
        artifact_type=ArtifactType.VIDEO,
        rate=2,
    )
    graph = RenderGraph(nodes=(decode, speed), outputs={"main": speed.id})
    backend = FakeBackend()
    work_root = tmp_path / "work"
    RenderScheduler(
        backend,
        RenderCache(tmp_path / "cache"),
        max_workers=1,
        use_cache=False,
    ).execute(graph, work_root)
    speed_work_dir = backend.work_dirs[backend.executions.index(speed.id)].resolve()
    assert speed_work_dir.is_relative_to(work_root.resolve())
