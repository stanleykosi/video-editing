from decimal import Decimal
from fractions import Fraction

import pytest

from video_engine.core.time import (
    AudioSampleTime,
    FrameRate,
    RationalRate,
    RationalTime,
    RoundingMode,
    Timecode,
    TimeRange,
)


def test_rational_time_normalizes_and_computes_exactly() -> None:
    half = RationalTime(value=24_000, timescale=48_000)
    third = RationalTime(value=1, timescale=3)
    assert half == RationalTime(value=1, timescale=2)
    assert half + third == RationalTime(value=5, timescale=6)
    assert half - third == RationalTime(value=1, timescale=6)
    assert half * Fraction(3, 2) == RationalTime(value=3, timescale=4)


def test_rational_rate_normalizes_scalar_inputs_exactly() -> None:
    assert RationalRate.model_validate("30000/1001").fraction == Fraction(30_000, 1001)
    assert RationalRate.model_validate(Decimal("0.125")) == RationalRate(numerator=1, denominator=8)
    with pytest.raises(ValueError, match="cannot exceed 100"):
        RationalRate(numerator=101)


def test_float_seconds_are_not_an_authoritative_constructor() -> None:
    assert RationalTime.from_seconds(Decimal("1.001"), 1000) == RationalTime(
        value=1001, timescale=1000
    )
    with pytest.raises(ValueError, match="not exact"):
        RationalTime.from_seconds("0.1", 24)


def test_fractional_frame_rate_round_trip() -> None:
    rate = FrameRate.fps_29_97()
    frame_time = rate.frames_to_time(1001)
    assert frame_time.fraction == Fraction(1_002_001, 30_000)
    assert rate.time_to_frames(frame_time) == 1001
    with pytest.raises(ValueError, match="does not land"):
        rate.time_to_frames(RationalTime(value=1, timescale=10))
    assert rate.time_to_frames(RationalTime(value=1, timescale=10), RoundingMode.NEAREST) == 3


@pytest.mark.parametrize(
    ("value", "expected_frames"),
    [
        ("00:01:00;02", 1800),
        ("00:10:00;00", 17_982),
        ("01:00:00;00", 107_892),
    ],
)
def test_drop_frame_timecode_round_trip(value: str, expected_frames: int) -> None:
    timecode = Timecode.parse(value, FrameRate.fps_29_97())
    assert timecode.frame_number == expected_frames
    assert str(timecode) == value


@pytest.mark.parametrize(
    ("frame_number", "label"),
    [
        (1799, "00:00:59;29"),
        (1800, "00:01:00;02"),
        (3597, "00:01:59;29"),
        (3598, "00:02:00;02"),
        (17_982, "00:10:00;00"),
        (107_892, "01:00:00;00"),
    ],
)
def test_drop_frame_formatter_handles_minute_boundaries(frame_number: int, label: str) -> None:
    rate = FrameRate.fps_29_97()
    timecode = Timecode(
        time=rate.frames_to_time(frame_number),
        rate=rate,
        drop_frame=True,
    )
    assert str(timecode) == label
    assert Timecode.parse(label, rate).frame_number == frame_number


@pytest.mark.parametrize("label", ["00:01:00;00", "00:01:00;01", "00:59:00;00"])
def test_drop_frame_parser_rejects_dropped_labels(label: str) -> None:
    with pytest.raises(ValueError, match="dropped frame label"):
        Timecode.parse(label, FrameRate.fps_29_97())


def test_timecode_parser_rejects_separator_mode_mismatch_and_unsupported_drop_rate() -> None:
    with pytest.raises(ValueError, match="separator disagrees"):
        Timecode.parse("00:00:00:00", FrameRate(numerator=24), drop_frame=True)
    with pytest.raises(ValueError, match=r"only at 29\.97 and 59\.94"):
        Timecode.parse("00:00:00;00", FrameRate(numerator=24))


@pytest.mark.parametrize(
    ("frame_number", "label"),
    [(3599, "00:00:59;59"), (3600, "00:01:00;04"), (35_964, "00:10:00;00")],
)
def test_5994_drop_frame_boundaries(frame_number: int, label: str) -> None:
    rate = FrameRate(numerator=60_000, denominator=1_001)
    timecode = Timecode(
        time=rate.frames_to_time(frame_number),
        rate=rate,
        drop_frame=True,
    )
    assert str(timecode) == label
    assert Timecode.parse(label, rate).frame_number == frame_number


def test_time_range_intersection_and_shift() -> None:
    left = TimeRange(
        start=RationalTime(value=0, timescale=1),
        duration=RationalTime(value=2, timescale=1),
    )
    right = TimeRange(
        start=RationalTime(value=3, timescale=2),
        duration=RationalTime(value=1, timescale=1),
    )
    assert left.overlaps(right)
    assert left.intersection(right) == TimeRange(
        start=RationalTime(value=3, timescale=2),
        duration=RationalTime(value=1, timescale=2),
    )
    assert left.shifted(RationalTime(value=1, timescale=2)).start == RationalTime(
        value=1, timescale=2
    )


def test_audio_sample_time_is_sample_accurate() -> None:
    sample_time = AudioSampleTime.from_time(
        RationalTime(value=1001, timescale=30_000),
        48_000,
        RoundingMode.NEAREST,
    )
    assert sample_time.samples == 1602
    assert sample_time.sample_rate == 48_000
    assert sample_time.shifted(1).samples == 1603
