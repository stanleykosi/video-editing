from __future__ import annotations

import hashlib
import subprocess
from pathlib import Path

import pytest
from pydantic import ValidationError

from video_engine.api.engine import VideoEngine
from video_engine.core.schema import (
    AdjustmentClip,
    AdjustmentTrack,
    AudioBus,
    AudioClip,
    AudioTrack,
    CaptionCue,
    CaptionTrack,
    Clip,
    Effect,
    EffectKind,
    GeneratorAssetReference,
    GeneratorClip,
    GraphicsTrack,
    Interpolation,
    Keyframe,
    Marker,
    MediaReference,
    NestedSequenceClip,
    Retime,
    Sequence,
    SequenceSnapshot,
    SpeedRampPoint,
    Timeline,
    Transition,
    TransitionKind,
    VideoTrack,
)
from video_engine.core.time import FrameRate, RationalRate, RationalTime, TimeRange
from video_engine.errors import EngineError
from video_engine.render.backends.ffmpeg import FFmpegBackend
from video_engine.render.compiler import RenderCompiler
from video_engine.render.models import RenderMode, RenderRequest
from video_engine.render.nodes import (
    AudioMixNode,
    AudioProcessNode,
    AudioSidechainNode,
    CaptionNode,
    ColorConversionNode,
    CompositeNode,
    ConcatNode,
    ConformNode,
    DecodeNode,
    FreezeNode,
    GradeNode,
    MaskNode,
    MotionGraphicNode,
    NodeKind,
    ReverseNode,
    SpeedNode,
    SpeedRampNode,
    TransformNode,
    TransitionNode,
    TrimNode,
)


def rt(value: int, timescale: int = 24) -> RationalTime:
    return RationalTime(value=value, timescale=timescale)


def freeze_parameters(
    frame_time: RationalTime,
    duration: RationalTime,
) -> dict[str, object]:
    return {
        "frame_time": frame_time.model_dump(mode="json"),
        "duration": duration.model_dump(mode="json"),
    }


@pytest.fixture
def source(tmp_path: Path) -> Path:
    path = tmp_path / "source.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=red:size=64x64:rate=24:duration=2",
            "-an",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(path),
        ],
        check=True,
    )
    return path


def project_with_clip(tmp_path: Path, source: Path):  # type: ignore[no-untyped-def]
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Compiler", width=64, height=64, frame_rate=FrameRate(numerator=24)
    )
    project.media.append(
        MediaReference(
            id="media",
            uri=str(source),
            available_range=TimeRange(start=rt(0), duration=rt(48)),
        )
    )
    clip = Clip(
        id="clip",
        media_reference_id="media",
        timeline_range=TimeRange(start=rt(0), duration=rt(36)),
        source_range=TimeRange(start=rt(6), duration=rt(36)),
        source_audio_enabled=False,
    )
    project.sequence().timeline.tracks = [VideoTrack(id="v1", items=[clip])]
    return engine, project, clip


def create_tone(path: Path) -> None:
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=1000:sample_rate=48000:duration=2",
            "-c:a",
            "pcm_s16le",
            str(path),
        ],
        check=True,
    )


def test_compiler_rebases_range_and_orders_caption_last(tmp_path: Path, source: Path) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    project.sequence().timeline.tracks.append(
        CaptionTrack(
            id="c1",
            items=[
                CaptionCue(
                    id="cue",
                    text="hello",
                    timeline_range=TimeRange(start=rt(12), duration=rt(12)),
                )
            ],
        )
    )
    request = RenderRequest(
        output_path=tmp_path / "range.mp4",
        mode=RenderMode.RANGE,
        timeline_range=TimeRange(start=rt(12), duration=rt(12)),
    )
    compiled = RenderCompiler(project, tmp_path, engine.config).compile(request)
    graph = compiled.graph
    video_trim = next(
        node
        for node in graph.nodes
        if isinstance(node, TrimNode) and node.artifact_type.value == "video"
    )
    assert video_trim.source_range == TimeRange(start=rt(18), duration=rt(12))
    composite = next(node for node in graph.nodes if isinstance(node, CompositeNode))
    caption = next(node for node in graph.nodes if isinstance(node, CaptionNode))
    assert caption.inputs == (composite.id,)
    assert caption.cues[0].timeline_range.start == rt(12)
    assert caption.timeline_offset == rt(12)
    order = graph.topological_order()
    assert order.index(caption.id) > order.index(composite.id)
    assert clip.source_range.start == rt(6)


def test_explicit_audio_cues_require_exact_sample_grid(tmp_path: Path, source: Path) -> None:
    engine, project, _ = project_with_clip(tmp_path, source)
    tone = tmp_path / "sample-accurate.wav"
    create_tone(tone)
    record = engine.media().import_media(tone)
    project.media.append(engine.media().to_media_reference(record))
    exact_start = RationalTime(value=24_001, timescale=48_000)
    exact_end = RationalTime(value=1, timescale=1)
    audio = AudioClip(
        id="sample-cue",
        media_reference_id=record.id,
        timeline_range=TimeRange.from_start_end(exact_start, exact_end),
        source_range=TimeRange(start=RationalTime.zero(), duration=exact_end - exact_start),
    )
    project.sequence().timeline.tracks.append(AudioTrack(id="audio", items=[audio]))

    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "sample-accurate.mp4", sectioning=False)
    )

    mix = next(node for node in compiled.graph.nodes if isinstance(node, AudioMixNode))
    assert any(item.start == exact_start for item in mix.mix_inputs)

    invalid_start = RationalTime(value=1, timescale=48_001)
    invalid = audio.model_copy(
        update={
            "timeline_range": TimeRange.from_start_end(invalid_start, exact_end),
            "source_range": TimeRange(
                start=RationalTime.zero(), duration=exact_end - invalid_start
            ),
        }
    )
    audio_track = project.sequence().timeline.tracks[-1]
    assert isinstance(audio_track, AudioTrack)
    audio_track.items = [invalid]

    with pytest.raises(EngineError) as raised:
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(output_path=tmp_path / "invalid-audio.mp4", sectioning=False)
        )
    assert raised.value.context["item_id"] == "sample-cue"
    assert raised.value.context["sample_rate"] == 48_000


def test_compiler_persists_source_identity_and_detects_changed_bytes(
    tmp_path: Path, source: Path
) -> None:
    engine, project, _ = project_with_clip(tmp_path, source)
    expected = hashlib.sha256(source.read_bytes()).hexdigest()
    project.media[0].sha256 = expected
    request = RenderRequest(output_path=tmp_path / "identity.mp4", sectioning=False)

    compiled = RenderCompiler(project, tmp_path, engine.config).compile(request)
    identity_path = tmp_path / ".video-engine" / "source-identities.json"
    first_identity = identity_path.read_text(encoding="utf-8")
    RenderCompiler(project, tmp_path, engine.config).compile(request)
    assert identity_path.read_text(encoding="utf-8") == first_identity

    decode = next(node for node in compiled.graph.nodes if isinstance(node, DecodeNode))
    assert decode.snapshot_uri is not None
    snapshot = Path(decode.snapshot_uri)
    assert snapshot.read_bytes() == source.read_bytes()

    source.write_bytes(b"changed source bytes")
    execution = FFmpegBackend(engine.config).execute(decode, (), tmp_path / "unused.mkv", tmp_path)
    assert execution.path == snapshot
    assert hashlib.sha256(snapshot.read_bytes()).hexdigest() == expected
    with pytest.raises(EngineError, match="source hash does not match"):
        RenderCompiler(project, tmp_path, engine.config).compile(request)


def test_compiler_builds_independently_cacheable_video_and_audio_sections(
    tmp_path: Path, source: Path
) -> None:
    engine, project, _ = project_with_clip(tmp_path, source)
    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(
            output_path=tmp_path / "sectioned.mp4",
            section_duration=rt(12),
        )
    )

    assert [output.section.timeline_range for output in compiled.section_outputs] == [
        TimeRange(start=rt(0), duration=rt(12)),
        TimeRange(start=rt(12), duration=rt(12)),
        TimeRange(start=rt(24), duration=rt(12)),
    ]
    concats = [node for node in compiled.graph.nodes if isinstance(node, ConcatNode)]
    assert {node.artifact_type.value for node in concats} == {"video", "audio"}
    assert all(len(node.inputs) == 3 for node in concats)
    for output in compiled.section_outputs:
        assert compiled.graph.node(output.video_node_id)
        assert compiled.graph.node(output.audio_node_id)


def test_compiler_maps_speed_ramp_exactly_for_full_and_range(tmp_path: Path, source: Path) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    ramp = Retime(
        speed_ramp=(
            SpeedRampPoint(time=rt(0), rate=1),
            SpeedRampPoint(time=rt(24), rate=2),
        )
    )
    replacement = clip.model_copy(
        update={
            "timeline_range": TimeRange(start=rt(0), duration=rt(24)),
            "source_range": TimeRange(start=rt(0), duration=rt(36)),
            "retime": ramp,
        }
    )
    track = project.sequence().timeline.tracks[0]
    assert isinstance(track, VideoTrack)
    track.items = [replacement]

    full = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "ramp-full.mp4", sectioning=False)
    )
    full_ramp = next(node for node in full.graph.nodes if isinstance(node, SpeedRampNode))
    full_trim = next(
        node
        for node in full.graph.nodes
        if isinstance(node, TrimNode) and node.artifact_type.value == "video"
    )
    assert full_ramp.duration == rt(24)
    assert full_trim.source_range == TimeRange(start=rt(0), duration=rt(36))

    partial = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(
            output_path=tmp_path / "ramp-range.mp4",
            mode=RenderMode.RANGE,
            timeline_range=TimeRange(start=rt(0), duration=rt(12)),
            sectioning=False,
        )
    )
    range_ramp = next(node for node in partial.graph.nodes if isinstance(node, SpeedRampNode))
    range_trim = next(
        node
        for node in partial.graph.nodes
        if isinstance(node, TrimNode) and node.artifact_type.value == "video"
    )
    assert range_ramp.duration == rt(12)
    assert range_trim.source_range == TimeRange(start=rt(0), duration=rt(15))

    reverse_replacement = replacement.model_copy(
        update={"retime": ramp.model_copy(update={"reverse": True})}
    )
    track.items = [reverse_replacement]
    reversed_render = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "ramp-reverse.mp4", sectioning=False)
    )
    reverse_node = next(
        node
        for node in reversed_render.graph.nodes
        if isinstance(node, ReverseNode) and node.artifact_type.value == "video"
    )
    reverse_ramp = next(
        node
        for node in reversed_render.graph.nodes
        if isinstance(node, SpeedRampNode) and node.artifact_type.value == "video"
    )
    reverse_conform = next(
        node
        for node in reversed_render.graph.nodes
        if isinstance(node, ConformNode) and node.artifact_type.value == "video"
    )
    assert reverse_node.inputs == ("clip-trim-video",)
    assert reverse_ramp.inputs == (reverse_node.id,)
    assert reverse_conform.inputs == (reverse_ramp.id,)


def test_ffmpeg_backend_rejects_impractical_temporal_rates(tmp_path: Path) -> None:
    backend = FFmpegBackend(VideoEngine(tmp_path).config)
    node = SpeedNode(
        id="too-slow",
        inputs=("source",),
        artifact_type="audio",
        rate=RationalRate(numerator=1, denominator=1_000),
        duration=rt(24),
        frame_rate=FrameRate(numerator=24),
        sample_rate=48_000,
    )

    assert not backend.can_execute(node)
    with pytest.raises(EngineError, match=r"between 0\.01 and 100"):
        backend._atempo_filters(0.001)


def test_compiler_resolves_direct_chapter_render_range(tmp_path: Path, source: Path) -> None:
    engine, project, _ = project_with_clip(tmp_path, source)
    project.sequence().timeline.markers = [
        Marker(id="opening", time=rt(0), extensions={"kind": "chapter"}),
        Marker(id="body", time=rt(18), extensions={"kind": "chapter"}),
    ]

    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(
            output_path=tmp_path / "body.mp4",
            mode=RenderMode.RANGE,
            chapter_id="body",
        )
    )

    assert compiled.timeline_range == TimeRange(start=rt(18), duration=rt(18))
    assert len(compiled.section_outputs) == 1
    assert compiled.section_outputs[0].section.chapter_id == "body"


def test_compiler_bounds_visual_and_audio_process_fan_in(tmp_path: Path, source: Path) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    engine.config.max_render_inputs = 3
    project.sequence().timeline.tracks = [
        VideoTrack(
            id=f"video-{index}",
            items=[clip.model_copy(update={"id": f"visual-{index}"}, deep=True)],
        )
        for index in range(10)
    ] + [
        AudioTrack(
            id=f"audio-{index}",
            items=[
                AudioClip(
                    id=f"audio-item-{index}",
                    media_reference_id="media",
                    timeline_range=TimeRange(start=rt(0), duration=rt(36)),
                    source_range=TimeRange(start=rt(0), duration=rt(36)),
                )
            ],
        )
        for index in range(10)
    ]

    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "bounded.mp4", sectioning=False)
    )

    composites = [node for node in compiled.graph.nodes if isinstance(node, CompositeNode)]
    audio_mixes = [node for node in compiled.graph.nodes if isinstance(node, AudioMixNode)]
    assert len(composites) > 1
    assert len(audio_mixes) > 10
    assert max(len(node.inputs) for node in composites) <= 3
    assert max(len(node.inputs) for node in audio_mixes) <= 3
    decodes = [node for node in compiled.graph.nodes if isinstance(node, DecodeNode)]
    assert [node.artifact_type.value for node in decodes].count("video") == 1
    assert [node.artifact_type.value for node in decodes].count("audio") == 1


def test_compiler_maps_partial_fast_retime_to_exact_source_range(
    tmp_path: Path, source: Path
) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    retimed = Clip.model_validate(
        {
            **clip.model_dump(mode="python"),
            "timeline_range": TimeRange(start=rt(0), duration=rt(18)),
            "source_range": TimeRange(start=rt(6), duration=rt(36)),
            "retime": Retime(rate="2"),
        }
    )
    track = project.sequence().timeline.tracks[0]
    assert isinstance(track, VideoTrack)
    track.items[0] = retimed

    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(
            output_path=tmp_path / "fast-range.mp4",
            mode=RenderMode.RANGE,
            timeline_range=TimeRange(start=rt(6), duration=rt(6)),
        )
    )

    trim = next(node for node in compiled.graph.nodes if isinstance(node, TrimNode))
    speed = next(node for node in compiled.graph.nodes if isinstance(node, SpeedNode))
    assert trim.source_range == TimeRange(start=rt(18), duration=rt(12))
    assert speed.rate.fraction == 2


def test_compiler_maps_reverse_range_from_the_source_end(tmp_path: Path, source: Path) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    reversed_clip = Clip.model_validate(
        {
            **clip.model_dump(mode="python"),
            "timeline_range": TimeRange(start=rt(0), duration=rt(18)),
            "source_range": TimeRange(start=rt(6), duration=rt(36)),
            "retime": Retime(rate="2", reverse=True),
        }
    )
    track = project.sequence().timeline.tracks[0]
    assert isinstance(track, VideoTrack)
    track.items[0] = reversed_clip

    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(
            output_path=tmp_path / "reverse-range.mp4",
            mode=RenderMode.RANGE,
            timeline_range=TimeRange(start=rt(0), duration=rt(6)),
        )
    )

    trim = next(node for node in compiled.graph.nodes if isinstance(node, TrimNode))
    reverse = next(node for node in compiled.graph.nodes if isinstance(node, ReverseNode))
    assert trim.source_range == TimeRange(start=rt(30), duration=rt(12))
    assert reverse.reverse_video


def test_compiler_requires_explicit_multilingual_caption_selection(
    tmp_path: Path, source: Path
) -> None:
    engine, project, _ = project_with_clip(tmp_path, source)
    cue_range = TimeRange(start=rt(0), duration=rt(12))
    project.sequence().timeline.tracks.extend(
        [
            CaptionTrack(
                id="english",
                language="en",
                items=[CaptionCue(id="en", text="Hello", timeline_range=cue_range)],
            ),
            CaptionTrack(
                id="french",
                language="fr",
                items=[CaptionCue(id="fr", text="Bonjour", timeline_range=cue_range)],
            ),
        ]
    )
    with pytest.raises(EngineError, match="explicit render selection"):
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(output_path=tmp_path / "ambiguous.mp4")
        )
    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(
            output_path=tmp_path / "english.mp4",
            caption_track_ids=("english",),
        )
    )
    caption = next(node for node in compiled.graph.nodes if isinstance(node, CaptionNode))
    assert [cue.text for cue in caption.cues] == ["Hello"]

    no_captions = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "clean.mp4", caption_track_ids=())
    )
    assert not any(isinstance(node, CaptionNode) for node in no_captions.graph.nodes)


def test_caption_track_selection_propagates_language_into_nested_sequences(
    tmp_path: Path, source: Path
) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    nested = Sequence(
        id="nested",
        name="Nested",
        timeline=Timeline(
            tracks=[
                VideoTrack(id="nested-video", items=[clip.model_copy(update={"id": "source"})]),
                CaptionTrack(
                    id="nested-en",
                    language="en",
                    items=[
                        CaptionCue(
                            id="nested-en-cue",
                            text="EN",
                            timeline_range=TimeRange(start=rt(0), duration=rt(12)),
                        )
                    ],
                ),
                CaptionTrack(
                    id="nested-fr",
                    language="fr",
                    items=[
                        CaptionCue(
                            id="nested-fr-cue",
                            text="FR",
                            timeline_range=TimeRange(start=rt(0), duration=rt(12)),
                        )
                    ],
                ),
            ]
        ),
    )
    project.sequences.append(nested)
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="root-video",
            items=[
                NestedSequenceClip(
                    id="nested-item",
                    sequence_id="nested",
                    timeline_range=TimeRange(start=rt(0), duration=rt(36)),
                    source_range=TimeRange(start=rt(0), duration=rt(36)),
                )
            ],
        ),
        CaptionTrack(id="root-en", language="en"),
    ]
    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(
            output_path=tmp_path / "nested-en.mp4",
            caption_track_ids=("root-en",),
        )
    )
    captions = [node for node in compiled.graph.nodes if isinstance(node, CaptionNode)]
    assert len(captions) == 1
    assert [cue.text for cue in captions[0].cues] == ["EN"]


def test_schema_rejects_unknown_effect_parameters() -> None:
    with pytest.raises(ValidationError, match="effect parameters are invalid"):
        Effect(
            id="bad-grade",
            kind=EffectKind.COLOR_GRADE,
            parameters={"contrast": 1.1, "raw_filter": "hue=s=0"},
        )


def test_transition_parameters_are_backend_neutral_and_strict() -> None:
    transition = Transition(
        id="wipe-right",
        kind=TransitionKind.WIPE,
        from_item_id="left",
        to_item_id="right",
        duration=rt(6),
        parameters={"direction": "right"},
    )
    assert transition.parameters == {"direction": "right"}

    with pytest.raises(ValidationError, match="transition parameters are invalid"):
        Transition(
            id="raw-backend-name",
            kind=TransitionKind.WIPE,
            from_item_id="left",
            to_item_id="right",
            duration=rt(6),
            parameters={"ffmpeg_name": "pixelize"},
        )


def test_graphic_asset_aliases_receive_unique_staged_names(tmp_path: Path, source: Path) -> None:
    engine, project, _ = project_with_clip(tmp_path, source)
    project.sequence().timeline.tracks = [
        GraphicsTrack(
            id="graphics",
            items=[
                GeneratorClip(
                    id="split",
                    generator_id="split_screen",
                    timeline_range=TimeRange(start=rt(0), duration=rt(24)),
                    properties={
                        "left_asset_id": "left",
                        "right_asset_id": "right",
                    },
                    assets=[
                        GeneratorAssetReference(id="left", media_reference_id="media"),
                        GeneratorAssetReference(id="right", media_reference_id="media"),
                    ],
                )
            ],
        )
    ]
    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "split.mp4")
    )
    motion = next(node for node in compiled.graph.nodes if isinstance(node, MotionGraphicNode))
    assert [asset.id for asset in motion.assets] == ["left", "right"]
    assert len({asset.staged_name for asset in motion.assets}) == 2


def test_compiler_resolves_lut_assets_from_project_root(tmp_path: Path, source: Path) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    lut = tmp_path / "look.cube"
    lut.write_text(
        "TITLE test\nLUT_3D_SIZE 2\n0 0 0\n0 0 1\n0 1 0\n0 1 1\n1 0 0\n1 0 1\n1 1 0\n1 1 1\n",
        encoding="ascii",
    )
    clip.effects.append(Effect(id="lut", kind=EffectKind.LUT, parameters={"path": "look.cube"}))
    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "lut.mp4")
    )
    grade = next(node for node in compiled.graph.nodes if isinstance(node, GradeNode))
    assert grade.lut_path == str(lut.resolve())


def test_compiler_lowers_item_and_disabled_track_matte_references(
    tmp_path: Path, source: Path
) -> None:
    engine, project, owner = project_with_clip(tmp_path, source)
    matte = owner.model_copy(
        deep=True,
        update={"id": "matte", "source_audio_enabled": False, "effects": []},
    )
    matte_track = GraphicsTrack(id="matte-track", enabled=False, items=[matte])
    project.sequence().timeline.tracks.append(matte_track)
    owner.effects = [
        Effect(
            id="item-matte",
            kind=EffectKind.TRACK_MATTE,
            parameters={"item_id": "matte", "channel": "luma"},
        )
    ]

    item_compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "item-matte.mp4", sectioning=False)
    )
    item_mask = next(
        node
        for node in item_compiled.graph.nodes
        if isinstance(node, MaskNode) and node.id == "clip-item-matte"
    )
    assert item_mask.mode == "luma_matte"
    assert len(item_mask.inputs) == 2
    assert item_mask.inputs[1].startswith("matte-")

    owner.effects = [
        Effect(
            id="track-matte",
            kind=EffectKind.TRACK_MATTE,
            parameters={"track_id": "matte-track", "channel": "alpha"},
        )
    ]
    matte_track.items = [
        matte.model_copy(
            deep=True,
            update={
                "id": "matte-a",
                "timeline_range": TimeRange(start=rt(0), duration=rt(12)),
                "source_range": TimeRange(start=rt(6), duration=rt(12)),
            },
        ),
        matte.model_copy(
            deep=True,
            update={
                "id": "matte-b",
                "timeline_range": TimeRange(start=rt(24), duration=rt(12)),
                "source_range": TimeRange(start=rt(24), duration=rt(12)),
            },
        ),
    ]
    track_compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "track-matte.mp4", sectioning=False)
    )
    track_mask = next(
        node
        for node in track_compiled.graph.nodes
        if isinstance(node, MaskNode) and node.id == "clip-track-matte"
    )
    matte_composite = next(
        node
        for node in track_compiled.graph.nodes
        if isinstance(node, CompositeNode) and node.id == "clip-track-matte-matte-track-composite"
    )
    assert track_mask.inputs[1] == matte_composite.id
    assert matte_composite.background_color == "black@0"
    assert [layer.timeline_range for layer in matte_composite.layers] == [
        TimeRange(start=rt(0), duration=rt(12)),
        TimeRange(start=rt(24), duration=rt(12)),
    ]


def test_track_matte_validation_rejects_invalid_references_and_cycles(
    tmp_path: Path, source: Path
) -> None:
    engine, project, owner = project_with_clip(tmp_path, source)
    matte = owner.model_copy(
        deep=True,
        update={"id": "matte", "source_audio_enabled": False, "effects": []},
    )
    project.sequence().timeline.tracks.append(
        GraphicsTrack(id="matte-track", enabled=False, items=[matte])
    )
    owner.effects = [
        Effect(
            id="owner-matte",
            kind=EffectKind.TRACK_MATTE,
            parameters={"item_id": "matte"},
        )
    ]
    matte.effects = [
        Effect(
            id="matte-owner",
            kind=EffectKind.TRACK_MATTE,
            parameters={"item_id": "clip"},
        )
    ]

    with pytest.raises(EngineError) as cycle:
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(output_path=tmp_path / "cycle.mp4", sectioning=False)
        )
    issues = cycle.value.context["issues"]
    assert isinstance(issues, list)
    assert any(issue["code"] == "timeline.track_matte_cycle" for issue in issues)

    matte.effects = []
    matte.enabled = False
    with pytest.raises(EngineError) as disabled:
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(output_path=tmp_path / "disabled.mp4", sectioning=False)
        )
    issues = disabled.value.context["issues"]
    assert isinstance(issues, list)
    assert any(issue["code"] == "timeline.track_matte_item_disabled" for issue in issues)


def test_track_matte_parameters_require_exactly_one_source() -> None:
    with pytest.raises(ValidationError):
        Effect(id="empty", kind=EffectKind.TRACK_MATTE, parameters={})
    with pytest.raises(ValidationError):
        Effect(
            id="ambiguous",
            kind=EffectKind.TRACK_MATTE,
            parameters={"path": "matte.png", "item_id": "matte"},
        )


@pytest.mark.parametrize(
    "effect",
    [
        Effect(
            id="animated-asset-mask",
            kind=EffectKind.MASK,
            parameters={"shape": "asset", "path": "mask.png"},
            keyframes=[Keyframe(id="mask-x", property_path="x", time=rt(0), value=0)],
        ),
        Effect(
            id="animated-full-blur",
            kind=EffectKind.BACKGROUND_BLUR,
            parameters={"sigma": 8},
            keyframes=[Keyframe(id="blur-x", property_path="x", time=rt(0), value=0)],
        ),
    ],
)
def test_compiler_rejects_visual_automation_that_cannot_execute(
    tmp_path: Path, source: Path, effect: Effect
) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    clip.effects = [effect]
    with pytest.raises(EngineError, match="keyframes"):
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(output_path=tmp_path / "unsupported-automation.mp4")
        )


def test_compiler_rejects_animated_regions_that_can_leave_canvas(
    tmp_path: Path, source: Path
) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    clip.effects = [
        Effect(
            id="escaping-mask",
            kind=EffectKind.MASK,
            parameters={"shape": "rectangle", "x": 0, "y": 0, "width": 0.5, "height": 1},
            keyframes=[Keyframe(id="mask-x", property_path="x", time=rt(12), value=0.6)],
        )
    ]
    with pytest.raises(EngineError, match="outside the normalized canvas"):
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(output_path=tmp_path / "escaping-mask.mp4")
        )


def test_matte_track_transitions_compile_and_dense_tracks_are_staged(
    tmp_path: Path, source: Path
) -> None:
    engine, project, owner = project_with_clip(tmp_path, source)
    owner.effects = [
        Effect(
            id="track-matte",
            kind=EffectKind.TRACK_MATTE,
            parameters={"track_id": "matte-track", "channel": "luma"},
        )
    ]
    base = owner.model_copy(deep=True, update={"effects": [], "source_audio_enabled": False})
    matte_track = GraphicsTrack(
        id="matte-track",
        enabled=False,
        items=[
            base.model_copy(
                deep=True,
                update={
                    "id": "matte-left",
                    "timeline_range": TimeRange(start=rt(0), duration=rt(18)),
                    "source_range": TimeRange(start=rt(3), duration=rt(18)),
                },
            ),
            base.model_copy(
                deep=True,
                update={
                    "id": "matte-right",
                    "timeline_range": TimeRange(start=rt(18), duration=rt(18)),
                    "source_range": TimeRange(start=rt(21), duration=rt(18)),
                },
            ),
        ],
        transitions=[
            Transition(
                id="matte-dissolve",
                kind=TransitionKind.DISSOLVE,
                from_item_id="matte-left",
                to_item_id="matte-right",
                duration=rt(6),
            )
        ],
    )
    project.sequence().timeline.tracks.append(matte_track)
    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "matte-transition.mp4", sectioning=False)
    )
    assert any(
        isinstance(node, TransitionNode) and node.id == "transition-matte-dissolve"
        for node in compiled.graph.nodes
    )

    matte_track.transitions = []
    matte_track.items = [
        base.model_copy(
            deep=True,
            update={
                "id": f"matte-{index}",
                "timeline_range": TimeRange(start=rt(index * 6), duration=rt(6)),
                "source_range": TimeRange(start=rt(index * 6), duration=rt(6)),
            },
        )
        for index in range(6)
    ]
    engine.config.max_render_inputs = 3
    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "matte-staged.mp4", sectioning=False)
    )
    matte_composites = [
        node
        for node in compiled.graph.nodes
        if isinstance(node, CompositeNode) and "matte-track-composite" in node.id
    ]
    assert len(matte_composites) == 3
    assert all(len(node.inputs) <= 3 for node in matte_composites)
    assert all(node.background_color == "black@0" for node in matte_composites)


def test_item_matte_validation_includes_transition_handles_and_snapshots(
    tmp_path: Path, source: Path
) -> None:
    engine, project, owner = project_with_clip(tmp_path, source)
    owner = owner.model_copy(
        deep=True,
        update={
            "timeline_range": TimeRange(start=rt(0), duration=rt(18)),
            "source_range": TimeRange(start=rt(6), duration=rt(18)),
        },
    )
    right = owner.model_copy(
        deep=True,
        update={
            "id": "right",
            "timeline_range": TimeRange(start=rt(18), duration=rt(18)),
            "source_range": TimeRange(start=rt(24), duration=rt(18)),
            "effects": [],
        },
    )
    matte = owner.model_copy(
        deep=True,
        update={"id": "matte", "effects": [], "source_audio_enabled": False},
    )
    owner.effects = [
        Effect(
            id="item-matte",
            kind=EffectKind.TRACK_MATTE,
            parameters={"item_id": "matte"},
        )
    ]
    project.sequence().timeline.tracks[0].items = [owner, right]
    project.sequence().timeline.tracks[0].transitions = [
        Transition(
            id="centered",
            kind=TransitionKind.DISSOLVE,
            from_item_id=owner.id,
            to_item_id=right.id,
            duration=rt(6),
        )
    ]
    project.sequence().timeline.tracks.append(
        GraphicsTrack(id="matte-track", enabled=False, items=[matte])
    )
    with pytest.raises(EngineError) as uncovered:
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(output_path=tmp_path / "uncovered-handle.mp4", sectioning=False)
        )
    assert any(
        issue["code"] == "timeline.track_matte_range_uncovered"
        for issue in uncovered.value.context["issues"]
    )

    project.sequence().timeline.tracks[0].transitions = []
    project.sequence().revision = 2
    snapshot_sequence = project.sequence().model_copy(deep=True, update={"revision": 1})
    snapshot_matte = snapshot_sequence.timeline.tracks[-1].items[0]
    snapshot_matte.enabled = False
    project.sequence_versions = [SequenceSnapshot.from_sequence(snapshot_sequence)]
    with pytest.raises(EngineError) as invalid_snapshot:
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(output_path=tmp_path / "invalid-snapshot.mp4", sectioning=False)
        )
    assert any(
        issue["code"] == "timeline.track_matte_item_disabled"
        and issue["path"].startswith("sequence_versions[0]")
        for issue in invalid_snapshot.value.context["issues"]
    )


def test_color_interpretation_precedes_normalization_fit_and_grade(
    tmp_path: Path, source: Path
) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    clip.effects.extend(
        [
            Effect(
                id="interpret-pq",
                kind=EffectKind.COLOR_INTERPRETATION,
                parameters={"input_space": "pq"},
            ),
            Effect(
                id="normalize",
                kind=EffectKind.COLOR_NORMALIZATION,
                parameters={"tone_map": "reinhard", "peak_nits": 400},
            ),
            Effect(
                id="creative",
                kind=EffectKind.COLOR_GRADE,
                parameters={"gamma": 1.07, "saturation": 0.8},
            ),
        ]
    )

    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "color-stages.mp4")
    )

    conversion = next(
        node for node in compiled.graph.nodes if isinstance(node, ColorConversionNode)
    )
    grade = next(node for node in compiled.graph.nodes if isinstance(node, GradeNode))
    fit = next(
        node
        for node in compiled.graph.nodes
        if node.node_type is NodeKind.SCALE and node.id == "clip-fit"
    )
    order = compiled.graph.topological_order()
    assert conversion.input_space.value == "pq"
    assert conversion.output_space.value == "rec709"
    assert conversion.tone_map == "reinhard"
    assert conversion.peak_nits == 400
    assert grade.gamma == 1.07
    assert order.index(conversion.id) < order.index(fit.id) < order.index(grade.id)


def test_compiler_rejects_hdr_to_sdr_without_tone_mapping(tmp_path: Path, source: Path) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    clip.effects.extend(
        [
            Effect(
                id="interpret-hlg",
                kind=EffectKind.COLOR_INTERPRETATION,
                parameters={"input_space": "hlg"},
            ),
            Effect(
                id="normalize-none",
                kind=EffectKind.COLOR_NORMALIZATION,
                parameters={"tone_map": "none", "peak_nits": 1_000},
            ),
        ]
    )

    with pytest.raises(EngineError, match="requires an explicit tone-map"):
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(output_path=tmp_path / "invalid-color.mp4")
        )


def test_compiler_rejects_duplicate_source_color_interpretations(
    tmp_path: Path, source: Path
) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    clip.effects.extend(
        [
            Effect(
                id="first",
                kind=EffectKind.COLOR_INTERPRETATION,
                parameters={"input_space": "hlg"},
            ),
            Effect(
                id="second",
                kind=EffectKind.COLOR_INTERPRETATION,
                parameters={"input_space": "pq"},
            ),
        ]
    )

    with pytest.raises(EngineError, match="only one interpretation"):
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(output_path=tmp_path / "duplicate-color.mp4")
        )


def test_compiler_lowers_rational_audio_automation(tmp_path: Path, source: Path) -> None:
    engine, project, _ = project_with_clip(tmp_path, source)
    project.sequence().timeline.audio_buses = [
        AudioBus(
            id="master",
            name="Master",
            effects=[
                Effect(
                    id="automated-gain",
                    kind=EffectKind.GAIN,
                    parameters={"db": 0},
                    keyframes=[
                        Keyframe(
                            id="gain-down",
                            property_path="db",
                            time=rt(12),
                            value=-12,
                        )
                    ],
                )
            ],
        )
    ]
    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "output.mp4")
    )
    process = next(
        node
        for node in compiled.graph.nodes
        if isinstance(node, AudioProcessNode) and node.id == "audio-bus-master-process"
    )
    assert process.processors[0].automation[0].time == rt(12)
    assert process.processors[0].automation[0].value == -12


def test_compiler_lowers_visual_automation_with_range_offset(tmp_path: Path, source: Path) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    clip.effects.append(
        Effect(
            id="move",
            kind=EffectKind.POSITION,
            parameters={"x": 0, "y": 12},
            keyframes=[
                Keyframe(id="start", property_path="x", time=rt(0), value=-20),
                Keyframe(id="end", property_path="x", time=rt(24), value=20),
            ],
        )
    )

    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(
            output_path=tmp_path / "visual-automation.mp4",
            mode=RenderMode.RANGE,
            timeline_range=TimeRange(start=rt(12), duration=rt(12)),
        )
    )

    transform = next(
        node
        for node in compiled.graph.nodes
        if isinstance(node, TransformNode) and node.id == "clip-move"
    )
    assert transform.automation_offset == rt(12)
    assert [point.property_path for point in transform.automation] == [
        "position_x",
        "position_x",
    ]
    assert [point.value for point in transform.automation] == [-20, 20]


def test_compiler_maps_blend_modes_to_composite_layers(tmp_path: Path, source: Path) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    clip.effects.append(
        Effect(
            id="screen",
            kind=EffectKind.BLEND_MODE,
            parameters={"mode": "screen", "opacity": 0.75},
        )
    )

    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "blend.mp4")
    )

    composite = next(node for node in compiled.graph.nodes if isinstance(node, CompositeNode))
    assert composite.layers[0].blend_mode == "screen"
    assert composite.layers[0].opacity == 0.75
    assert not any(node.id == "clip-screen" for node in compiled.graph.nodes)


def test_compiler_segments_discrete_blend_mode_automation(tmp_path: Path, source: Path) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    clip.effects.append(
        Effect(
            id="blend-state",
            kind=EffectKind.BLEND_MODE,
            parameters={"mode": "multiply", "opacity": 0.5},
            keyframes=[
                Keyframe(
                    id="screen-halfway",
                    property_path="mode",
                    time=rt(18),
                    value="screen",
                    interpolation=Interpolation.HOLD,
                ),
                Keyframe(
                    id="opaque-halfway",
                    property_path="opacity",
                    time=rt(18),
                    value=1,
                    interpolation=Interpolation.HOLD,
                ),
            ],
        )
    )

    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "animated-blend.mp4")
    )

    composite = next(node for node in compiled.graph.nodes if isinstance(node, CompositeNode))
    assert [layer.blend_mode for layer in composite.layers] == ["multiply", "screen"]
    assert [layer.opacity for layer in composite.layers] == [0.5, 1]
    assert [layer.timeline_range for layer in composite.layers] == [
        TimeRange(start=rt(0), duration=rt(18)),
        TimeRange(start=rt(18), duration=rt(18)),
    ]
    segments = [
        node
        for node in compiled.graph.nodes
        if isinstance(node, TrimNode) and "blend-segment" in node.id
    ]
    assert [node.source_range for node in segments] == [
        TimeRange(start=rt(0), duration=rt(18)),
        TimeRange(start=rt(18), duration=rt(18)),
    ]


def test_compiler_scopes_adjustment_layer_grades_to_the_render_range(
    tmp_path: Path, source: Path
) -> None:
    engine, project, _ = project_with_clip(tmp_path, source)
    project.sequence().timeline.tracks.append(
        AdjustmentTrack(
            id="adjustments",
            items=[
                AdjustmentClip(
                    id="look",
                    timeline_range=TimeRange(start=rt(6), duration=rt(18)),
                    effects=[
                        Effect(
                            id="contrast",
                            kind=EffectKind.COLOR_GRADE,
                            parameters={"contrast": 1.2},
                        )
                    ],
                )
            ],
        )
    )

    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(
            output_path=tmp_path / "adjustment-range.mp4",
            mode=RenderMode.RANGE,
            timeline_range=TimeRange(start=rt(12), duration=rt(12)),
        )
    )

    grade = next(node for node in compiled.graph.nodes if isinstance(node, GradeNode))
    assert grade.enabled_range == TimeRange(start=rt(0), duration=rt(12))


def test_compiler_rejects_visual_keyframes_for_the_wrong_property(
    tmp_path: Path, source: Path
) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    clip.effects.append(
        Effect(
            id="bad-opacity",
            kind=EffectKind.OPACITY,
            parameters={"value": 1},
            keyframes=[Keyframe(id="bad", property_path="x", time=rt(0), value=0.5)],
        )
    )

    with pytest.raises(EngineError, match="wrong property"):
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(output_path=tmp_path / "bad-automation.mp4")
        )


def test_compiler_lowers_bus_sidechain_and_rejects_dependency_cycles(
    tmp_path: Path, source: Path
) -> None:
    engine, project, _ = project_with_clip(tmp_path, source)
    dialogue = AudioBus(id="dialogue", name="Dialogue", parent_bus_id="master")
    music = AudioBus(
        id="music",
        name="Music",
        parent_bus_id="master",
        effects=[
            Effect(
                id="duck",
                kind=EffectKind.SIDECHAIN_DUCKING,
                parameters={"key_bus_id": "dialogue", "threshold_db": -30},
            )
        ],
    )
    project.sequence().timeline.audio_buses = [
        AudioBus(id="master", name="Master"),
        dialogue,
        music,
    ]
    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "sidechain.mp4")
    )
    sidechain = next(node for node in compiled.graph.nodes if isinstance(node, AudioSidechainNode))
    assert sidechain.inputs == ("audio-bus-music-mix", "audio-bus-dialogue-mix")

    dialogue.effects.append(
        Effect(
            id="cycle",
            kind=EffectKind.SIDECHAIN_DUCKING,
            parameters={"key_bus_id": "music"},
        )
    )
    with pytest.raises(EngineError, match="dependencies contain a cycle"):
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(output_path=tmp_path / "cycle.mp4")
        )


def test_compiler_rejects_unknown_explicit_delivery_profile(tmp_path: Path, source: Path) -> None:
    engine, project, _ = project_with_clip(tmp_path, source)
    with pytest.raises(EngineError, match="profile was not found"):
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(
                output_path=tmp_path / "output.mp4",
                delivery_profile_id="missing",
            )
        )


def test_compiler_lowers_transition_without_changing_timeline_duration(
    tmp_path: Path, source: Path
) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    second = clip.model_copy(
        deep=True,
        update={
            "id": "second",
            "timeline_range": TimeRange(start=rt(36), duration=rt(12)),
            "source_range": TimeRange(start=rt(24), duration=rt(12)),
        },
    )
    track = project.sequence().timeline.tracks[0]
    assert isinstance(track, VideoTrack)
    track.items.append(second)
    track.transitions.append(
        Transition(
            id="dissolve",
            kind=TransitionKind.DISSOLVE,
            from_item_id=clip.id,
            to_item_id=second.id,
            duration=rt(6),
        )
    )
    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "output.mp4")
    )
    transition = next(node for node in compiled.graph.nodes if isinstance(node, TransitionNode))
    assert transition.duration == rt(6)
    assert transition.offset == RationalTime.zero()
    assert compiled.timeline_range.duration == rt(48)


def test_compiler_lowers_audio_crossfade_with_source_handles(tmp_path: Path, source: Path) -> None:
    engine, project, _ = project_with_clip(tmp_path, source)
    left = AudioClip(
        id="left-audio",
        media_reference_id="media",
        timeline_range=TimeRange(start=rt(0), duration=rt(24)),
        source_range=TimeRange(start=rt(6), duration=rt(24)),
    )
    right = AudioClip(
        id="right-audio",
        media_reference_id="media",
        timeline_range=TimeRange(start=rt(24), duration=rt(24)),
        source_range=TimeRange(start=rt(24), duration=rt(24)),
    )
    project.sequence().timeline.tracks.append(
        AudioTrack(
            id="a1",
            items=[left, right],
            transitions=[
                Transition(
                    id="audio-dissolve",
                    kind=TransitionKind.AUDIO_CROSSFADE,
                    from_item_id=left.id,
                    to_item_id=right.id,
                    duration=rt(6),
                )
            ],
        )
    )
    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "audio-crossfade.mp4")
    )
    crossfade = next(
        node
        for node in compiled.graph.nodes
        if isinstance(node, TransitionNode) and node.artifact_type.value == "audio"
    )
    assert crossfade.transition is TransitionKind.AUDIO_CROSSFADE
    assert crossfade.duration == rt(6)
    assert crossfade.audio_sample_rate == 48_000


def test_compiler_rejects_transition_without_source_handles(tmp_path: Path, source: Path) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    clip = Clip.model_validate(
        {
            **clip.model_dump(mode="python"),
            "source_range": TimeRange(start=rt(0), duration=rt(24)),
            "timeline_range": TimeRange(start=rt(0), duration=rt(24)),
        }
    )
    second = clip.model_copy(
        deep=True,
        update={
            "id": "second",
            "timeline_range": TimeRange(start=rt(24), duration=rt(24)),
            "source_range": TimeRange(start=rt(0), duration=rt(24)),
        },
    )
    track = project.sequence().timeline.tracks[0]
    assert isinstance(track, VideoTrack)
    track.items[0] = clip
    track.items.append(second)
    track.transitions.append(
        Transition(
            id="no-handles",
            kind=TransitionKind.DISSOLVE,
            from_item_id=clip.id,
            to_item_id=second.id,
            duration=rt(6),
        )
    )
    with pytest.raises(EngineError, match="source handles"):
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(output_path=tmp_path / "output.mp4")
        )


def test_compile_graph_is_independent_of_output_path(tmp_path: Path, source: Path) -> None:
    engine, project, _ = project_with_clip(tmp_path, source)
    first = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "one.mp4")
    )
    second = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "two.mp4")
    )
    assert first.graph.graph_hash == second.graph.graph_hash
    assert [node.node_type for node in first.graph.nodes].count(NodeKind.DECODE) == 1
    assert any(isinstance(node, DecodeNode) for node in first.graph.nodes)


def test_freeze_compiles_item_local_frame_for_full_range_and_reverse(
    tmp_path: Path, source: Path
) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    clip.effects.append(
        Effect(
            id="hold",
            kind=EffectKind.FREEZE,
            parameters=freeze_parameters(rt(12), rt(36)),
        )
    )

    full = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "freeze-full.mp4", sectioning=False)
    )
    full_trim = next(
        node
        for node in full.graph.nodes
        if isinstance(node, TrimNode) and node.artifact_type.value == "video"
    )
    full_freeze = next(node for node in full.graph.nodes if isinstance(node, FreezeNode))
    assert full_trim.source_range == TimeRange(start=rt(18), duration=rt(1))
    assert full_freeze.frame_time == RationalTime.zero()
    assert full_freeze.duration == rt(36)
    assert full_freeze.frame_rate == FrameRate(numerator=24)

    ranged = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(
            output_path=tmp_path / "freeze-range.mp4",
            mode=RenderMode.RANGE,
            timeline_range=TimeRange(start=rt(18), duration=rt(6)),
            sectioning=False,
        )
    )
    ranged_trim = next(
        node
        for node in ranged.graph.nodes
        if isinstance(node, TrimNode) and node.artifact_type.value == "video"
    )
    ranged_freeze = next(node for node in ranged.graph.nodes if isinstance(node, FreezeNode))
    assert ranged_trim.source_range == full_trim.source_range
    assert ranged_freeze.duration == rt(6)

    reversed_clip = clip.model_copy(
        deep=True,
        update={"retime": Retime(reverse=True)},
    )
    track = project.sequence().timeline.tracks[0]
    assert isinstance(track, VideoTrack)
    track.items = [reversed_clip]
    reversed_render = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "freeze-reverse.mp4", sectioning=False)
    )
    reverse_trim = next(
        node
        for node in reversed_render.graph.nodes
        if isinstance(node, TrimNode) and node.artifact_type.value == "video"
    )
    assert reverse_trim.source_range == TimeRange(start=rt(29), duration=rt(1))
    assert any(isinstance(node, ReverseNode) for node in reversed_render.graph.nodes)


@pytest.mark.parametrize(
    ("parameters", "message"),
    [
        (freeze_parameters(rt(12), rt(24)), "duration must equal"),
        (
            freeze_parameters(RationalTime(value=1, timescale=25), rt(36)),
            "align to the sequence frame grid",
        ),
        (freeze_parameters(rt(36), rt(36)), "outside the owning source context"),
    ],
)
def test_freeze_rejects_invalid_item_timing(
    tmp_path: Path,
    source: Path,
    parameters: dict[str, object],
    message: str,
) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    clip.effects.append(Effect(id="invalid-freeze", kind=EffectKind.FREEZE, parameters=parameters))
    with pytest.raises(EngineError, match=message):
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(output_path=tmp_path / "invalid-freeze.mp4")
        )


def test_freeze_target_frame_changes_graph_identity(tmp_path: Path, source: Path) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    clip.effects.append(
        Effect(
            id="hold",
            kind=EffectKind.FREEZE,
            parameters=freeze_parameters(rt(6), rt(36)),
        )
    )
    first = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "first.mp4")
    )
    clip.effects[0] = clip.effects[0].model_copy(
        update={"parameters": freeze_parameters(rt(12), rt(36))}
    )
    second = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "second.mp4")
    )
    assert first.graph.graph_hash != second.graph.graph_hash


def test_freeze_uses_sequence_grid_when_delivery_rate_differs(
    tmp_path: Path,
    source: Path,
) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    delivery = project.delivery_profiles[0].model_copy(
        update={
            "id": "thirty-fps",
            "name": "Thirty FPS",
            "frame_rate": FrameRate(numerator=30),
        }
    )
    project.delivery_profiles = [delivery]
    clip.effects.append(
        Effect(
            id="sequence-grid",
            kind=EffectKind.FREEZE,
            parameters=freeze_parameters(rt(1), rt(36)),
        )
    )
    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(
            output_path=tmp_path / "sequence-grid.mp4",
            delivery_profile_id=delivery.id,
            sectioning=False,
        )
    )
    trim = next(
        node
        for node in compiled.graph.nodes
        if isinstance(node, TrimNode) and node.artifact_type.value == "video"
    )
    assert trim.source_range == TimeRange(start=rt(7), duration=rt(1))
    freeze = next(node for node in compiled.graph.nodes if isinstance(node, FreezeNode))
    assert freeze.frame_rate == FrameRate(numerator=30)

    clip.effects[0] = Effect(
        id="delivery-only-grid",
        kind=EffectKind.FREEZE,
        parameters=freeze_parameters(
            RationalTime(value=1, timescale=30),
            rt(36),
        ),
    )
    with pytest.raises(EngineError, match="sequence frame grid"):
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(
                output_path=tmp_path / "delivery-only-grid.mp4",
                delivery_profile_id=delivery.id,
                sectioning=False,
            )
        )


def test_nested_sequence_compiles_as_reusable_child_graph(tmp_path: Path, source: Path) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    child_clip = clip.model_copy(
        deep=True,
        update={"id": "child-clip", "source_audio_enabled": False},
    )
    child = Sequence(
        id="child",
        name="Child",
        revision=3,
        timeline=Timeline(tracks=[VideoTrack(id="child-v1", items=[child_clip])]),
    )
    project.sequences.append(child)
    nested = NestedSequenceClip(
        id="nested",
        sequence_id=child.id,
        sequence_version=3,
        timeline_range=TimeRange(start=rt(0), duration=rt(12)),
        source_range=TimeRange(start=rt(12), duration=rt(12)),
    )
    parent_track = project.sequence().timeline.tracks[0]
    assert isinstance(parent_track, VideoTrack)
    parent_track.items = [nested]

    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "nested.mp4")
    )
    composites = [node for node in compiled.graph.nodes if isinstance(node, CompositeNode)]
    assert len(composites) == 2
    child_trim = next(
        node
        for node in compiled.graph.nodes
        if isinstance(node, TrimNode) and node.id.startswith("child-clip-trim-video")
    )
    assert child_trim.source_range == TimeRange(start=rt(18), duration=rt(12))

    nested.sequence_version = 2
    with pytest.raises(EngineError, match="project failed invariant validation") as error:
        RenderCompiler(project, tmp_path, engine.config).compile(
            RenderRequest(output_path=tmp_path / "stale.mp4")
        )
    assert any(
        issue["code"] == "timeline.missing_nested_sequence_revision"
        for issue in error.value.context["issues"]
    )


def test_nested_sequence_applies_settings_and_parent_audio_controls(
    tmp_path: Path, source: Path
) -> None:
    engine, project, clip = project_with_clip(tmp_path, source)
    child_clip = clip.model_copy(
        deep=True,
        update={"id": "child-picture", "source_audio_enabled": False},
    )
    child_audio = AudioClip(
        id="child-audio",
        media_reference_id="media",
        timeline_range=TimeRange(start=rt(0), duration=rt(36)),
        source_range=TimeRange(start=rt(0), duration=rt(36)),
    )
    child = Sequence(
        id="child-av",
        name="Child AV",
        settings_override={
            "width": 80,
            "height": 48,
            "audio_sample_rate": 44_100,
        },
        timeline=Timeline(
            tracks=[
                VideoTrack(id="child-video", items=[child_clip]),
                AudioTrack(id="child-audio-track", items=[child_audio]),
            ]
        ),
    )
    project.sequences.append(child)
    parent = project.sequence()
    parent.timeline.audio_buses = [
        AudioBus(id="master", name="Master"),
        AudioBus(id="nested-bus", name="Nested", parent_bus_id="master"),
    ]
    nested = NestedSequenceClip(
        id="nested-av",
        sequence_id=child.id,
        timeline_range=TimeRange(start=rt(0), duration=rt(12)),
        source_range=TimeRange(start=rt(0), duration=rt(12)),
        audio_bus_id="nested-bus",
        audio_gain_db=-6,
        audio_pan=0.25,
    )
    parent_track = parent.timeline.tracks[0]
    assert isinstance(parent_track, VideoTrack)
    parent_track.items = [nested]

    compiled = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "nested-av.mp4")
    )

    composites = [node for node in compiled.graph.nodes if isinstance(node, CompositeNode)]
    assert any((node.width, node.height) == (80, 48) for node in composites)
    assert any(
        isinstance(node, ConformNode)
        and node.artifact_type.value == "audio"
        and node.sample_rate == 48_000
        for node in compiled.graph.nodes
    )
    process = next(
        node
        for node in compiled.graph.nodes
        if isinstance(node, AudioProcessNode) and "nested-av-nested-audio-process" in node.id
    )
    assert [processor.kind for processor in process.processors] == ["gain", "pan"]

    nested.source_audio_enabled = False
    muted = RenderCompiler(project, tmp_path, engine.config).compile(
        RenderRequest(output_path=tmp_path / "nested-muted.mp4")
    )
    assert not any(
        isinstance(node, AudioProcessNode) and "nested-av-nested-audio-process" in node.id
        for node in muted.graph.nodes
    )
