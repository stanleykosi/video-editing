from __future__ import annotations

import json
from pathlib import Path

from video_engine.api.engine import VideoEngine
from video_engine.core.schema import (
    Clip,
    Marker,
    MediaReference,
    Transition,
    TransitionKind,
    VideoTrack,
)
from video_engine.core.time import RationalTime, TimeRange
from video_engine.inspection.models import InspectionKind, InspectionRequest, InspectionStatus


def rt(value: int, timescale: int = 1) -> RationalTime:
    return RationalTime(value=value, timescale=timescale)


def test_timeline_inspection_records_ranges_transition_windows_and_hashes(
    tmp_path: Path,
) -> None:
    engine = VideoEngine(tmp_path)
    project = engine.create_project("Inspection", width=320, height=180)
    project.media.append(
        MediaReference(
            id="m1",
            uri="source.mp4",
            available_range=TimeRange(start=rt(0), duration=rt(4)),
        )
    )
    first = Clip(
        id="first",
        media_reference_id="m1",
        timeline_range=TimeRange(start=rt(0), duration=rt(2)),
        source_range=TimeRange(start=rt(0), duration=rt(2)),
    )
    second = Clip(
        id="second",
        media_reference_id="m1",
        timeline_range=TimeRange(start=rt(2), duration=rt(2)),
        source_range=TimeRange(start=rt(2), duration=rt(2)),
    )
    project.sequence().timeline.tracks.append(
        VideoTrack(
            id="v1",
            name="Picture",
            items=[first, second],
            transitions=[
                Transition(
                    id="dissolve",
                    kind=TransitionKind.DISSOLVE,
                    from_item_id="first",
                    to_item_id="second",
                    duration=rt(1),
                    alignment="center",
                )
            ],
        )
    )
    project.sequence().timeline.markers.append(Marker(id="chapter", time=rt(2)))
    result = engine.inspection(project).inspect(
        InspectionRequest(
            kind=InspectionKind.TIMELINE,
            output_dir=tmp_path / "inspection",
        )
    )

    assert result.status is InspectionStatus.COMPLETE
    assert result.report_json.is_file()
    assert result.report_markdown.is_file()
    assert all(artifact.path.is_file() and artifact.size_bytes > 0 for artifact in result.artifacts)
    payload = json.loads((result.output_dir / "timeline.json").read_text(encoding="utf-8"))
    transition = payload["tracks"][0]["transitions"][0]
    assert transition["cut_time"] == {"value": 2, "timescale": 1}
    assert transition["timeline_range"] == {
        "start": {"value": 3, "timescale": 2},
        "duration": {"value": 1, "timescale": 1},
    }
    assert payload["tracks"][0]["items"][0]["canonical"]["source_range"]
    assert payload["markers"][0]["id"] == "chapter"
    assert payload["audio_buses"][0]["id"] == "master"


def test_timeline_inspection_paginates_time_and_lanes(tmp_path: Path) -> None:
    engine = VideoEngine(tmp_path)
    project = engine.create_project("Paged", width=320, height=180)
    project.media.append(
        MediaReference(
            id="m1",
            uri="source.mp4",
            available_range=TimeRange(start=rt(0), duration=rt(700)),
        )
    )
    for index in range(25):
        items = (
            [
                Clip(
                    id="duration-anchor",
                    media_reference_id="m1",
                    timeline_range=TimeRange(start=rt(0), duration=rt(700)),
                    source_range=TimeRange(start=rt(0), duration=rt(700)),
                )
            ]
            if index == 0
            else []
        )
        project.sequence().timeline.tracks.append(VideoTrack(id=f"v{index:02d}", items=items))
    result = engine.inspection(project).inspect(
        InspectionRequest(
            kind=InspectionKind.TIMELINE,
            output_dir=tmp_path / "paged",
            timeline_page_duration=rt(300),
            max_lanes_per_page=20,
        )
    )

    maps = [artifact for artifact in result.artifacts if artifact.kind == "timeline_map"]
    assert len(maps) == 6
    payload = json.loads((result.output_dir / "timeline.json").read_text(encoding="utf-8"))
    assert len(payload["pages"]) == 6
