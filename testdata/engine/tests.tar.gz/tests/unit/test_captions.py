from __future__ import annotations

from pathlib import Path

import pysubs2
import pytest
from pydantic import ValidationError

from video_engine.api.engine import VideoEngine
from video_engine.captions.ass import escape_ass_text, write_ass
from video_engine.core.schema import (
    CaptionCollisionRegion,
    CaptionCue,
    CaptionStyle,
    CaptionStyleOverride,
    CaptionTrack,
    CaptionWord,
)
from video_engine.core.time import RationalTime, TimeRange
from video_engine.render.cache import cache_key_for_node
from video_engine.render.nodes import (
    ArtifactType,
    CaptionNode,
    CaptionRenderCue,
    CaptionRenderWord,
)


def tr(start: int, duration: int, timescale: int = 1000) -> TimeRange:
    return TimeRange(
        start=RationalTime(value=start, timescale=timescale),
        duration=RationalTime(value=duration, timescale=timescale),
    )


def test_caption_word_timing_is_strict_and_ordered() -> None:
    with pytest.raises(ValidationError, match="ordered and non-overlapping"):
        CaptionCue(
            id="cue",
            text="one two",
            timeline_range=tr(0, 2000),
            words=[
                CaptionWord(text="two", range=tr(1000, 750)),
                CaptionWord(text="one", range=tr(500, 750)),
            ],
        )
    with pytest.raises(ValidationError, match="caption word text must not be blank"):
        CaptionCue(
            id="cue",
            text="blank",
            timeline_range=tr(0, 1000),
            words=[CaptionWord(text=" ", range=tr(0, 500))],
        )
    with pytest.raises(ValidationError, match="caption word duration must be positive"):
        CaptionCue(
            id="cue",
            text="still",
            timeline_range=tr(0, 1000),
            words=[CaptionWord(text="still", range=tr(0, 0))],
        )


def test_caption_style_overrides_reject_unknown_and_invalid_values() -> None:
    with pytest.raises(ValidationError, match="Extra inputs are not permitted"):
        CaptionStyleOverride.model_validate({"raw_ass": "{\\blur99}"})
    with pytest.raises(ValidationError, match="String should match pattern"):
        CaptionStyleOverride(primary_color="yellow")


def test_ass_writer_has_single_hard_break_and_preserves_word_gaps(tmp_path: Path) -> None:
    style = CaptionStyle(id="news", name="News", highlight_color="#00FF00")
    cue = CaptionRenderCue(
        text="unused",
        timeline_range=tr(0, 2000),
        style_id=style.id,
        speaker="Host, Name\nSafe",
        position="custom",
        position_x=0.25,
        position_y=0.75,
        style_overrides=CaptionStyleOverride(font_size_px=44, bold=False),
        words=(
            CaptionRenderWord(text="Hello", timeline_range=tr(250, 500)),
            CaptionRenderWord(
                text="world\n{now}",
                timeline_range=tr(1000, 500),
                highlight=True,
            ),
        ),
    )
    node = CaptionNode(
        id="captions",
        inputs=("video",),
        artifact_type=ArtifactType.VIDEO,
        cues=(cue,),
        width=1920,
        height=1080,
        styles=(style,),
        default_style_id=style.id,
    )
    output = tmp_path / "captions.ass"
    write_ass(node, output)
    ass = output.read_text(encoding="utf-8")
    dialogue = next(line for line in ass.splitlines() if line.startswith("Dialogue:"))
    assert r"\\N" not in dialogue
    assert dialogue.count(r"\N") == 1
    assert r"\pos(480,810)" in dialogue
    assert r"\fs44\b0" in dialogue
    assert r"{\k25}" in dialogue
    assert r"{\k25}" in dialogue[dialogue.index("Hello") :]
    assert r"\1c&H0000FF00&" in dialogue
    assert "\uff5bnow\uff5d" in dialogue
    assert ",Host  Name Safe,0,0,0,," in dialogue
    assert escape_ass_text(r"already\Nbroken") == "already\uff3cNbroken"
    parsed = pysubs2.load(str(output), encoding="utf-8")
    assert len(parsed) == 1


def test_ass_round_trip_restores_reserved_caption_text(tmp_path: Path) -> None:
    original = r"literal {braces} C:\Notes slash\path"
    track = CaptionTrack(
        id="code",
        items=[CaptionCue(id="cue", text=original, timeline_range=tr(0, 1000))],
    )
    path = tmp_path / "code.ass"
    engine = VideoEngine(tmp_path)
    engine.captions().export(track, [CaptionStyle(id="default", name="Default")], path)
    imported = engine.captions().import_file(path)
    cue = imported.track.items[0]
    assert isinstance(cue, CaptionCue)
    assert cue.text == original


def test_ass_boundaries_keep_single_120fps_frame_nonempty(tmp_path: Path) -> None:
    style = CaptionStyle(id="default", name="Default")
    node = CaptionNode(
        id="captions",
        inputs=("video",),
        artifact_type=ArtifactType.VIDEO,
        cues=(
            CaptionRenderCue(
                text="frame",
                timeline_range=tr(2, 1, timescale=120),
                style_id="default",
            ),
        ),
        width=1920,
        height=1080,
        styles=(style,),
    )
    path = tmp_path / "frame.ass"
    write_ass(node, path)
    dialogue = next(
        line
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.startswith("Dialogue:")
    )
    assert ",0:00:00.01,0:00:00.03," in dialogue


@pytest.mark.parametrize("suffix", [".srt", ".vtt"])
def test_caption_sidecar_round_trip_preserves_timing(tmp_path: Path, suffix: str) -> None:
    engine = VideoEngine(tmp_path)
    track = CaptionTrack(
        id="english",
        language="en",
        items=[
            CaptionCue(
                id="cue-1",
                text="First line\nSecond line",
                speaker="Narrator",
                language="en",
                timeline_range=tr(125, 1375),
            )
        ],
    )
    sidecar = tmp_path / f"captions{suffix}"
    exported = engine.captions().export(
        track, [CaptionStyle(id="default", name="Default")], sidecar
    )
    imported = engine.captions().import_file(sidecar, language="en")
    cue = imported.track.items[0]
    assert isinstance(cue, CaptionCue)
    assert cue.timeline_range == tr(125, 1375)
    assert cue.text == "First line\nSecond line"
    features = {loss.feature for loss in exported.losses}
    assert "language" in features
    if suffix == ".vtt":
        assert cue.speaker == "Narrator"
        assert "speaker" not in features
    else:
        assert cue.speaker is None
        assert "speaker" in features


def test_caption_cache_key_tracks_resolved_font_content(tmp_path: Path) -> None:
    font = tmp_path / "font.ttf"
    font.write_bytes(b"font-version-one")
    style = CaptionStyle(id="default", name="Default")
    node = CaptionNode(
        id="captions",
        inputs=("video",),
        artifact_type=ArtifactType.VIDEO,
        cues=(
            CaptionRenderCue(
                text="Font",
                timeline_range=tr(0, 1000),
                style_id="default",
            ),
        ),
        width=1920,
        height=1080,
        styles=(style,),
        font_paths=(str(font),),
    )
    first = cache_key_for_node(
        node,
        ("video-input",),
        backend_name="ffmpeg",
        backend_version="test",
        tool_fingerprint="ffmpeg-test",
    )
    font.write_bytes(b"font-version-two")
    second = cache_key_for_node(
        node,
        ("video-input",),
        backend_name="ffmpeg",
        backend_version="test",
        tool_fingerprint="ffmpeg-test",
    )
    assert first != second


def test_ass_import_preserves_style_and_reports_uninterpreted_tags(tmp_path: Path) -> None:
    source = tmp_path / "input.ass"
    source.write_text(
        "\n".join(
            [
                "[Script Info]",
                "ScriptType: v4.00+",
                "PlayResX: 1920",
                "PlayResY: 1080",
                "",
                "[V4+ Styles]",
                "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,"
                "OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,"
                "ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,"
                "MarginR,MarginV,Encoding",
                "Style: Header,DejaVu Sans,48,&H0000FFFF,&H000000FF,&H00000000,"
                "&H80000000,-1,0,0,0,100,100,0,0,1,2,1,8,20,20,30,1",
                "",
                "[Events]",
                "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text",
                r"Dialogue: 0,0:00:00.10,0:00:01.50,Header,Narrator,0,0,0,," r"{\i1}Hello\Nworld",
                "",
            ]
        ),
        encoding="utf-8",
    )
    imported = VideoEngine(tmp_path).captions().import_file(source, language="en")
    assert imported.styles[0].font_family == "DejaVu Sans"
    assert imported.styles[0].primary_color == "#FFFF00"
    cue = imported.track.items[0]
    assert isinstance(cue, CaptionCue)
    assert cue.position == "top"
    assert cue.speaker == "Narrator"
    assert cue.text == "Hello\nworld"
    assert {loss.feature for loss in imported.losses} == {
        "ass_override_tags",
        "ass_style_metrics",
    }
    assert cue.extensions["unsupported_override_tags"] == r"{\i1}Hello\Nworld"


def test_layout_detects_unfittable_text_and_collision(tmp_path: Path) -> None:
    cue = CaptionCue(
        id="cue",
        text="W" * 100,
        timeline_range=tr(0, 500),
        position="center",
    )
    track = CaptionTrack(
        id="captions",
        items=[cue],
        collision_regions=[
            CaptionCollisionRegion(
                id="subject",
                timeline_range=tr(0, 1000),
                x=0.25,
                y=0.25,
                width=0.5,
                height=0.5,
                kind="subject",
            )
        ],
    )
    style = CaptionStyle(
        id="default",
        name="Default",
        min_font_size_px=24,
        max_font_size_px=24,
        max_chars_per_line=20,
    )
    result = VideoEngine(tmp_path).captions().validate_layout(track, [style], width=320, height=180)
    codes = {issue.code for issue in result.issues}
    assert "caption.fit_failed" in codes
    assert "caption.reading_speed" in codes
    assert "caption.collision" in codes
    assert not result.valid


def test_layout_uses_explicit_zero_coordinates_and_fits_overrides(tmp_path: Path) -> None:
    cue = CaptionCue(
        id="corner",
        text="Corner",
        timeline_range=tr(0, 1000),
        position="custom",
        position_x=0,
        position_y=0,
        style_overrides=CaptionStyleOverride(font_size_px=500),
    )
    result = (
        VideoEngine(tmp_path)
        .captions()
        .validate_layout(
            CaptionTrack(id="captions", items=[cue]),
            [CaptionStyle(id="default", name="Default")],
            width=320,
            height=180,
        )
    )
    assert result.fitted_font_sizes[cue.id] < 500
    assert "caption.safe_area" in {issue.code for issue in result.issues}
