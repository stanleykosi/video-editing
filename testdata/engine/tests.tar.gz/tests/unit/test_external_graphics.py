from __future__ import annotations

import json
from pathlib import Path

import pytest

from video_engine.cli.main import main
from video_engine.config import EngineConfig
from video_engine.core.time import FrameRate, RationalTime, TimeRange
from video_engine.graphics.models import (
    BlenderSceneProps,
    GraphicAsset,
    GraphicRenderer,
    HyperFramesCompositionProps,
)
from video_engine.graphics.registry import builtin_graphics_registry
from video_engine.graphics.service import GraphicsService
from video_engine.render.backends.blender import BlenderBackend
from video_engine.render.backends.hyperframes import HyperFramesBackend
from video_engine.render.backends.manim import ManimBackend
from video_engine.render.cache import sha256_file
from video_engine.render.nodes import ArtifactType, MotionGraphicNode


def test_external_components_are_typed_and_renderer_specific() -> None:
    registry = builtin_graphics_registry()
    assert registry.get("hyperframes_composition", "1.0.0").renderer is (
        GraphicRenderer.HYPERFRAMES
    )
    assert registry.get("manim_scene", "1.0.0").renderer is GraphicRenderer.MANIM
    assert registry.get("blender_scene", "1.0.0").renderer is GraphicRenderer.BLENDER
    with pytest.raises(ValueError, match="confined relative path"):
        HyperFramesCompositionProps(
            source_asset_id="source",
            asset_bindings={"../escape.png": "asset"},
        )


def test_external_executable_paths_materialize_from_project_root(tmp_path: Path) -> None:
    config = EngineConfig(
        manim_path="tools/manim/bin/manim",
        blender_path="tools/blender/blender",
    ).materialize(tmp_path)
    assert config.manim_path == str(tmp_path / "tools/manim/bin/manim")
    assert config.blender_path == str(tmp_path / "tools/blender/blender")
    assert EngineConfig(manim_path="manim").materialize(tmp_path).manim_path == "manim"


def test_graphics_service_builds_content_addressed_external_clip(tmp_path: Path) -> None:
    entry = tmp_path / "index.html"
    logo = tmp_path / "logo.png"
    entry.write_text("<html></html>", encoding="utf-8")
    logo.write_bytes(b"logo")
    prepared = GraphicsService().prepare_hyperframes(
        clip_id="graphic-1",
        timeline_range=TimeRange(
            start=RationalTime.zero(),
            duration=RationalTime(value=2, timescale=1),
        ),
        entry_path=entry,
        asset_bindings={"assets/logo.png": logo},
        variables={"headline": "Canonical"},
    )
    assert prepared.clip.generator_id == "hyperframes_composition"
    assert prepared.clip.properties["asset_bindings"] == {"assets/logo.png": "asset-000"}
    assert prepared.clip.properties["variables"] == {"headline": "Canonical"}
    assert len(prepared.media_references) == 2
    assert {reference.sha256 for reference in prepared.media_references} == {
        sha256_file(entry),
        sha256_file(logo),
    }


def test_graphics_prepare_cli_emits_machine_readable_bundle(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    script = tmp_path / "scene.py"
    output = tmp_path / "prepared.json"
    script.write_text("from manim import Scene\nclass Demo(Scene): pass\n", encoding="utf-8")
    assert (
        main(
            [
                "graphics",
                "prepare",
                "manim",
                str(script),
                "--clip-id",
                "technical-overlay",
                "--start",
                "3/2",
                "--duration",
                "2",
                "--scene",
                "Demo",
                "--output",
                str(output),
                "--json",
            ]
        )
        == 0
    )
    response = json.loads(capsys.readouterr().out)
    persisted = json.loads(output.read_text(encoding="utf-8"))
    assert response["renderer"] == "manim"
    assert persisted["clip"]["generator_id"] == "manim_scene"
    assert persisted["clip"]["timeline_range"] == {
        "start": {"value": 3, "timescale": 2},
        "duration": {"value": 2, "timescale": 1},
    }


def test_external_backends_only_accept_matching_renderer(tmp_path: Path) -> None:
    source = tmp_path / "source.bin"
    source.write_bytes(b"source")
    node = MotionGraphicNode(
        id="graphic",
        artifact_type=ArtifactType.VIDEO,
        component_id="manim_scene",
        component_version="1.0.0",
        component_digest="a" * 64,
        renderer=GraphicRenderer.MANIM,
        props={"source_asset_id": "source", "scene_name": "Scene"},
        assets=(
            GraphicAsset(
                id="source",
                source_path=source,
                sha256=sha256_file(source),
                media_type="data",
                staged_name="source.bin",
            ),
        ),
        duration=RationalTime(value=1, timescale=1),
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
        composition_duration_frames=24,
        render_duration_frames=24,
    )
    config = EngineConfig()
    assert ManimBackend(config, tmp_path).can_execute(node)
    assert not BlenderBackend(config, tmp_path).can_execute(node)
    assert not HyperFramesBackend(config, tmp_path).can_execute(node)


def test_blender_lowering_is_exact_and_contains_no_user_code() -> None:
    props = BlenderSceneProps(
        source_asset_id="source",
        camera_name="Camera A",
        render_engine="CYCLES",
        samples=32,
    )
    expression = BlenderBackend._configuration_expression(
        1080,
        1920,
        30_000,
        1001,
        12,
        42,
        Path("/tmp/frames/frame_"),
        props,
        True,
    )
    assert "s.render.resolution_x=1080" in expression
    assert "s.render.fps=30" in expression
    assert "s.render.fps_base=30030/30000" in expression
    assert "s.frame_start=12" in expression
    assert "s.frame_end=42" in expression
    assert "s.camera=bpy.data.objects['Camera A']" in expression
    assert "s.cycles.samples=32" in expression
