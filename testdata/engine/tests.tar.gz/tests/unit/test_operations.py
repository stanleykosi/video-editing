from __future__ import annotations

from fractions import Fraction
from typing import Any

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st
from pydantic import TypeAdapter, ValidationError

from video_engine.core.schema import (
    AudioClip,
    AudioRole,
    AudioTrack,
    CaptionCollisionRegion,
    CaptionTrack,
    Clip,
    Effect,
    EffectKind,
    Keyframe,
    Marker,
    MediaReference,
    Project,
    Retime,
    Sequence,
    SpeedRampPoint,
    Timeline,
    Transition,
    TransitionKind,
    VideoTrack,
)
from video_engine.core.time import RationalTime, TimeRange
from video_engine.core.validation import validate_project
from video_engine.errors import EngineError
from video_engine.operations.editor import TimelineEditor
from video_engine.operations.models import (
    AddCaptionCollisionRegionOperation,
    AddEffectOperation,
    AddKeyframeOperation,
    AddMarkerOperation,
    AddTransitionOperation,
    AppendOperation,
    AudioCrossfadeOperation,
    DisableOperation,
    DuplicateOperation,
    ExtractOperation,
    GroupOperation,
    InsertOperation,
    JCutOperation,
    LCutOperation,
    LiftOperation,
    LinkOperation,
    MoveOperation,
    NestOperation,
    OverwriteOperation,
    PatchEnvelope,
    RemoveCaptionCollisionRegionOperation,
    RemoveEffectOperation,
    RemoveKeyframeOperation,
    RemoveMarkerOperation,
    RemoveTransitionOperation,
    ReplaceOperation,
    RippleDeleteOperation,
    RippleTrimOperation,
    RollOperation,
    SlideOperation,
    SlipOperation,
    SplitOperation,
    TimelinePatch,
    TrimOperation,
    UngroupOperation,
    UnlinkOperation,
    UnnestOperation,
)

TIMESCALE = 24


def seconds(value: int) -> RationalTime:
    return RationalTime(value=value * TIMESCALE, timescale=TIMESCALE)


def time_range(start: int, duration: int) -> TimeRange:
    return TimeRange(start=seconds(start), duration=seconds(duration))


def video_clip(item_id: str, start: int, duration: int, source_start: int | None = None) -> Clip:
    return Clip(
        id=item_id,
        timeline_range=time_range(start, duration),
        source_range=time_range(source_start if source_start is not None else start, duration),
        media_reference_id="media",
    )


def audio_clip(
    item_id: str, start: int, duration: int, source_start: int | None = None
) -> AudioClip:
    return AudioClip(
        id=item_id,
        timeline_range=time_range(start, duration),
        source_range=time_range(source_start if source_start is not None else start, duration),
        media_reference_id="media",
        role=AudioRole.DIALOGUE,
    )


def project_with_tracks(*, second_video_track: bool = False, audio: bool = True) -> Project:
    tracks: list[Any] = [
        VideoTrack(
            id="v1",
            items=[
                video_clip("a", 0, 10),
                video_clip("b", 10, 10),
                video_clip("c", 20, 10),
            ],
        )
    ]
    if second_video_track:
        tracks.append(VideoTrack(id="v2"))
    if audio:
        tracks.append(
            AudioTrack(
                id="a1",
                role=AudioRole.DIALOGUE,
                items=[audio_clip("aa", 0, 10), audio_clip("ab", 10, 10)],
            )
        )
    return Project(
        id="project",
        name="Operations",
        media=[
            MediaReference(
                id="media",
                uri="file:///synthetic.mp4",
                available_range=time_range(0, 120),
            )
        ],
        sequences=[Sequence(id="main", name="Main", timeline=Timeline(tracks=tracks))],
        active_sequence_id="main",
    )


def track_items(editor: TimelineEditor, track_id: str) -> list[Any]:
    return next(
        track for track in editor.project.sequence().timeline.tracks if track.id == track_id
    ).items


def apply(editor: TimelineEditor, operation: Any, patch_id: str = "patch") -> None:
    editor.apply_operation(operation, patch_id=f"{patch_id}-{editor.project.revision}")


def without_revisions(project: Project) -> dict[str, Any]:
    data = project.model_dump(mode="json")
    data["revision"] = 0
    for sequence in data["sequences"]:
        sequence["revision"] = 0
    return data


def test_append_insert_overwrite_replace_and_split() -> None:
    editor = TimelineEditor(project_with_tracks())
    apply(editor, AppendOperation(track_id="v1", item=video_clip("d", 0, 5, 30)))
    assert track_items(editor, "v1")[-1].timeline_range == time_range(30, 5)

    apply(editor, InsertOperation(track_id="v1", at=seconds(10), item=video_clip("i", 0, 5, 40)))
    starts = {item.id: item.timeline_range.start for item in track_items(editor, "v1")}
    assert starts["i"] == seconds(10)
    assert starts["b"] == seconds(15)
    assert starts["c"] == seconds(25)

    fresh = TimelineEditor(project_with_tracks())
    apply(
        fresh,
        OverwriteOperation(track_id="v1", at=seconds(8), item=video_clip("o", 0, 4, 50)),
    )
    ranges = {item.id: item.timeline_range for item in track_items(fresh, "v1")}
    assert ranges["a"] == time_range(0, 8)
    assert ranges["o"] == time_range(8, 4)
    assert ranges["b"] == time_range(12, 8)

    apply(
        fresh,
        ReplaceOperation(
            track_id="v1",
            item_id="o",
            item=video_clip("replacement", 0, 1, 60),
        ),
    )
    replacement = next(item for item in track_items(fresh, "v1") if item.id == "replacement")
    assert replacement.timeline_range == time_range(8, 4)
    assert replacement.source_range == time_range(60, 4)

    split_editor = TimelineEditor(project_with_tracks())
    apply(
        split_editor,
        SplitOperation(
            track_id="v1",
            item_id="a",
            at=seconds(5),
            left_id="a-left",
            right_id="a-right",
        ),
    )
    split = {item.id: item for item in track_items(split_editor, "v1")}
    assert split["a-left"].source_range == time_range(0, 5)
    assert split["a-right"].source_range == time_range(5, 5)


def test_trim_ripple_trim_roll_slip_and_slide() -> None:
    trim_editor = TimelineEditor(project_with_tracks())
    apply(trim_editor, TrimOperation(track_id="v1", item_id="a", new_range=time_range(0, 8)))
    assert track_items(trim_editor, "v1")[0].timeline_range == time_range(0, 8)

    ripple = TimelineEditor(project_with_tracks())
    apply(
        ripple,
        RippleTrimOperation(track_id="v1", item_id="a", new_range=time_range(0, 8)),
    )
    assert [item.timeline_range.start for item in track_items(ripple, "v1")] == [
        seconds(0),
        seconds(8),
        seconds(18),
    ]

    roll = TimelineEditor(project_with_tracks())
    apply(
        roll,
        RollOperation(track_id="v1", left_item_id="a", right_item_id="b", new_cut=seconds(12)),
    )
    rolled = {item.id: item for item in track_items(roll, "v1")}
    assert rolled["a"].timeline_range == time_range(0, 12)
    assert rolled["b"].timeline_range == time_range(12, 8)
    assert rolled["b"].source_range.start == seconds(12)

    slip = TimelineEditor(project_with_tracks())
    apply(slip, SlipOperation(track_id="v1", item_id="b", source_offset=seconds(2)))
    slipped = next(item for item in track_items(slip, "v1") if item.id == "b")
    assert slipped.timeline_range == time_range(10, 10)
    assert slipped.source_range == time_range(12, 10)

    slide = TimelineEditor(project_with_tracks())
    apply(slide, SlideOperation(track_id="v1", item_id="b", offset=seconds(2)))
    slid = {item.id: item for item in track_items(slide, "v1")}
    assert slid["a"].timeline_range == time_range(0, 12)
    assert slid["b"].timeline_range == time_range(12, 10)
    assert slid["c"].timeline_range == time_range(22, 8)


@pytest.mark.parametrize(
    ("reverse", "expected_source_start"),
    [(False, 4), (True, 8)],
)
def test_trim_preserves_retime_mapping(reverse: bool, expected_source_start: int) -> None:
    project = project_with_tracks(audio=False)
    track = project.sequence().timeline.tracks[0]
    assert isinstance(track, VideoTrack)
    track.items = [
        Clip(
            id="retimed",
            timeline_range=time_range(0, 10),
            source_range=time_range(0, 20),
            media_reference_id="media",
            retime=Retime(rate="2", reverse=reverse),
        )
    ]
    editor = TimelineEditor(project)

    apply(
        editor,
        TrimOperation(track_id="v1", item_id="retimed", new_range=time_range(2, 4)),
    )

    item = track_items(editor, "v1")[0]
    assert isinstance(item, Clip)
    assert item.source_range == time_range(expected_source_start, 8)
    assert item.retime.rate.fraction == 2


def test_trim_and_split_preserve_exact_speed_ramp_windows() -> None:
    project = project_with_tracks(audio=False)
    track = project.sequence().timeline.tracks[0]
    assert isinstance(track, VideoTrack)
    ramp = Retime(
        speed_ramp=(
            SpeedRampPoint(time=seconds(0), rate=1),
            SpeedRampPoint(time=seconds(10), rate=2),
        )
    )
    track.items = [
        Clip(
            id="ramped",
            timeline_range=time_range(0, 10),
            source_range=time_range(0, 15),
            media_reference_id="media",
            retime=ramp,
        )
    ]
    editor = TimelineEditor(project)

    apply(
        editor,
        TrimOperation(track_id="v1", item_id="ramped", new_range=time_range(2, 6)),
    )
    trimmed = track_items(editor, "v1")[0]
    assert isinstance(trimmed, Clip)
    assert trimmed.source_range == TimeRange(
        start=RationalTime(value=11, timescale=5),
        duration=RationalTime(value=9, timescale=1),
    )
    assert [point.rate.fraction for point in trimmed.retime.speed_ramp] == [
        Fraction(6, 5),
        Fraction(9, 5),
    ]

    apply(
        editor,
        SplitOperation(
            track_id="v1",
            item_id="ramped",
            at=seconds(5),
            left_id="left",
            right_id="right",
        ),
    )
    left, right = track_items(editor, "v1")
    assert isinstance(left, Clip) and isinstance(right, Clip)
    assert left.source_range.duration == RationalTime(value=81, timescale=20)
    assert right.source_range.duration == RationalTime(value=99, timescale=20)
    assert left.retime.speed_ramp[-1].time == left.timeline_range.duration
    assert right.retime.speed_ramp[-1].time == right.timeline_range.duration


def test_trim_split_and_slip_preserve_materialized_freeze_source() -> None:
    project = project_with_tracks()
    track = project.sequence().timeline.tracks[0]
    assert isinstance(track, VideoTrack)
    clip = track.items[0]
    assert isinstance(clip, Clip)
    clip.effects.append(
        Effect(
            id="hold",
            kind=EffectKind.FREEZE,
            parameters={
                "frame_time": seconds(8).model_dump(mode="json"),
                "duration": seconds(10).model_dump(mode="json"),
            },
        )
    )
    editor = TimelineEditor(Project.model_validate(project.model_dump(mode="python")))

    apply(
        editor,
        TrimOperation(track_id="v1", item_id="a", new_range=time_range(2, 4)),
    )
    trimmed = track_items(editor, "v1")[0]
    assert isinstance(trimmed, Clip)
    assert trimmed.timeline_range == time_range(2, 4)
    assert trimmed.source_range == time_range(2, 4)
    assert trimmed.effects[0].parameters["duration"] == seconds(4).model_dump(mode="json")
    assert TimeRange.model_validate(trimmed.effects[0].parameters["source_range"]) == TimeRange(
        start=seconds(8),
        duration=RationalTime(value=1, timescale=24),
    )
    assert validate_project(editor.project).valid

    split_project = project_with_tracks()
    split_track = split_project.sequence().timeline.tracks[0]
    assert isinstance(split_track, VideoTrack)
    split_clip = split_track.items[0]
    assert isinstance(split_clip, Clip)
    split_clip.effects.append(clip.effects[0].model_copy(deep=True))
    split_editor = TimelineEditor(Project.model_validate(split_project.model_dump(mode="python")))
    apply(
        split_editor,
        SplitOperation(
            track_id="v1",
            item_id="a",
            at=seconds(5),
            left_id="freeze-left",
            right_id="freeze-right",
        ),
    )
    split_items = {item.id: item for item in track_items(split_editor, "v1")}
    for item_id in ("freeze-left", "freeze-right"):
        item = split_items[item_id]
        assert isinstance(item, Clip)
        assert RationalTime.model_validate(item.effects[0].parameters["duration"]) == seconds(5)
        assert TimeRange.model_validate(item.effects[0].parameters["source_range"]) == TimeRange(
            start=seconds(8),
            duration=RationalTime(value=1, timescale=24),
        )
    assert validate_project(split_editor.project).valid

    apply(
        split_editor,
        SlipOperation(
            track_id="v1",
            item_id="freeze-right",
            source_offset=seconds(1),
        ),
    )
    slipped = next(item for item in track_items(split_editor, "v1") if item.id == "freeze-right")
    assert isinstance(slipped, Clip)
    assert TimeRange.model_validate(slipped.effects[0].parameters["source_range"]) == TimeRange(
        start=seconds(9),
        duration=RationalTime(value=1, timescale=24),
    )
    assert validate_project(split_editor.project).valid


def test_speed_ramp_trim_then_extend_matches_direct_trim() -> None:
    def ramp_project() -> Project:
        project = project_with_tracks(audio=False)
        track = project.sequence().timeline.tracks[0]
        assert isinstance(track, VideoTrack)
        track.items = [
            Clip(
                id="ramped",
                timeline_range=time_range(0, 10),
                source_range=time_range(0, 15),
                media_reference_id="media",
                retime=Retime(
                    speed_ramp=(
                        SpeedRampPoint(time=seconds(0), rate=1),
                        SpeedRampPoint(time=seconds(10), rate=2),
                    )
                ),
            )
        ]
        return project

    direct = TimelineEditor(ramp_project())
    apply(
        direct,
        TrimOperation(track_id="v1", item_id="ramped", new_range=time_range(0, 8)),
    )
    sequential = TimelineEditor(ramp_project())
    apply(
        sequential,
        TrimOperation(track_id="v1", item_id="ramped", new_range=time_range(0, 5)),
    )
    apply(
        sequential,
        TrimOperation(track_id="v1", item_id="ramped", new_range=time_range(0, 8)),
    )

    direct_item = track_items(direct, "v1")[0]
    sequential_item = track_items(sequential, "v1")[0]
    assert isinstance(direct_item, Clip) and isinstance(sequential_item, Clip)
    assert sequential_item.source_range == direct_item.source_range
    assert sequential_item.retime.speed_ramp == direct_item.retime.speed_ramp
    assert sequential_item.retime.source_curve


@pytest.mark.parametrize("ramped", [False, True])
def test_replace_preserving_range_keeps_reverse_source_end(ramped: bool) -> None:
    project = project_with_tracks(audio=False)
    track = project.sequence().timeline.tracks[0]
    assert isinstance(track, VideoTrack)
    track.items = [video_clip("old", 0, 4)]
    retime = (
        Retime(
            reverse=True,
            speed_ramp=(
                SpeedRampPoint(time=seconds(0), rate=1),
                SpeedRampPoint(time=seconds(10), rate=2),
            ),
        )
        if ramped
        else Retime(rate=2, reverse=True)
    )
    replacement = Clip(
        id="replacement",
        timeline_range=time_range(0, 10),
        source_range=time_range(10, 15 if ramped else 20),
        media_reference_id="media",
        retime=retime,
    )
    editor = TimelineEditor(project)

    apply(
        editor,
        ReplaceOperation(track_id="v1", item_id="old", item=replacement),
    )

    item = track_items(editor, "v1")[0]
    assert isinstance(item, Clip)
    assert item.source_range.end == replacement.source_range.end
    expected_duration = RationalTime(value=24, timescale=5) if ramped else seconds(8)
    assert item.source_range.duration == expected_duration


def test_lift_extract_ripple_delete_move_and_duplicate() -> None:
    lift = TimelineEditor(project_with_tracks())
    apply(lift, LiftOperation(track_id="v1", item_id="b", gap_id="gap-b"))
    assert track_items(lift, "v1")[1].item_type == "gap"

    extract = TimelineEditor(project_with_tracks(audio=False))
    apply(extract, ExtractOperation(range=time_range(5, 10), track_ids=["v1"]))
    assert [(item.id, item.timeline_range) for item in track_items(extract, "v1")] == [
        ("a", time_range(0, 5)),
        ("b", time_range(5, 5)),
        ("c", time_range(10, 10)),
    ]

    ripple = TimelineEditor(project_with_tracks())
    apply(ripple, RippleDeleteOperation(track_id="v1", item_id="b"))
    assert [(item.id, item.timeline_range.start) for item in track_items(ripple, "v1")] == [
        ("a", seconds(0)),
        ("c", seconds(10)),
    ]

    move = TimelineEditor(project_with_tracks(second_video_track=True))
    apply(
        move,
        MoveOperation(
            source_track_id="v1",
            item_id="b",
            target_track_id="v2",
            target_start=seconds(5),
        ),
    )
    assert [item.id for item in track_items(move, "v1")] == ["a", "c"]
    assert track_items(move, "v2")[0].timeline_range == time_range(5, 10)

    apply(
        move,
        DuplicateOperation(
            source_track_id="v1",
            item_id="a",
            target_track_id="v2",
            target_start=seconds(20),
            new_item_id="a-copy",
        ),
    )
    assert [item.id for item in track_items(move, "v2")] == ["b", "a-copy"]


def test_effect_keyframe_marker_transition_enable_and_remove() -> None:
    editor = TimelineEditor(project_with_tracks())
    effect = Effect(id="opacity", kind=EffectKind.OPACITY, parameters={"value": 0.5})
    apply(editor, AddEffectOperation(item_id="a", effect=effect))
    apply(
        editor,
        AddKeyframeOperation(
            effect_id="opacity",
            keyframe=Keyframe(
                id="kf1", property_path="parameters.value", time=seconds(1), value=1.0
            ),
        ),
    )
    apply(editor, DisableOperation(target_type="effect", target_id="opacity"))
    clip = track_items(editor, "v1")[0]
    assert clip.effects[0].enabled is False
    assert clip.effects[0].keyframes[0].id == "kf1"

    apply(
        editor,
        AddMarkerOperation(
            target_type="item", target_id="a", marker=Marker(id="mark", time=seconds(2))
        ),
    )
    clip = track_items(editor, "v1")[0]
    assert clip.markers[0].id == "mark"

    transition = Transition(
        id="dissolve",
        kind=TransitionKind.DISSOLVE,
        from_item_id="a",
        to_item_id="b",
        duration=seconds(1),
    )
    apply(editor, AddTransitionOperation(track_id="v1", transition=transition))
    assert len(editor.project.sequence().timeline.tracks[0].transitions) == 1

    apply(editor, RemoveMarkerOperation(target_type="item", target_id="a", marker_id="mark"))
    apply(editor, RemoveKeyframeOperation(effect_id="opacity", keyframe_id="kf1"))
    apply(editor, RemoveEffectOperation(item_id="a", effect_id="opacity"))
    apply(editor, RemoveTransitionOperation(track_id="v1", transition_id="dissolve"))
    clip = track_items(editor, "v1")[0]
    assert clip.markers == []
    assert clip.effects == []
    assert editor.project.sequence().timeline.tracks[0].transitions == []


def test_caption_collision_region_operations_are_atomic_and_undoable() -> None:
    project = project_with_tracks()
    project.sequence().timeline.tracks.append(CaptionTrack(id="captions"))
    original = project.model_copy(deep=True)
    editor = TimelineEditor(project)
    region = CaptionCollisionRegion(
        id="tracked-face",
        timeline_range=time_range(2, 3),
        x=0.1,
        y=0.2,
        width=0.3,
        height=0.4,
        kind="face",
    )

    result = editor.apply_patch(
        TimelinePatch(
            patch_id="caption-collision",
            expected_project_revision=1,
            operations=[AddCaptionCollisionRegionOperation(track_id="captions", region=region)],
        )
    )
    track = next(
        track for track in editor.project.sequence().timeline.tracks if track.id == "captions"
    )
    assert isinstance(track, CaptionTrack)
    assert track.collision_regions == [region]
    assert result.audit_entries[0].operation.value == "add_caption_collision_region"

    editor.undo()
    assert without_revisions(editor.project) == without_revisions(original)
    editor.redo()
    apply(
        editor,
        RemoveCaptionCollisionRegionOperation(track_id="captions", region_id="tracked-face"),
    )
    track = next(
        track for track in editor.project.sequence().timeline.tracks if track.id == "captions"
    )
    assert isinstance(track, CaptionTrack)
    assert track.collision_regions == []

    parsed = TypeAdapter(TimelinePatch).validate_python(
        {
            "patch_id": "json-caption-region",
            "operations": [
                {
                    "operation": "add_caption_collision_region",
                    "track_id": "captions",
                    "region": region.model_dump(mode="json"),
                }
            ],
        }
    )
    assert isinstance(parsed.operations[0], AddCaptionCollisionRegionOperation)


def test_link_group_nest_and_unnest() -> None:
    editor = TimelineEditor(project_with_tracks())
    apply(editor, LinkOperation(group_id="linked", item_ids=["a", "aa"]))
    assert editor.project.sequence().timeline.link_groups[0].item_ids == ["a", "aa"]
    apply(editor, UnlinkOperation(item_ids=["aa"]))
    assert editor.project.sequence().timeline.link_groups == []

    apply(editor, GroupOperation(group_id="scene", item_ids=["a", "b"]))
    assert all(item.group_id == "scene" for item in track_items(editor, "v1")[:2])
    apply(editor, UngroupOperation(group_id="scene"))
    assert all(item.group_id is None for item in track_items(editor, "v1"))

    apply(
        editor,
        NestOperation(
            item_ids=["a", "b"],
            target_track_id="v1",
            sequence_id="nested",
            sequence_name="Nested",
            nested_clip_id="nested-clip",
        ),
    )
    assert [sequence.id for sequence in editor.project.sequences] == ["main", "nested"]
    assert [item.id for item in track_items(editor, "v1")] == ["nested-clip", "c"]
    nested_items = editor.project.sequence("nested").timeline.tracks[0].items
    assert [item.timeline_range.start for item in nested_items] == [seconds(0), seconds(10)]

    apply(
        editor,
        UnnestOperation(
            track_id="v1",
            nested_clip_id="nested-clip",
            remove_sequence=True,
        ),
    )
    assert [sequence.id for sequence in editor.project.sequences] == ["main"]
    assert [item.id for item in track_items(editor, "v1")] == ["a", "b", "c"]


def test_j_cut_l_cut_and_audio_crossfade() -> None:
    jcut = TimelineEditor(project_with_tracks())
    apply(
        jcut,
        JCutOperation(audio_track_id="a1", audio_item_id="ab", extension=seconds(2)),
    )
    extended = next(item for item in track_items(jcut, "a1") if item.id == "ab")
    assert extended.timeline_range == time_range(8, 12)
    assert extended.source_range == time_range(8, 12)

    single_audio = project_with_tracks()
    single_audio.sequence().timeline.tracks[-1].items = [audio_clip("only", 0, 10)]
    lcut = TimelineEditor(single_audio)
    apply(
        lcut,
        LCutOperation(audio_track_id="a1", audio_item_id="only", extension=seconds(2)),
    )
    assert track_items(lcut, "a1")[0].timeline_range == time_range(0, 12)

    crossfade = TimelineEditor(project_with_tracks())
    apply(
        crossfade,
        AudioCrossfadeOperation(
            track_id="a1",
            left_item_id="aa",
            right_item_id="ab",
            duration=seconds(1),
            transition_id="audio-xf",
        ),
    )
    audio_track = crossfade.project.sequence().timeline.tracks[-1]
    assert audio_track.transitions[0].kind is TransitionKind.AUDIO_CROSSFADE


def test_patch_is_atomic_revision_checked_and_undoable() -> None:
    original = project_with_tracks()
    editor = TimelineEditor(original)
    patch = TimelinePatch(
        patch_id="multi",
        expected_project_revision=1,
        operations=[
            RippleDeleteOperation(track_id="v1", item_id="b"),
            AppendOperation(track_id="v1", item=video_clip("d", 0, 5, 40)),
        ],
    )
    result = editor.apply_patch(patch)
    after = editor.project.model_copy(deep=True)
    assert result.project_revision == 2
    assert len(result.audit_entries) == 2
    assert result.inverse_patch.expected_project_revision == 2

    editor.undo()
    assert without_revisions(editor.project) == without_revisions(original)
    editor.redo()
    assert without_revisions(editor.project) == without_revisions(after)

    inverse_editor = TimelineEditor(after)
    inverse_editor.apply_patch(result.inverse_patch)
    assert without_revisions(inverse_editor.project) == without_revisions(original)

    before_failure = editor.project.model_copy(deep=True)
    with pytest.raises(EngineError, match="revision conflict"):
        editor.apply_patch(
            TimelinePatch(
                patch_id="stale",
                expected_project_revision=1,
                operations=[RippleDeleteOperation(track_id="v1", item_id="a")],
            )
        )
    assert editor.project == before_failure


def test_json_patch_is_strict_and_public_restore_is_reserved() -> None:
    payload = {
        "patch_id": "json",
        "expected_project_revision": 1,
        "operations": [{"operation": "disable", "target_type": "item", "target_id": "a"}],
    }
    patch = TypeAdapter(TimelinePatch).validate_python(payload)
    assert patch.operations[0].operation.value == "disable"
    bad = {**payload, "operations": [{**payload["operations"][0], "unknown": True}]}
    with pytest.raises(ValidationError, match="extra_forbidden"):
        TypeAdapter(TimelinePatch).validate_python(bad)

    editor = TimelineEditor(project_with_tracks())
    result = editor.apply_patch(patch)
    with pytest.raises(ValidationError, match="reserved"):
        PatchEnvelope(patch=result.inverse_patch)


def test_effect_and_keyframe_operations_respect_track_and_item_locks() -> None:
    project = project_with_tracks()
    track = project.sequence().timeline.tracks[0]
    item = track.items[0]
    effect = Effect(id="position", kind=EffectKind.POSITION, parameters={"x": 0, "y": 0})
    track.locked = True
    with pytest.raises(EngineError, match="track is locked"):
        apply(
            TimelineEditor(project),
            AddEffectOperation(item_id=item.id, effect=effect),
            patch_id="locked-effect",
        )

    track.locked = False
    item.effects = [effect]
    item.locked = True
    with pytest.raises(EngineError, match="item is locked"):
        apply(
            TimelineEditor(project),
            AddKeyframeOperation(
                effect_id=effect.id,
                keyframe=Keyframe(id="x", property_path="x", time=seconds(0), value=10),
            ),
            patch_id="locked-keyframe",
        )


@settings(max_examples=20, deadline=None)
@given(st.lists(st.integers(min_value=1, max_value=8), min_size=1, max_size=12))
def test_append_property_preserves_duration_and_invariants(durations: list[int]) -> None:
    project = project_with_tracks(audio=False)
    project.sequence().timeline.tracks[0].items = []
    editor = TimelineEditor(project)
    for index, duration in enumerate(durations):
        apply(
            editor,
            AppendOperation(
                track_id="v1",
                item=video_clip(f"clip-{index}", 0, duration, index * 8),
            ),
            patch_id=f"append-{index}",
        )
    assert editor.project.sequence().timeline.duration == seconds(sum(durations))
    assert validate_project(editor.project).valid
