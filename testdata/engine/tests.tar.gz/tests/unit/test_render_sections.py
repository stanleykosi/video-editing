from __future__ import annotations

from video_engine.core.schema import Gap, Marker, Sequence, Timeline, VideoTrack
from video_engine.core.time import AudioSampleTime, FrameRate, RationalTime, RoundingMode, TimeRange
from video_engine.render.sections import SectionPlanner, chapter_range


def rt(value: int, timescale: int = 24) -> RationalTime:
    return RationalTime(value=value, timescale=timescale)


def sequence_with_duration(duration: RationalTime, *markers: Marker) -> Sequence:
    return Sequence(
        id="sequence",
        name="Sequence",
        timeline=Timeline(
            tracks=[
                VideoTrack(
                    id="video",
                    items=[
                        Gap(
                            id="duration",
                            timeline_range=TimeRange(start=RationalTime.zero(), duration=duration),
                        )
                    ],
                )
            ],
            markers=list(markers),
        ),
    )


def test_section_planner_splits_by_maximum_duration() -> None:
    sequence = sequence_with_duration(rt(120))
    plan = SectionPlanner(
        frame_rate=FrameRate(numerator=24),
        audio_sample_rate=48_000,
        max_duration=RationalTime(value=2, timescale=1),
    ).plan(
        sequence,
        TimeRange(start=rt(0), duration=rt(120)),
    )

    assert [section.timeline_range.duration for section in plan.sections] == [
        rt(48),
        rt(48),
        rt(24),
    ]
    assert [section.id for section in plan.sections] == [
        "section-f0-f48",
        "section-f48-f96",
        "section-f96-f120",
    ]


def test_fractional_rate_internal_boundaries_are_sample_aligned() -> None:
    rate = FrameRate.fps_29_97()
    duration = rate.frames_to_time(90)
    sequence = sequence_with_duration(duration)
    plan = SectionPlanner(
        frame_rate=rate,
        audio_sample_rate=48_000,
        max_duration=RationalTime(value=1, timescale=1),
    ).plan(sequence, TimeRange(start=RationalTime.zero(), duration=duration))

    internal = [section.timeline_range.end for section in plan.sections[:-1]]
    assert [rate.time_to_frames(time) for time in internal] == [25, 50, 75]
    for time in internal:
        AudioSampleTime.from_time(time, 48_000, RoundingMode.EXACT)


def test_chapter_boundaries_and_direct_chapter_ranges_are_stable() -> None:
    opening = Marker(
        id="opening",
        time=rt(0),
        name="Opening",
        extensions={"kind": "chapter"},
    )
    body = Marker(
        id="body",
        time=rt(48),
        name="Body",
        extensions={"chapter": True},
    )
    sequence = sequence_with_duration(rt(120), opening, body)
    plan = SectionPlanner(
        frame_rate=FrameRate(numerator=24),
        audio_sample_rate=48_000,
        max_duration=None,
    ).plan(sequence, TimeRange(start=rt(0), duration=rt(120)))

    assert [section.chapter_id for section in plan.sections] == ["opening", "body"]
    assert chapter_range(sequence, "opening") == TimeRange(start=rt(0), duration=rt(48))
    assert chapter_range(sequence, "body") == TimeRange(start=rt(48), duration=rt(72))
