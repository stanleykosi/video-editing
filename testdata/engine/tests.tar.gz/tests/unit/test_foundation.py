from __future__ import annotations

import json
from pathlib import Path

import pytest

import video_engine.api as public_api
import video_engine.audio as public_audio
from video_engine.api.engine import VideoEngine
from video_engine.cli.main import main
from video_engine.config import EngineConfig
from video_engine.core.schema import Gap, VideoTrack
from video_engine.core.time import RationalTime, TimeRange
from video_engine.process import CommandRunner
from video_engine.temp import TemporaryWorkspace


def test_public_api_exports_stable_engine_timeline_and_result_contracts() -> None:
    assert {
        "VideoEngine",
        "Project",
        "Timeline",
        "RationalTime",
        "AudioSampleTime",
        "TimelinePatch",
        "PatchEnvelope",
        "RenderRequest",
        "RenderResult",
        "QCRequest",
        "QCResult",
        "InspectionRequest",
        "InspectionResult",
        "MigrationResult",
        "ExportResult",
        "MediaRecord",
    } <= set(public_api.__all__)
    assert {
        "AudioTrack",
        "AudioClip",
        "AudioBus",
        "AudioRole",
        "AudioSampleTime",
        "Effect",
        "EffectKind",
        "LoudnessProfile",
    } <= set(public_audio.__all__)


def test_command_runner_captures_structured_result() -> None:
    result = CommandRunner().run(["/bin/sh", "-c", "printf hello"])
    assert result.return_code == 0
    assert result.stdout == "hello"
    assert result.duration_seconds >= 0
    assert result.to_dict()["command"] == ["/bin/sh", "-c", "printf hello"]


def test_temporary_workspace_cleans_up(tmp_path: Path) -> None:
    with TemporaryWorkspace(root=tmp_path) as workspace:
        marker = workspace / "marker"
        marker.write_text("present", encoding="utf-8")
        assert marker.exists()
    assert not workspace.exists()


def test_config_rejects_unknown_values(tmp_path: Path) -> None:
    path = tmp_path / "config.json"
    path.write_text('{"unknown": true}', encoding="utf-8")
    with pytest.raises(Exception, match="Extra inputs"):
        EngineConfig.from_file(path)


def test_config_bounds_and_loads_remotion_browser_timeout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    with pytest.raises(ValueError, match="greater than or equal to 7"):
        EngineConfig(remotion_browser_timeout_seconds=6)
    with pytest.raises(ValueError, match="less than or equal to 300"):
        EngineConfig(remotion_browser_timeout_seconds=301)

    monkeypatch.setenv("VIDEO_ENGINE_REMOTION_BROWSER_TIMEOUT", "180")
    assert EngineConfig.from_environment().remotion_browser_timeout_seconds == 180


def test_cli_init_and_validate_json(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["init", str(tmp_path), "--name", "CLI Project", "--json"]) == 0
    created = json.loads(capsys.readouterr().out)
    assert created["ok"] is True
    project_path = Path(created["project"])
    assert project_path.exists()

    assert main(["project", "validate", str(project_path), "--json"]) == 0
    validated = json.loads(capsys.readouterr().out)
    assert validated["ok"] is True
    assert validated["issues"] == []


def test_cli_usage_errors_are_machine_readable_when_json_is_requested(
    capsys: pytest.CaptureFixture[str],
) -> None:
    assert main(["render", "preview", "--json"]) == 2
    payload = json.loads(capsys.readouterr().out)
    assert payload["error"]["code"] == "configuration_error"
    assert payload["error"]["message"] == "invalid command-line arguments"
    assert "required" in payload["error"]["context"]["detail"]


def test_doctor_reports_missing_remotion_without_crashing(tmp_path: Path) -> None:
    report = VideoEngine(
        tmp_path,
        EngineConfig(remotion_root=tmp_path / "missing-remotion"),
    ).doctor()
    remotion = next(check for check in report.checks if check.name == "Remotion")
    assert remotion.required is True
    assert remotion.status.value == "fail"
    assert report.healthy is False


def test_cli_applies_and_inspects_strict_timeline_patch(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    engine = VideoEngine(tmp_path)
    project = engine.create_project("Patch Project")
    project.sequence().timeline.tracks.append(VideoTrack(id="v1"))
    project_path = engine.save_project(project)
    patch_path = tmp_path / "patch.json"
    patch_path.write_text(
        json.dumps(
            {
                "patch_id": "append-gap",
                "expected_project_revision": 1,
                "operations": [
                    {
                        "operation": "append",
                        "track_id": "v1",
                        "item": Gap(
                            id="gap-1",
                            timeline_range=TimeRange(
                                start=RationalTime.zero(),
                                duration=RationalTime(value=48, timescale=24),
                            ),
                        ).model_dump(mode="json"),
                    }
                ],
            }
        ),
        encoding="utf-8",
    )

    assert main(["timeline", "apply-patch", str(project_path), str(patch_path), "--json"]) == 0
    applied = json.loads(capsys.readouterr().out)
    assert applied["project_revision"] == 2
    assert applied["audit_entries"][0]["operation"] == "append"
    assert applied["inverse_patch"]["operations"][0]["operation"] == "restore_project"

    assert main(["timeline", "inspect", str(project_path), "--json"]) == 0
    inspected = json.loads(capsys.readouterr().out)
    assert inspected["sequence"]["duration"] == {"value": 2, "timescale": 1}
    assert inspected["sequence"]["tracks"][0]["items"][0]["id"] == "gap-1"
