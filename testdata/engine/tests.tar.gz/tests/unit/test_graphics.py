from __future__ import annotations

from pathlib import Path

import pytest

from video_engine.core.time import FrameRate, RationalTime
from video_engine.errors import EngineError
from video_engine.graphics.models import GraphicAsset, GraphicBoundsPolicy, TextCardProps
from video_engine.graphics.registry import (
    ComponentDefinition,
    GraphicsRegistry,
    builtin_graphics_registry,
)
from video_engine.render.cache import cache_key_for_node, sha256_file
from video_engine.render.nodes import ArtifactType, MotionGraphicNode


def graphic_node(
    *,
    digest: str = "a" * 64,
    assets: tuple[GraphicAsset, ...] = (),
) -> MotionGraphicNode:
    return MotionGraphicNode(
        id="graphic",
        artifact_type=ArtifactType.VIDEO,
        component_id="title_card",
        component_version="1.0.0",
        component_digest=digest,
        props={"title": "Engine"},
        assets=assets,
        duration=RationalTime(value=1, timescale=1),
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
        composition_duration_frames=48,
        render_start_frame=12,
        render_duration_frames=24,
    )


def cache_key(node: MotionGraphicNode) -> str:
    return cache_key_for_node(
        node,
        (),
        backend_name="remotion",
        backend_version="1.0.0",
        tool_fingerprint="node=1;browser=1",
    )


def test_builtin_registry_is_versioned_and_rejects_unknown_props() -> None:
    registry = builtin_graphics_registry()
    assert registry.ids == (
        "call_to_action",
        "chapter_card",
        "comparison",
        "countdown",
        "device_mockup",
        "diagram_overlay",
        "emphasis_text",
        "end_card",
        "hook_card",
        "kinetic_caption",
        "logo_reveal",
        "lower_third",
        "number_card",
        "picture_in_picture",
        "product_feature",
        "progress_accent",
        "quote_card",
        "screenshot_frame",
        "split_screen",
        "stat_card",
        "title_card",
    )
    definition, props = registry.validate_props("title_card", "1.0.0", {"title": "A typed title"})
    assert len(definition.source_digest) == 64
    assert props["title"] == "A typed title"
    assert props["alignment"] == "left"
    assert definition.bounds_policy is GraphicBoundsPolicy.FULL_FRAME
    assert registry.get("kinetic_caption", "1.0.0").bounds_policy is GraphicBoundsPolicy.SAFE_AREA
    assert registry.get("progress_accent", "1.0.0").bounds_policy is GraphicBoundsPolicy.EDGE_ACCENT
    with pytest.raises(EngineError, match="props are invalid"):
        registry.validate_props("title_card", "1.0.0", {"title": "Title", "raw_html": "<script />"})
    with pytest.raises(EngineError, match="version is unavailable"):
        registry.validate_props("title_card", "2.0.0", {"title": "Title"})


def test_registry_retains_multiple_component_versions() -> None:
    registry = GraphicsRegistry()
    registry.register(
        ComponentDefinition(
            id="title_card",
            version="1.0.0",
            props_model=TextCardProps,
            source_digest="a" * 64,
        )
    )
    registry.register(
        ComponentDefinition(
            id="title_card",
            version="2.0.0",
            props_model=TextCardProps,
            source_digest="b" * 64,
        )
    )
    assert registry.get("title_card", "1.0.0").source_digest == "a" * 64
    assert registry.get("title_card", "2.0.0").source_digest == "b" * 64


def test_registry_requires_declared_content_addressed_assets() -> None:
    registry = builtin_graphics_registry()
    _, props = registry.validate_props("picture_in_picture", "1.0.0", {"asset_id": "camera-a"})
    with pytest.raises(EngineError, match="undeclared assets") as raised:
        registry.validate_asset_references("picture_in_picture", props, set())
    assert raised.value.context["asset_ids"] == ["camera-a"]
    registry.validate_asset_references("picture_in_picture", props, {"camera-a"})


def test_graphic_cache_tracks_component_source_and_asset_bytes(tmp_path: Path) -> None:
    source = tmp_path / "frame.png"
    source.write_bytes(b"first")
    asset = GraphicAsset(
        id="frame",
        source_path=source,
        sha256=sha256_file(source),
        media_type="image",
        staged_name="frame.png",
    )
    initial = graphic_node(assets=(asset,))
    initial_key = cache_key(initial)
    assert initial_key != cache_key(graphic_node(digest="b" * 64, assets=(asset,)))

    source.write_bytes(b"second")
    changed_asset = asset.model_copy(update={"sha256": sha256_file(source)})
    assert initial_key != cache_key(graphic_node(assets=(changed_asset,)))


def test_graphic_cache_tracks_asset_media_semantics(tmp_path: Path) -> None:
    source = tmp_path / "payload.bin"
    source.write_bytes(b"same bytes")
    checksum = sha256_file(source)
    image = GraphicAsset(
        id="asset",
        source_path=source,
        sha256=checksum,
        media_type="image",
        staged_name="asset.png",
    )
    video = image.model_copy(update={"media_type": "video", "staged_name": "asset.mp4"})
    assert cache_key(graphic_node(assets=(image,))) != cache_key(graphic_node(assets=(video,)))


def test_graphic_range_cannot_exceed_composition() -> None:
    with pytest.raises(ValueError, match="range exceeds"):
        MotionGraphicNode.model_validate(
            {
                **graphic_node().model_dump(mode="json"),
                "render_start_frame": 40,
                "render_duration_frames": 24,
            }
        )


def test_graphic_duration_must_equal_rendered_frames() -> None:
    with pytest.raises(ValueError, match="duration must equal"):
        MotionGraphicNode.model_validate(
            {
                **graphic_node().model_dump(mode="json"),
                "frame_rate": {"numerator": 30, "denominator": 1},
            }
        )
