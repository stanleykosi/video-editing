from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
from pathlib import Path
from threading import Barrier

import pytest

from video_engine.api.engine import VideoEngine
from video_engine.core.schema import Clip, MediaReference, VideoTrack
from video_engine.core.time import FrameRate, RationalTime, TimeRange
from video_engine.errors import EngineError, ErrorCode
from video_engine.render.backends.base import BackendExecution, RenderBackend
from video_engine.render.backends.registry import BackendPlan, BackendRegistry
from video_engine.render.checkpoints import (
    CheckpointAttempt,
    RenderCheckpointStore,
    checkpoint_identity,
)
from video_engine.render.models import RenderArtifact, RenderRequest
from video_engine.render.nodes import ALL_NODE_KINDS, RenderNode
from video_engine.render.service import RenderService


def rt(value: int, timescale: int = 24) -> RationalTime:
    return RationalTime(value=value, timescale=timescale)


class DeterministicBackend(RenderBackend):
    name = "checkpoint-test"
    version = "1.0.0"
    capabilities = ALL_NODE_KINDS

    def __init__(self, *, fail_node_id: str | None = None) -> None:
        self.fail_node_id = fail_node_id
        self.failed = False

    @property
    def tool_fingerprint(self) -> str:
        return "checkpoint-test-tool-v1"

    def output_suffix(self, node: RenderNode) -> str:
        return ".bin"

    def execute(
        self,
        node: RenderNode,
        inputs: tuple[RenderArtifact, ...],
        output_path: Path,
        work_dir: Path,
    ) -> BackendExecution:
        del inputs, work_dir
        if node.id == self.fail_node_id and not self.failed:
            self.failed = True
            raise EngineError(
                ErrorCode.RENDER_FAILED,
                "intentional checkpoint recovery failure",
                context={"node_id": node.id},
            )
        output_path.write_bytes(f"artifact:{node.node_type.value}".encode())
        return BackendExecution(path=output_path)


def build_checkpoint_project(tmp_path: Path):  # type: ignore[no-untyped-def]
    source = tmp_path / "source.bin"
    source.write_bytes(b"synthetic source identity")
    engine = VideoEngine(tmp_path)
    engine.config.max_workers = 1
    project = engine.create_project(
        "Checkpoint",
        width=64,
        height=64,
        frame_rate=FrameRate(numerator=24),
    )
    project.media.append(
        MediaReference(
            id="media",
            uri=str(source),
            available_range=TimeRange(start=rt(0), duration=rt(36)),
        )
    )
    project.sequence().timeline.tracks = [
        VideoTrack(
            id="video",
            items=[
                Clip(
                    id="clip",
                    media_reference_id="media",
                    timeline_range=TimeRange(start=rt(0), duration=rt(36)),
                    source_range=TimeRange(start=rt(0), duration=rt(36)),
                    source_audio_enabled=False,
                )
            ],
        )
    ]
    return engine, project


def test_checkpoint_store_marks_interrupted_attempts_and_resets_without_resume(
    tmp_path: Path,
) -> None:
    engine, project = build_checkpoint_project(tmp_path)
    request = RenderRequest(output_path=tmp_path / "output.mp4", section_duration=rt(12))
    compiled = engine.renderer(project).compile(request)
    backend = DeterministicBackend()
    plan = BackendPlan(by_node_id={node.id: backend for node in compiled.graph.nodes})
    identity, signature = checkpoint_identity(
        compiled,
        plan,
        request,
        project_id=project.id,
        project_revision=project.revision,
    )
    store = RenderCheckpointStore(tmp_path / "checkpoints")

    first, _ = store.begin(
        identity=identity,
        signature=signature,
        compiled=compiled,
        project_id=project.id,
        project_revision=project.revision,
        resume=True,
    )
    resumed, _ = store.begin(
        identity=identity,
        signature=signature,
        compiled=compiled,
        project_id=project.id,
        project_revision=project.revision,
        resume=True,
    )
    fresh, _ = store.begin(
        identity=identity,
        signature=signature,
        compiled=compiled,
        project_id=project.id,
        project_revision=project.revision,
        resume=False,
    )

    assert first.attempts[0].status == "running"
    assert [attempt.status for attempt in resumed.attempts] == ["running", "running"]
    assert len(fresh.attempts) == 1


@pytest.mark.integration
def test_failed_render_resumes_from_cache_with_attempt_history(tmp_path: Path) -> None:
    engine, project = build_checkpoint_project(tmp_path)
    request = RenderRequest(
        output_path=tmp_path / "failed.bin",
        section_duration=rt(12),
        backend="checkpoint-test",
        use_cache=False,
    )
    preview_backend = DeterministicBackend()
    preview_registry = BackendRegistry()
    preview_registry.register(preview_backend)
    preview_service = RenderService(project, tmp_path, engine.config, registry=preview_registry)
    compiled = preview_service.compile(request)
    failing_node = compiled.section_outputs[1].video_node_id
    preview_backend.fail_node_id = failing_node

    with pytest.raises(EngineError, match="render graph execution failed"):
        preview_service.render(request)

    recovery_registry = BackendRegistry()
    recovery_registry.register(DeterministicBackend())
    recovery_service = RenderService(project, tmp_path, engine.config, registry=recovery_registry)
    recovered = recovery_service.render(
        request.model_copy(update={"output_path": tmp_path / "recovered.bin"})
    )
    checkpoint_metadata = recovered.manifest.metadata["checkpoint"]
    assert isinstance(checkpoint_metadata, dict)
    checkpoint = RenderCheckpointStore(
        engine.config.materialize(tmp_path).cache_dir / "render-checkpoints"
    ).load(str(checkpoint_metadata["identity"]))

    assert checkpoint is not None
    assert checkpoint.status == "succeeded"
    assert [attempt.status for attempt in checkpoint.attempts] == ["failed", "succeeded"]
    assert checkpoint.output_sha256 == recovered.manifest.output_sha256
    assert recovered.cache_hits > 0
    assert recovered.output_path.read_bytes().startswith(b"artifact:mux")


def test_checkpoint_identity_ignores_destination_path(tmp_path: Path) -> None:
    engine, project = build_checkpoint_project(tmp_path)
    first_request = RenderRequest(output_path=tmp_path / "one.mp4")
    second_request = first_request.model_copy(update={"output_path": tmp_path / "two.mp4"})
    compiled = engine.renderer(project).compile(first_request)
    backend = DeterministicBackend()
    plan = BackendPlan(by_node_id={node.id: backend for node in compiled.graph.nodes})

    first_identity, _ = checkpoint_identity(
        compiled,
        plan,
        first_request,
        project_id=project.id,
        project_revision=project.revision,
    )
    second_identity, _ = checkpoint_identity(
        compiled,
        plan,
        second_request,
        project_id=project.id,
        project_revision=project.revision,
    )

    assert first_identity == second_identity


def test_public_partial_render_executes_only_target_closure(tmp_path: Path) -> None:
    engine, project = build_checkpoint_project(tmp_path)
    request = RenderRequest(
        output_path=tmp_path / "unused.bin",
        section_duration=rt(12),
        backend="checkpoint-test",
    )
    registry = BackendRegistry()
    registry.register(DeterministicBackend())
    service = RenderService(project, tmp_path, engine.config, registry=registry)
    compiled = service.compile(request)
    target = compiled.section_outputs[1].video_node_id

    first = service.execute_partial(request, (target,))
    second = service.execute_partial(request, (target,))

    assert first.target_node_ids == (target,)
    assert first.artifacts[target].path.is_file()
    assert first.artifacts[target].path.is_relative_to(
        engine.config.materialize(tmp_path).cache_dir
    )
    assert all(record.node_id != compiled.graph.outputs["main"] for record in first.records)
    assert second.cache_hits > 0


def test_checkpoint_identity_is_scoped_to_project_revision(tmp_path: Path) -> None:
    engine, project = build_checkpoint_project(tmp_path)
    request = RenderRequest(output_path=tmp_path / "scope.mp4")
    compiled = engine.renderer(project).compile(request)
    backend = DeterministicBackend()
    plan = BackendPlan(by_node_id={node.id: backend for node in compiled.graph.nodes})

    first, _ = checkpoint_identity(
        compiled,
        plan,
        request,
        project_id=project.id,
        project_revision=project.revision,
    )
    other_project, _ = checkpoint_identity(
        compiled,
        plan,
        request,
        project_id="another-project",
        project_revision=project.revision,
    )
    other_revision, _ = checkpoint_identity(
        compiled,
        plan,
        request,
        project_id=project.id,
        project_revision=project.revision + 1,
    )

    assert len({first, other_project, other_revision}) == 3


def test_corrupt_checkpoint_is_quarantined_and_recreated(tmp_path: Path) -> None:
    engine, project = build_checkpoint_project(tmp_path)
    request = RenderRequest(output_path=tmp_path / "corrupt.mp4")
    compiled = engine.renderer(project).compile(request)
    backend = DeterministicBackend()
    plan = BackendPlan(by_node_id={node.id: backend for node in compiled.graph.nodes})
    identity, signature = checkpoint_identity(
        compiled,
        plan,
        request,
        project_id=project.id,
        project_revision=project.revision,
    )
    store = RenderCheckpointStore(tmp_path / "checkpoints")
    checkpoint, _ = store.begin(
        identity=identity,
        signature=signature,
        compiled=compiled,
        project_id=project.id,
        project_revision=project.revision,
        resume=True,
    )
    store.path_for(identity).write_text("{not-json", encoding="utf-8")

    assert store.load(identity) is None
    assert list(store.path_for(identity).parent.glob(f"{identity}.corrupt-*.json"))
    recreated, _ = store.begin(
        identity=identity,
        signature=signature,
        compiled=compiled,
        project_id=project.id,
        project_revision=project.revision,
        resume=True,
    )
    assert recreated.identity == checkpoint.identity
    assert len(recreated.attempts) == 1


def test_new_attempt_clears_prior_output_evidence(tmp_path: Path) -> None:
    engine, project = build_checkpoint_project(tmp_path)
    request = RenderRequest(output_path=tmp_path / "evidence.mp4")
    compiled = engine.renderer(project).compile(request)
    backend = DeterministicBackend()
    plan = BackendPlan(by_node_id={node.id: backend for node in compiled.graph.nodes})
    identity, signature = checkpoint_identity(
        compiled,
        plan,
        request,
        project_id=project.id,
        project_revision=project.revision,
    )
    store = RenderCheckpointStore(tmp_path / "checkpoints")
    checkpoint, attempt_id = store.begin(
        identity=identity,
        signature=signature,
        compiled=compiled,
        project_id=project.id,
        project_revision=project.revision,
        resume=True,
    )
    completed = store.finish(
        checkpoint,
        attempt_id,
        compiled,
        (),
        status="succeeded",
        output_sha256="a" * 64,
    )
    assert completed.output_sha256 == "a" * 64

    running, _ = store.begin(
        identity=identity,
        signature=signature,
        compiled=compiled,
        project_id=project.id,
        project_revision=project.revision,
        resume=True,
    )
    assert running.output_sha256 is None


def test_historical_success_does_not_mask_sequential_failure(tmp_path: Path) -> None:
    engine, project = build_checkpoint_project(tmp_path)
    request = RenderRequest(output_path=tmp_path / "sequential.mp4")
    compiled = engine.renderer(project).compile(request)
    backend = DeterministicBackend()
    plan = BackendPlan(by_node_id={node.id: backend for node in compiled.graph.nodes})
    identity, signature = checkpoint_identity(
        compiled,
        plan,
        request,
        project_id=project.id,
        project_revision=project.revision,
    )
    store = RenderCheckpointStore(tmp_path / "checkpoints")
    first, first_id = store.begin(
        identity=identity,
        signature=signature,
        compiled=compiled,
        project_id=project.id,
        project_revision=project.revision,
        resume=True,
    )
    store.finish(
        first,
        first_id,
        compiled,
        (),
        status="succeeded",
        output_sha256="c" * 64,
    )
    second, second_id = store.begin(
        identity=identity,
        signature=signature,
        compiled=compiled,
        project_id=project.id,
        project_revision=project.revision,
        resume=True,
    )
    failed = store.finish(second, second_id, compiled, (), status="failed")

    assert failed.status == "failed"
    assert failed.output_sha256 is None
    assert [attempt.status for attempt in failed.attempts] == [
        "succeeded",
        "failed",
    ]


def test_checkpoint_owner_identity_detects_pid_reuse() -> None:
    attempt = CheckpointAttempt(
        id="reused",
        status="running",
        started_at=datetime.now(UTC),
        owner_pid=os.getpid(),
        owner_identity="different-boot-and-start",
    )
    assert RenderCheckpointStore._owner_is_alive(attempt) is False


def test_concurrent_attempt_finishes_preserve_history_and_success(
    tmp_path: Path,
) -> None:
    engine, project = build_checkpoint_project(tmp_path)
    request = RenderRequest(output_path=tmp_path / "concurrent.mp4")
    compiled = engine.renderer(project).compile(request)
    backend = DeterministicBackend()
    plan = BackendPlan(by_node_id={node.id: backend for node in compiled.graph.nodes})
    identity, signature = checkpoint_identity(
        compiled,
        plan,
        request,
        project_id=project.id,
        project_revision=project.revision,
    )
    store = RenderCheckpointStore(tmp_path / "checkpoints")
    first, first_id = store.begin(
        identity=identity,
        signature=signature,
        compiled=compiled,
        project_id=project.id,
        project_revision=project.revision,
        resume=True,
    )
    second, second_id = store.begin(
        identity=identity,
        signature=signature,
        compiled=compiled,
        project_id=project.id,
        project_revision=project.revision,
        resume=True,
    )
    barrier = Barrier(2)

    def finish(checkpoint, attempt_id: str, status: str) -> None:  # type: ignore[no-untyped-def]
        barrier.wait()
        store.finish(
            checkpoint,
            attempt_id,
            compiled,
            (),
            status=status,  # type: ignore[arg-type]
            output_sha256="b" * 64 if status == "succeeded" else None,
        )

    with ThreadPoolExecutor(max_workers=2) as pool:
        completed = [
            pool.submit(finish, first, first_id, "succeeded"),
            pool.submit(finish, second, second_id, "failed"),
        ]
        for future in completed:
            future.result()

    final = store.load(identity)
    assert final is not None
    assert final.status == "succeeded"
    assert final.output_sha256 == "b" * 64
    assert {attempt.status for attempt in final.attempts} == {"succeeded", "failed"}
