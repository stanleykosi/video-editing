from __future__ import annotations

import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from video_engine.api.engine import VideoEngine
from video_engine.core.schema import Gap, VideoTrack
from video_engine.core.time import RationalTime, TimeRange
from video_engine.qc.models import (
    QCCheckResult,
    QCCheckStatus,
    QCFinding,
    QCOverallStatus,
    QCRequest,
    QCScope,
    QCSeverity,
    overall_status,
)


def test_output_scopes_require_an_output_path() -> None:
    with pytest.raises(ValidationError, match="require output_path"):
        QCRequest(scopes=(QCScope.VIDEO,))


def test_overall_status_prioritizes_failure_then_incomplete_then_warning() -> None:
    warning_finding = QCFinding(
        code="qc.warning",
        scope=QCScope.TIMELINE,
        severity=QCSeverity.WARNING,
        blocking=False,
        message="warning",
    )
    warning = QCCheckResult(
        code="timeline.warning",
        scope=QCScope.TIMELINE,
        status=QCCheckStatus.WARNING,
        summary="warning",
        duration_seconds=0,
        findings=(warning_finding,),
    )
    skipped = QCCheckResult(
        code="video.skipped",
        scope=QCScope.VIDEO,
        status=QCCheckStatus.SKIPPED,
        summary="missing evidence",
        duration_seconds=0,
        error={"code": "missing", "message": "missing evidence"},
    )
    failure_finding = QCFinding(
        code="qc.failure",
        scope=QCScope.DELIVERY,
        severity=QCSeverity.ERROR,
        blocking=True,
        message="failure",
    )
    failed = QCCheckResult(
        code="delivery.failure",
        scope=QCScope.DELIVERY,
        status=QCCheckStatus.FAILED,
        summary="failure",
        duration_seconds=0,
        findings=(failure_finding,),
    )

    assert overall_status([warning], fail_on_warnings=False) is (
        QCOverallStatus.PASSED_WITH_WARNINGS
    )
    assert overall_status([warning], fail_on_warnings=True) is QCOverallStatus.FAILED
    assert overall_status([warning, skipped], fail_on_warnings=False) is (
        QCOverallStatus.INCOMPLETE
    )
    assert overall_status([warning, skipped, failed], fail_on_warnings=False) is (
        QCOverallStatus.FAILED
    )


def test_timeline_qc_treats_explicit_gap_as_intent_and_writes_matching_reports(
    tmp_path: Path,
) -> None:
    engine = VideoEngine(tmp_path)
    project = engine.create_project("Explicit Gap", width=320, height=180)
    project.sequence().timeline.tracks.append(
        VideoTrack(
            id="v1",
            items=[
                Gap(
                    id="intentional-gap",
                    timeline_range=TimeRange(
                        start=RationalTime.zero(),
                        duration=RationalTime(value=1, timescale=1),
                    ),
                )
            ],
        )
    )
    result = engine.qc(project).run(
        QCRequest(scopes=(QCScope.TIMELINE,), report_dir=tmp_path / "qc")
    )

    assert result.report.status is QCOverallStatus.PASSED
    assert not any(
        finding.code == "timeline.implicit_visual_gap" for finding in result.report.findings
    )
    payload = json.loads(result.json_path.read_text(encoding="utf-8"))
    assert payload == result.report.model_dump(mode="json")
    markdown = result.markdown_path.read_text(encoding="utf-8")
    assert "# Technical QC Report" in markdown
    assert "timeline.render_capabilities" in markdown


def test_timeline_qc_reports_only_uncovered_interval_as_implicit_gap(tmp_path: Path) -> None:
    engine = VideoEngine(tmp_path)
    project = engine.create_project("Implicit Gap", width=320, height=180)
    project.sequence().timeline.tracks.append(
        VideoTrack(
            id="v1",
            items=[
                Gap(
                    id="late-explicit-gap",
                    timeline_range=TimeRange(
                        start=RationalTime(value=1, timescale=2),
                        duration=RationalTime(value=1, timescale=2),
                    ),
                )
            ],
        )
    )
    report = (
        engine.qc(project)
        .run(QCRequest(scopes=(QCScope.TIMELINE,), report_dir=tmp_path / "qc"))
        .report
    )

    gap = next(
        finding for finding in report.findings if finding.code == "timeline.implicit_visual_gap"
    )
    assert gap.blocking is False
    assert gap.measurements[0].value == 0.0
    assert gap.measurements[1].value == 0.5
    assert report.status is QCOverallStatus.PASSED_WITH_WARNINGS
