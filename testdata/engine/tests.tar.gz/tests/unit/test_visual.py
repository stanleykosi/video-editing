from __future__ import annotations

from fractions import Fraction

import pytest

from video_engine.core.schema import (
    CaptionTrack,
    Clip,
    EffectKind,
    GeneratorClip,
    GraphicsTrack,
    Interpolation,
    MediaReference,
    Project,
    ProjectSettings,
    Retime,
    Sequence,
    SpeedRampPoint,
    StreamSummary,
    Timeline,
    VideoTrack,
)
from video_engine.core.time import FrameRate, RationalRate, RationalTime, TimeRange
from video_engine.errors import EngineError
from video_engine.operations.editor import TimelineEditor
from video_engine.operations.models import (
    AddCaptionCollisionRegionOperation,
    AddEffectOperation,
)
from video_engine.visual.models import (
    MultiSubjectFallback,
    NormalizedBox,
    ReframeMode,
    ReframeSettings,
    TrackingBinding,
    TrackingGeometry,
    TrackingObservation,
    TrackingRequest,
    TrackingResult,
)
from video_engine.visual.service import VisualService


def rt(value: int, timescale: int = 24) -> RationalTime:
    return RationalTime(value=value, timescale=timescale)


def request(*observations: TrackingObservation) -> TrackingRequest:
    return TrackingRequest(
        id="manual",
        media_reference_id="media",
        source_range=TimeRange(start=rt(0), duration=rt(48)),
        sample_interval=rt(12),
        manual_observations=observations,
    )


def observation(
    subject_id: str,
    time: int,
    *,
    x: float,
    y: float = 0.25,
    width: float = 0.2,
    height: float = 0.5,
    confidence: float = 1,
) -> TrackingObservation:
    return TrackingObservation(
        time=rt(time),
        subject_id=subject_id,
        confidence=confidence,
        box=NormalizedBox(x=x, y=y, width=width, height=height),
        manual=True,
    )


def test_manual_tracking_is_ordered_and_rejects_empty_requests() -> None:
    service = VisualService()
    result = service.track(
        request(
            observation("subject", 24, x=0.7),
            observation("subject", 0, x=0.1),
        )
    )
    assert [item.time for item in result.observations] == [rt(0), rt(24)]
    assert all(item.manual for item in result.observations)
    with pytest.raises(EngineError, match="at least one observation"):
        service.track(request())


def test_reframe_planner_preserves_output_aspect_and_smooths_motion() -> None:
    service = VisualService()
    result = service.track(
        request(
            observation("subject", 0, x=0.05),
            observation("subject", 24, x=0.75),
        )
    )
    plan = service.plan_reframe(
        result,
        source_width=1920,
        source_height=1080,
        output_width=1080,
        output_height=1920,
        settings=ReframeSettings(smoothing=0.5),
    )
    expected_normalized_aspect = Fraction(1080, 1920) / Fraction(1920, 1080)
    for keyframe in plan.keyframes:
        assert keyframe.crop.width / keyframe.crop.height == pytest.approx(
            float(expected_normalized_aspect)
        )
    assert plan.keyframes[0].crop.center.x < plan.keyframes[1].crop.center.x
    assert plan.keyframes[1].crop.center.x < 0.85


def test_reframe_planner_reports_split_screen_fallback() -> None:
    service = VisualService()
    result = service.track(
        request(
            observation("left", 0, x=0.0, width=0.1),
            observation("right", 0, x=0.9, width=0.1),
        )
    )
    plan = service.plan_reframe(
        result,
        source_width=1920,
        source_height=1080,
        output_width=1080,
        output_height=1920,
        settings=ReframeSettings(
            multi_subject_fallback=MultiSubjectFallback.SPLIT_SCREEN,
            multi_subject_max_span=0.75,
        ),
    )
    assert plan.decisions[0].mode == "split_screen"
    assert {panel.subject_id for panel in plan.split_screen_panels} == {"left", "right"}

    clip = Clip(
        id="source",
        media_reference_id="media",
        timeline_range=TimeRange(start=rt(0), duration=rt(48)),
        source_range=TimeRange(start=rt(0), duration=rt(48)),
    )
    tracks = service.split_screen_tracks(plan, clip)
    assert len(tracks) == 2
    panel_clips = [track.items[0] for track in tracks]
    assert sum(item.source_audio_enabled for item in panel_clips) == 1
    reframe_parameters = [
        next(effect for effect in item.effects if effect.kind is EffectKind.REFRAME).parameters
        for item in panel_clips
    ]
    assert all(parameters["target_width"] == 540 for parameters in reframe_parameters)
    assert all(parameters["target_height"] == 1920 for parameters in reframe_parameters)


@pytest.mark.parametrize(
    ("fallback", "expected_decision", "expected_fit"),
    [
        (MultiSubjectFallback.CONTAIN, "contain", "contain"),
        (MultiSubjectFallback.CENTER, "center", "cover"),
    ],
)
def test_multi_subject_non_split_fallbacks_reach_canonical_effect(
    fallback: MultiSubjectFallback,
    expected_decision: str,
    expected_fit: str,
) -> None:
    service = VisualService()
    result = service.track(
        request(
            observation("left", 0, x=0.0, width=0.1),
            observation("right", 0, x=0.9, width=0.1),
        )
    )
    plan = service.plan_reframe(
        result,
        source_width=1920,
        source_height=1080,
        output_width=1080,
        output_height=1920,
        settings=ReframeSettings(
            multi_subject_fallback=fallback,
            multi_subject_max_span=0.75,
        ),
    )

    effect = service.reframe_effect(plan)

    assert plan.decisions[0].mode == expected_decision
    assert effect.parameters["fit"] == expected_fit
    if fallback is MultiSubjectFallback.CONTAIN:
        assert effect.keyframes == []


def test_reframe_plan_converts_to_canonical_effect_keyframes() -> None:
    service = VisualService()
    result = service.track(
        request(
            observation("subject", 0, x=0.0, width=0.2),
            observation("subject", 24, x=0.8, width=0.2),
        )
    )
    plan = service.plan_reframe(
        result,
        source_width=320,
        source_height=180,
        output_width=180,
        output_height=180,
        settings=ReframeSettings(smoothing=0),
    )
    effect = service.reframe_effect(plan)
    assert effect.kind is EffectKind.REFRAME
    assert {keyframe.property_path for keyframe in effect.keyframes} == {
        "focus_x",
        "focus_y",
        "zoom",
    }
    assert effect.extensions["tracking_result_id"] == result.id


@pytest.mark.parametrize("mode", [ReframeMode.CONTAIN, ReframeMode.STRETCH])
def test_non_cover_reframe_effect_does_not_emit_cover_only_automation(
    mode: ReframeMode,
) -> None:
    service = VisualService()
    result = service.track(request(observation("subject", 0, x=0.1)))
    plan = service.plan_reframe(
        result,
        source_width=320,
        source_height=180,
        output_width=180,
        output_height=180,
        settings=ReframeSettings(mode=mode),
    )

    effect = service.reframe_effect(plan)

    assert effect.parameters["fit"] == mode.value
    assert effect.parameters["zoom"] == 1
    assert effect.keyframes == []


@pytest.mark.parametrize("reverse", [False, True])
def test_reframe_effect_maps_source_times_through_clip_retime(reverse: bool) -> None:
    service = VisualService()
    tracking_request = TrackingRequest(
        id="trimmed",
        media_reference_id="media",
        source_range=TimeRange(start=rt(24), duration=rt(48)),
        sample_interval=rt(24),
        manual_observations=(
            observation("subject", 24, x=0.0),
            observation("subject", 72, x=0.8),
        ),
    )
    plan = service.plan_reframe(
        service.track(tracking_request),
        source_width=320,
        source_height=180,
        output_width=180,
        output_height=180,
        settings=ReframeSettings(smoothing=0),
    )
    clip = Clip(
        id="trimmed-clip",
        media_reference_id="media",
        timeline_range=TimeRange(start=rt(0), duration=rt(24)),
        source_range=TimeRange(start=rt(24), duration=rt(48)),
        source_audio_enabled=False,
        retime=Retime(rate=RationalRate(numerator=2), reverse=reverse),
    )

    effect = service.reframe_effect(plan, clip=clip)

    focus_x = [
        (keyframe.time, keyframe.value)
        for keyframe in effect.keyframes
        if keyframe.property_path == "focus_x"
    ]
    assert [time for time, _ in focus_x] == [rt(0), rt(24)]
    first_value = focus_x[0][1]
    second_value = focus_x[1][1]
    assert isinstance(first_value, (int, float))
    assert isinstance(second_value, (int, float))
    if reverse:
        assert first_value > second_value
    else:
        assert first_value < second_value


def binding_project(retime: Retime | None = None) -> tuple[Project, Clip]:
    retime = retime or Retime()
    duration = rt(48)
    source_duration = retime.source_offset_at(duration)
    clip = Clip(
        id="source",
        media_reference_id="media",
        timeline_range=TimeRange(start=rt(24), duration=duration),
        source_range=TimeRange(start=rt(240), duration=source_duration),
        source_audio_enabled=False,
        retime=retime,
    )
    project = Project(
        id="tracking-project",
        name="Tracking bindings",
        media=[
            MediaReference(
                id="media",
                uri="file:///synthetic.mp4",
                available_range=TimeRange(start=rt(0), duration=rt(1000)),
                streams=[
                    StreamSummary(
                        index=0,
                        codec_type="video",
                        width=320,
                        height=180,
                    )
                ],
            )
        ],
        settings=ProjectSettings(width=180, height=180, frame_rate=FrameRate(numerator=24)),
        sequences=[
            Sequence(
                id="main",
                name="Main",
                timeline=Timeline(
                    tracks=[
                        VideoTrack(id="v1", items=[clip]),
                        CaptionTrack(id="captions"),
                        GraphicsTrack(
                            id="graphics",
                            items=[
                                GeneratorClip(
                                    id="graphic",
                                    generator_id="solid_color",
                                    timeline_range=clip.timeline_range,
                                )
                            ],
                        ),
                    ]
                ),
            )
        ],
        active_sequence_id="main",
    )
    return project, clip


def binding_result(clip: Clip) -> TrackingResult:
    offsets = (RationalTime.zero(), clip.retime.source_offset_at(rt(24)))
    observations = tuple(
        TrackingObservation(
            time=(
                clip.source_range.end - offset
                if clip.retime.reverse
                else clip.source_range.start + offset
            ),
            subject_id="person",
            confidence=0.95,
            box=NormalizedBox(x=0.2 + index * 0.2, y=0.2, width=0.2, height=0.4),
            manual=True,
        )
        for index, offset in enumerate(offsets)
    )
    ordered = tuple(sorted(observations, key=lambda item: item.time))
    return TrackingResult(
        id="tracking-result",
        request_id="request",
        media_reference_id="media",
        backend="manual",
        backend_version="1.0.0",
        source_range=clip.source_range,
        observations=ordered,
    )


def binding(driver: str, *, subject_id: str | None = "person") -> TrackingBinding:
    kwargs: dict[str, object] = {}
    if driver == "caption_exclusion":
        kwargs["target_track_id"] = "captions"
        kwargs["interpolation"] = "hold"
    elif driver == "graphic_attachment":
        kwargs["target_item_id"] = "graphic"
    else:
        kwargs["target_item_id"] = "source"
    if driver == "blur":
        kwargs["blur_region"] = "inside"
    return TrackingBinding(
        id=f"binding-{driver}",
        tracking_result_id="tracking-result",
        source_item_id="source",
        driver=driver,  # type: ignore[arg-type]
        geometry=TrackingGeometry(
            source_width=320,
            source_height=180,
            canvas_width=180,
            canvas_height=180,
        ),
        timeline_frame_rate=FrameRate(numerator=24),
        subject_id=subject_id,
        **kwargs,  # type: ignore[arg-type]
    )


@pytest.mark.parametrize(
    ("driver", "effect_kind"),
    [
        ("crop", EffectKind.REFRAME),
        ("position", EffectKind.POSITION),
        ("graphic_attachment", EffectKind.POSITION),
        ("mask", EffectKind.MASK),
        ("blur", EffectKind.BACKGROUND_BLUR),
    ],
)
def test_tracking_bindings_materialize_effect_patches_and_apply(
    driver: str, effect_kind: EffectKind
) -> None:
    project, clip = binding_project()
    application = VisualService().materialize_binding(
        project, binding_result(clip), binding(driver)
    )

    assert application.observation_count == 2
    assert len(application.patch.operations) == 1
    assert isinstance(application.patch.operations[0], AddEffectOperation)
    assert [item.frame_number for item in application.evidence] == [24, 48]
    assert application.patch.metadata["mapping_evidence"]
    editor = TimelineEditor(project)
    result = editor.apply_patch(application.patch)
    target_id = "graphic" if driver == "graphic_attachment" else "source"
    edited_item = next(
        item
        for track in editor.project.sequence().timeline.tracks
        for item in track.items
        if item.id == target_id
    )
    assert edited_item.effects[0].kind is effect_kind
    assert {keyframe.time for keyframe in edited_item.effects[0].keyframes} == {
        rt(0),
        rt(24),
    }
    editor.apply_patch(result.inverse_patch)
    restored = next(
        item
        for track in editor.project.sequence().timeline.tracks
        for item in track.items
        if item.id == target_id
    )
    assert restored.effects == []


def test_tracking_crop_focus_uses_render_crop_overflow_coordinates() -> None:
    project, clip = binding_project()
    application = VisualService().materialize_binding(
        project, binding_result(clip), binding("crop")
    )
    operation = application.patch.operations[0]
    assert isinstance(operation, AddEffectOperation)
    parameters = operation.effect.parameters
    assert parameters["zoom"] == pytest.approx(2.5)
    assert parameters["focus_x"] == pytest.approx(150 / 620)
    assert parameters["focus_y"] == pytest.approx(1 / 3)


def test_caption_exclusion_binding_adds_timed_collision_regions() -> None:
    project, clip = binding_project()
    application = VisualService().materialize_binding(
        project, binding_result(clip), binding("caption_exclusion")
    )

    assert len(application.patch.operations) == 2
    assert all(
        isinstance(operation, AddCaptionCollisionRegionOperation)
        for operation in application.patch.operations
    )
    editor = TimelineEditor(project)
    editor.apply_patch(application.patch)
    track = editor.project.sequence().timeline.tracks[1]
    assert isinstance(track, CaptionTrack)
    assert [region.timeline_range for region in track.collision_regions] == [
        TimeRange(start=rt(24), duration=rt(24)),
        TimeRange(start=rt(48), duration=rt(24)),
    ]


@pytest.mark.parametrize(
    "retime",
    [
        Retime(rate=RationalRate(numerator=2)),
        Retime(rate=RationalRate(numerator=2), reverse=True),
        Retime(
            speed_ramp=(
                SpeedRampPoint(time=rt(0), rate=RationalRate(numerator=1)),
                SpeedRampPoint(time=rt(48), rate=RationalRate(numerator=2)),
            )
        ),
    ],
)
def test_tracking_mapping_is_frame_quantized_for_constant_reverse_and_ramp(
    retime: Retime,
) -> None:
    project, clip = binding_project(retime)
    application = VisualService().materialize_binding(
        project, binding_result(clip), binding("position")
    )

    assert [item.timeline_time for item in application.evidence] == [rt(24), rt(48)]
    assert all(item.source_mapping_error == RationalTime.zero() for item in application.evidence)


def test_tracking_binding_requires_explicit_subject_when_result_is_ambiguous() -> None:
    project, clip = binding_project()
    result = binding_result(clip)
    second = result.observations[0].model_copy(update={"subject_id": "other"})
    result = result.model_copy(
        update={
            "observations": tuple(
                sorted((*result.observations, second), key=lambda item: item.time)
            )
        }
    )

    with pytest.raises(EngineError, match="subject is ambiguous"):
        VisualService().materialize_binding(project, result, binding("position", subject_id=None))


def test_tracking_binding_rejects_geometry_drift_and_unowned_confidence_gaps() -> None:
    project, clip = binding_project()
    result = binding_result(clip)
    wrong_geometry = binding("position").model_copy(
        update={
            "geometry": TrackingGeometry(
                source_width=320,
                source_height=180,
                canvas_width=181,
                canvas_height=180,
            )
        }
    )
    with pytest.raises(EngineError, match="canvas geometry"):
        VisualService().materialize_binding(project, result, wrong_geometry)

    low_confidence = TrackingObservation(
        time=clip.source_range.start + rt(12),
        subject_id="person",
        confidence=0.1,
        box=NormalizedBox(x=0.3, y=0.2, width=0.2, height=0.4),
        manual=False,
    )
    result = result.model_copy(
        update={
            "observations": tuple(
                sorted((*result.observations, low_confidence), key=lambda item: item.time)
            )
        }
    )
    with pytest.raises(EngineError, match="confidence or sampling gap"):
        VisualService().materialize_binding(project, result, binding("position"))

    hold_binding = binding("position").model_copy(update={"missing_policy": "hold"})
    application = VisualService().materialize_binding(project, result, hold_binding)
    operation = application.patch.operations[0]
    assert isinstance(operation, AddEffectOperation)
    assert {keyframe.interpolation for keyframe in operation.effect.keyframes} == {
        Interpolation.HOLD
    }


def test_tracking_binding_synthesizes_target_start_between_observations() -> None:
    project, clip = binding_project()
    graphic = project.sequence().timeline.tracks[2].items[0]
    graphic.timeline_range = TimeRange(start=rt(36), duration=rt(24))
    application = VisualService().materialize_binding(
        project,
        binding_result(clip),
        binding("graphic_attachment"),
    )

    assert application.evidence[0].timeline_time == rt(36)
    assert application.evidence[0].target_time == RationalTime.zero()
    operation = application.patch.operations[0]
    assert isinstance(operation, AddEffectOperation)
    first_x = next(
        keyframe.value
        for keyframe in operation.effect.keyframes
        if keyframe.property_path == "x" and keyframe.time == RationalTime.zero()
    )
    assert isinstance(first_x, (int, float))
    assert first_x < 0
