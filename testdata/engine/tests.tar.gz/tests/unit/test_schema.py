import json
from fractions import Fraction
from pathlib import Path

import pytest
from pydantic import ValidationError

from video_engine.api.engine import VideoEngine
from video_engine.core.schema import (
    AudioBus,
    AudioClip,
    AudioTrack,
    CaptionCue,
    CaptionTrack,
    CaptionWord,
    Clip,
    ColorSpace,
    DeliveryProfile,
    FrameRate,
    MediaReference,
    NestedSequenceClip,
    Project,
    Retime,
    Sequence,
    SequenceSnapshot,
    SpeedRampPoint,
    Timeline,
    VideoTrack,
)
from video_engine.core.time import RationalTime, TimeRange
from video_engine.core.validation import validate_project


def rt(value: int, timescale: int = 24) -> RationalTime:
    return RationalTime(value=value, timescale=timescale)


def tr(start: int, duration: int, timescale: int = 24) -> TimeRange:
    return TimeRange(start=rt(start, timescale), duration=rt(duration, timescale))


def media() -> MediaReference:
    return MediaReference(id="m1", uri="file:///source.mp4", available_range=tr(0, 240))


def test_unknown_project_values_are_rejected() -> None:
    with pytest.raises(ValidationError, match="extra_forbidden"):
        Project.model_validate(
            {
                "id": "p1",
                "name": "Strict",
                "sequences": [{"id": "s1", "name": "Main", "timeline": {}}],
                "active_sequence_id": "s1",
                "surprise": True,
            }
        )


def test_project_rejects_missing_media_reference() -> None:
    clip = Clip(
        id="c1", timeline_range=tr(0, 24), source_range=tr(0, 24), media_reference_id="missing"
    )
    with pytest.raises(ValidationError, match="missing media"):
        Project(
            id="p1",
            name="Broken",
            sequences=[
                Sequence(
                    id="s1",
                    name="Main",
                    timeline=Timeline(tracks=[VideoTrack(id="v1", items=[clip])]),
                )
            ],
            active_sequence_id="s1",
        )


def test_retime_requires_exact_source_duration() -> None:
    clip = Clip(
        id="fast",
        timeline_range=tr(0, 24),
        source_range=tr(48, 48),
        media_reference_id="m1",
        retime=Retime(rate="2"),
    )
    assert clip.retime.rate.fraction == 2
    with pytest.raises(ValidationError, match="source duration"):
        Clip(
            id="invalid-fast",
            timeline_range=tr(0, 24),
            source_range=tr(48, 24),
            media_reference_id="m1",
            retime=Retime(rate="2"),
        )


def test_timeline_validator_finds_overlap_and_keyframe_boundaries() -> None:
    first = Clip(id="c1", timeline_range=tr(0, 30), source_range=tr(0, 30), media_reference_id="m1")
    second = Clip(
        id="c2", timeline_range=tr(24, 24), source_range=tr(30, 24), media_reference_id="m1"
    )
    project = Project(
        id="p1",
        name="Overlap",
        media=[media()],
        sequences=[
            Sequence(
                id="s1",
                name="Main",
                timeline=Timeline(tracks=[VideoTrack(id="v1", items=[first, second])]),
            )
        ],
        active_sequence_id="s1",
    )
    report = validate_project(project)
    assert not report.valid
    assert [issue.code for issue in report.issues] == ["timeline.track_overlap"]


def test_caption_words_must_fit_the_cue() -> None:
    with pytest.raises(ValidationError, match="caption word timing"):
        CaptionCue(
            id="cue1",
            timeline_range=tr(24, 24),
            text="hello",
            words=[CaptionWord(text="hello", range=tr(23, 3))],
        )


def test_nested_sequence_cycle_is_reported() -> None:
    nested_a = NestedSequenceClip(
        id="na",
        timeline_range=tr(0, 24),
        source_range=tr(0, 24),
        sequence_id="b",
    )
    nested_b = NestedSequenceClip(
        id="nb",
        timeline_range=tr(0, 24),
        source_range=tr(0, 24),
        sequence_id="a",
    )
    project = Project(
        id="p1",
        name="Cycle",
        sequences=[
            Sequence(
                id="a", name="A", timeline=Timeline(tracks=[VideoTrack(id="va", items=[nested_a])])
            ),
            Sequence(
                id="b", name="B", timeline=Timeline(tracks=[VideoTrack(id="vb", items=[nested_b])])
            ),
        ],
        active_sequence_id="a",
    )
    report = validate_project(project)
    assert not report.valid
    assert any(issue.code == "project.nested_sequence_cycle" for issue in report.issues)


def test_multitrack_project_round_trips_strictly(tmp_path: Path) -> None:
    engine = VideoEngine(tmp_path)
    project = engine.create_project(
        "Multitrack",
        width=1080,
        height=1920,
        frame_rate=FrameRate(numerator=30_000, denominator=1001),
    )
    project.media.append(media())
    timeline = project.sequence().timeline
    timeline.tracks.extend(
        [
            VideoTrack(
                id="v1",
                items=[
                    Clip(
                        id="vclip",
                        timeline_range=tr(0, 48),
                        source_range=tr(0, 48),
                        media_reference_id="m1",
                    )
                ],
            ),
            AudioTrack(
                id="a1",
                items=[
                    AudioClip(
                        id="aclip",
                        timeline_range=tr(0, 48),
                        source_range=tr(0, 48),
                        media_reference_id="m1",
                    )
                ],
            ),
            CaptionTrack(
                id="c1",
                items=[CaptionCue(id="cue", timeline_range=tr(0, 24), text="Canonical caption")],
            ),
        ]
    )
    path = engine.save_project(project)
    loaded, migrations = engine.load_project(path)
    assert migrations == []
    assert loaded == project
    assert loaded.settings.frame_rate == FrameRate.fps_29_97()


def test_audio_buses_must_route_to_master() -> None:
    with pytest.raises(ValidationError, match="does not route to the master"):
        Timeline(
            audio_buses=[
                AudioBus(id="master", name="Master"),
                AudioBus(id="orphan", name="Orphan"),
            ]
        )


def test_audio_channel_maps_and_delivery_layouts_are_strict() -> None:
    with pytest.raises(ValidationError, match="channel_map"):
        AudioClip(
            id="bad-map",
            media_reference_id="m1",
            timeline_range=tr(0, 24),
            source_range=tr(0, 24),
            channel_map=[-1],
        )
    with pytest.raises(ValidationError, match="audio_channels"):
        DeliveryProfile(
            id="mono",
            name="Mono",
            width=320,
            height=180,
            frame_rate=FrameRate(numerator=24),
            audio_channels=2,
            audio_channel_layout="mono",
        )
    with pytest.raises(ValidationError, match="10-bit"):
        DeliveryProfile(
            id="hlg",
            name="HLG",
            width=320,
            height=180,
            frame_rate=FrameRate(numerator=24),
            output_color_space=ColorSpace.HLG,
            pixel_format="yuv420p",
        )


def test_project_resolves_immutable_historical_sequence_revision() -> None:
    child_v1 = Sequence(
        id="child",
        name="Child",
        revision=1,
        timeline=Timeline(
            tracks=[
                VideoTrack(
                    id="child-video",
                    items=[
                        Clip(
                            id="v1-clip",
                            media_reference_id="m1",
                            timeline_range=tr(0, 24),
                            source_range=tr(0, 24),
                        )
                    ],
                )
            ]
        ),
    )
    child_v2 = child_v1.model_copy(deep=True)
    child_v2.revision = 2
    child_v2.timeline.tracks[0].items[0].id = "v2-clip"
    parent = Sequence(
        id="parent",
        name="Parent",
        timeline=Timeline(
            tracks=[
                VideoTrack(
                    id="parent-video",
                    items=[
                        NestedSequenceClip(
                            id="nested",
                            sequence_id="child",
                            sequence_version=1,
                            timeline_range=tr(0, 24),
                            source_range=tr(0, 24),
                        )
                    ],
                )
            ]
        ),
    )
    snapshot = SequenceSnapshot.from_sequence(child_v1)
    project = Project(
        id="versioned",
        name="Versioned",
        media=[media()],
        sequences=[parent, child_v2],
        sequence_versions=[snapshot],
        active_sequence_id="parent",
    )

    resolved = project.resolve_sequence("child", 1)

    assert resolved.revision == 1
    assert resolved.timeline.tracks[0].items[0].id == "v1-clip"
    assert snapshot.content_sha256 == snapshot.calculate_digest()
    tampered = snapshot.model_dump(mode="python")
    tampered["content_sha256"] = "0" * 64
    with pytest.raises(ValidationError, match="content digest"):
        SequenceSnapshot.model_validate(tampered)


def test_schema_1_0_projects_migrate_to_sequence_history_schema(tmp_path: Path) -> None:
    engine = VideoEngine(tmp_path)
    project = engine.create_project("Migration")
    payload = project.model_dump(mode="json")
    payload["schema_version"] = "1.0.0"
    payload.pop("sequence_versions")
    path = tmp_path / "old-project.json"
    path.write_text(json.dumps(payload), encoding="utf-8")

    migrated, migrations = engine.load_project(path)

    assert migrations == ["1.0.0->1.1.0", "1.1.0->1.2.0"]
    assert migrated.schema_version == "1.2.0"
    assert migrated.sequence_versions == []


def test_speed_ramp_integrates_exact_source_time_and_slices_windows() -> None:
    retime = Retime(
        speed_ramp=(
            SpeedRampPoint(time=RationalTime.zero(), rate=1),
            SpeedRampPoint(time=RationalTime(value=1, timescale=1), rate=2),
            SpeedRampPoint(time=RationalTime(value=2, timescale=1), rate=1),
        )
    )

    assert retime.source_offset_at(RationalTime(value=1, timescale=2)) == RationalTime(
        value=5, timescale=8
    )
    assert retime.source_offset_at(RationalTime(value=3, timescale=2)) == RationalTime(
        value=19, timescale=8
    )
    assert retime.source_offset_at(RationalTime(value=2, timescale=1)) == RationalTime(
        value=3, timescale=1
    )

    window = retime.window(RationalTime(value=1, timescale=2), RationalTime(value=1, timescale=1))
    assert [point.time for point in window.speed_ramp] == [
        RationalTime.zero(),
        RationalTime(value=1, timescale=2),
        RationalTime(value=1, timescale=1),
    ]
    assert [point.rate.fraction for point in window.speed_ramp] == [
        Fraction(3, 2),
        Fraction(2),
        Fraction(3, 2),
    ]
    assert window.source_offset_at(window.speed_ramp[-1].time) == RationalTime(value=7, timescale=4)
