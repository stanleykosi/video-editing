from __future__ import annotations

import json
from pathlib import Path

import pytest

from video_engine.api.engine import VideoEngine
from video_engine.cli.main import main
from video_engine.core.schema import (
    AudioClip,
    AudioTrack,
    CaptionCue,
    CaptionTrack,
    Clip,
    EffectKind,
    Gap,
    MediaReference,
    NestedSequenceClip,
    Sequence,
    StreamSummary,
    Timeline,
    VideoTrack,
)
from video_engine.core.time import FrameRate, RationalTime, TimeRange
from video_engine.errors import EngineError


def _write_edl(path: Path, body: str) -> Path:
    path.write_text(body.strip() + "\n", encoding="utf-8")
    return path


def _range(start: int, duration: int) -> TimeRange:
    return TimeRange(
        start=RationalTime(value=start, timescale=24),
        duration=RationalTime(value=duration, timescale=24),
    )


def _export_project(tmp_path: Path):  # type: ignore[no-untyped-def]
    engine = VideoEngine(tmp_path / "export-engine")
    project = engine.create_project(
        "Export Fixture",
        width=320,
        height=180,
        frame_rate=FrameRate(numerator=24),
    )
    project.media.append(
        MediaReference(
            id="offline-av",
            uri=str(tmp_path / "offline.mov"),
            offline=True,
            streams=[
                StreamSummary(index=0, codec_type="video", width=320, height=180),
                StreamSummary(
                    index=1,
                    codec_type="audio",
                    sample_rate=48_000,
                    channels=2,
                    channel_layout="stereo",
                ),
            ],
            extensions={
                "cmx:reel": "AX",
                "cmx:source_timecode_start": "01:00:00:00",
            },
        )
    )
    nested = Sequence(
        id="nested-section",
        name="Reusable section",
        timeline=Timeline(
            tracks=[
                VideoTrack(
                    id="nested-video",
                    items=[
                        Clip(
                            id="nested-clip",
                            name="Source",
                            media_reference_id="offline-av",
                            timeline_range=_range(0, 24),
                            source_range=_range(0, 24),
                            source_audio_enabled=False,
                        )
                    ],
                )
            ]
        ),
    )
    main = project.sequence()
    main.timeline.tracks.extend(
        [
            VideoTrack(
                id="main-video",
                items=[
                    NestedSequenceClip(
                        id="nested-use",
                        name="Nested",
                        sequence_id=nested.id,
                        timeline_range=_range(0, 24),
                        source_range=_range(0, 24),
                    )
                ],
            ),
            AudioTrack(
                id="main-audio",
                items=[
                    AudioClip(
                        id="main-audio-clip",
                        media_reference_id="offline-av",
                        timeline_range=_range(0, 24),
                        source_range=_range(0, 24),
                    )
                ],
            ),
            CaptionTrack(
                id="main-captions",
                items=[
                    CaptionCue(
                        id="cue-1",
                        text="Exact caption",
                        timeline_range=_range(0, 12),
                        speaker="Narrator",
                    )
                ],
            ),
        ]
    )
    project.sequences.append(nested)
    project.extensions["cmx:record_timecode_start"] = "10:00:00:00"
    return engine, project


def test_cmx_import_rebases_record_and_source_timecode_with_losses(tmp_path: Path) -> None:
    edl = _write_edl(
        tmp_path / "offline.edl",
        """
TITLE: CMX Fixture
FCM: NON-DROP FRAME

001  AX       V/A   C        01:00:00:00 01:00:01:00 10:00:00:00 10:00:01:00
* FROM CLIP NAME: missing.mov
002  AX       V/A   D 006    01:00:01:00 01:00:02:00 10:00:01:00 10:00:02:00
M2   AX      024.0  01:00:01:00
003  BL       V     C        00:00:00:00 00:00:00:12 10:00:02:00 10:00:02:12
""",
    )
    result = (
        VideoEngine(tmp_path / "engine")
        .adapters()
        .import_cmx(
            edl,
            frame_rate=FrameRate(numerator=24),
            source_timecodes={"AX": "01:00:00:00"},
        )
    )

    assert result.report.valid
    assert result.report.offline_assets == (str((tmp_path / "missing.mov").resolve()),)
    assert result.project.extensions["cmx:record_timecode_start"] == "10:00:00:00"
    video = next(
        track
        for track in result.project.sequence().timeline.tracks
        if isinstance(track, VideoTrack)
    )
    audio = next(
        track
        for track in result.project.sequence().timeline.tracks
        if isinstance(track, AudioTrack)
    )
    assert isinstance(video.items[0], Clip)
    assert video.items[0].timeline_range.start == RationalTime.zero()
    assert video.items[0].source_range.start == RationalTime.zero()
    assert len(video.transitions) == 1
    assert video.transitions[0].duration == RationalTime(value=1, timescale=4)
    assert isinstance(video.items[-1], Gap)
    assert len(audio.items) == 2
    assert any(issue.code == "cmx.m2_preserved" for issue in result.report.issues)


def test_cmx_non_drop_requires_explicit_rate(tmp_path: Path) -> None:
    edl = _write_edl(
        tmp_path / "rate.edl",
        """
FCM: NON-DROP FRAME
001 AX V C 00:00:00:00 00:00:01:00 00:00:00:00 00:00:01:00
""",
    )
    with pytest.raises(EngineError, match="requires an explicit frame rate"):
        VideoEngine(tmp_path / "engine").adapters().import_cmx(edl)


def test_cmx_drop_frame_defaults_to_2997_and_rejects_dropped_labels(tmp_path: Path) -> None:
    valid = _write_edl(
        tmp_path / "drop.edl",
        """
FCM: DROP FRAME
001 AX V C 00:00:00;00 00:00:01;00 00:10:00;00 00:10:01;00
""",
    )
    result = VideoEngine(tmp_path / "valid-engine").adapters().import_cmx(valid)
    assert result.project.settings.frame_rate == FrameRate.fps_29_97()

    invalid = _write_edl(
        tmp_path / "invalid-drop.edl",
        """
FCM: DROP FRAME
001 AX V C 00:01:00;00 00:01:01;00 00:10:00;00 00:10:01;00
""",
    )
    with pytest.raises(EngineError, match="timecode is invalid"):
        VideoEngine(tmp_path / "invalid-engine").adapters().import_cmx(invalid)


def _fcpxml() -> str:
    return """<?xml version="1.0" encoding="UTF-8"?>
<fcpxml version="1.10">
  <resources>
    <format id="r1" frameDuration="1/24s" width="320" height="180"/>
    <asset id="r2" name="Offline Source" start="3600s" duration="2s"
           hasVideo="1" hasAudio="1">
      <media-rep kind="original-media" src="file:///missing.mov"/>
    </asset>
    <media id="r3" name="Reusable Section">
      <sequence format="r1" duration="1s">
        <spine>
          <asset-clip ref="r2" offset="0s" start="3600s" duration="1s"/>
        </spine>
      </sequence>
    </media>
  </resources>
  <library><event name="Fixture"><project name="FCPXML Fixture">
    <sequence format="r1" duration="2s" tcStart="3600s">
      <spine>
        <asset-clip ref="r2" name="Opening" offset="0s" start="3600s" duration="1s">
          <adjust-transform position="10 -5" scale="110 90" rotation="5"/>
          <adjust-crop mode="trim">
            <trim-rect left="5" right="5" top="10" bottom="10"/>
          </adjust-crop>
          <marker start="14401/4s" value="Proof" note="Exact marker"/>
          <caption offset="1/2s" duration="1/2s" value="Native caption" role="speaker.one"/>
          <filter-video ref="missing-effect"/>
        </asset-clip>
        <transition name="Cross Dissolve" offset="1s" duration="1/4s"/>
        <ref-clip ref="r3" name="Nested" offset="1s" start="0s" duration="1s"/>
      </spine>
    </sequence>
  </project></event></library>
</fcpxml>
"""


def test_fcpxml_imports_resources_lanes_nested_captions_and_typed_effects(
    tmp_path: Path,
) -> None:
    source = tmp_path / "fixture.fcpxml"
    source.write_text(_fcpxml(), encoding="utf-8")
    result = VideoEngine(tmp_path / "engine").adapters().import_fcpxml(source)

    assert result.report.valid
    assert result.project.settings.frame_rate == FrameRate(numerator=24)
    assert (result.project.settings.width, result.project.settings.height) == (320, 180)
    assert len(result.project.sequences) == 2
    assert result.report.offline_assets == ("/missing.mov",)
    video = next(
        track
        for track in result.project.sequence().timeline.tracks
        if isinstance(track, VideoTrack)
    )
    clip = video.items[0]
    assert isinstance(clip, Clip)
    assert {effect.kind for effect in clip.effects} == {
        EffectKind.POSITION,
        EffectKind.SCALE,
        EffectKind.ROTATION,
        EffectKind.CROP,
    }
    crop = next(effect for effect in clip.effects if effect.kind is EffectKind.CROP)
    assert crop.parameters == {
        "x": 16,
        "y": 18,
        "width": 288,
        "height": 144,
        "space": "canvas",
    }
    assert isinstance(video.items[1], NestedSequenceClip)
    assert len(video.transitions) == 1
    assert any(isinstance(track, AudioTrack) for track in result.project.sequence().timeline.tracks)
    caption_track = next(
        track
        for track in result.project.sequence().timeline.tracks
        if isinstance(track, CaptionTrack)
    )
    assert caption_track.items[0].text == "Native caption"
    assert result.project.sequence().timeline.markers[0].time == RationalTime(
        value=1,
        timescale=4,
    )
    assert any(issue.code == "fcpxml.unsupported_child_preserved" for issue in result.report.issues)


def test_fcpxmld_bundle_resolution_and_xml_entity_rejection(tmp_path: Path) -> None:
    bundle = tmp_path / "fixture.fcpxmld"
    bundle.mkdir()
    (bundle / "Info.fcpxml").write_text(_fcpxml(), encoding="utf-8")
    assert VideoEngine(tmp_path / "bundle-engine").adapters().import_fcpxml(bundle).report.valid

    malicious = tmp_path / "malicious.fcpxml"
    malicious.write_text(
        """<?xml version="1.0"?>
<!DOCTYPE fcpxml [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
<fcpxml version="1.10"><resources>&xxe;</resources></fcpxml>
""",
        encoding="utf-8",
    )
    with pytest.raises(EngineError, match="forbidden XML constructs"):
        VideoEngine(tmp_path / "malicious-engine").adapters().import_fcpxml(malicious)


def test_interchange_migrate_cli_emits_machine_report(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    source = tmp_path / "cli.fcpxml"
    source.write_text(_fcpxml(), encoding="utf-8")
    project_path = tmp_path / "project.json"
    report_path = tmp_path / "losses.json"

    exit_code = main(
        [
            "migrate",
            "fcpxml",
            str(source),
            "--project-root",
            str(tmp_path / "engine"),
            "--output",
            str(project_path),
            "--report",
            str(report_path),
            "--json",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["ok"] is True
    assert payload["adapter"] == "fcpxml"
    assert project_path.is_file()
    assert report_path.is_file()


def test_otio_adapter_reports_missing_optional_dependency(tmp_path: Path) -> None:
    source = tmp_path / "timeline.otio"
    source.write_text("{}", encoding="utf-8")
    try:
        import opentimelineio  # noqa: F401
    except ModuleNotFoundError:
        with pytest.raises(EngineError, match="interchange dependency group"):
            VideoEngine(tmp_path / "engine").adapters().import_otio(
                source,
                frame_rate=FrameRate(numerator=24),
            )
    else:
        with pytest.raises(EngineError, match="could not read"):
            VideoEngine(tmp_path / "engine").adapters().import_otio(
                source,
                frame_rate=FrameRate(numerator=24),
            )


def test_otio_export_and_import_execute_with_optional_dependency(tmp_path: Path) -> None:
    otio = pytest.importorskip("opentimelineio")
    engine, project = _export_project(tmp_path)
    destination = tmp_path / "project.otio"

    exported = engine.exporter().export(project, destination, format="otio")
    external = otio.adapters.read_from_file(str(exported.path))
    assert external.name == project.name
    assert len(external.tracks) == 2

    imported = engine.adapters().import_otio(
        exported.path,
        frame_rate=FrameRate(numerator=24),
    )
    audio = next(
        track
        for track in imported.project.sequence().timeline.tracks
        if isinstance(track, AudioTrack)
    )
    assert imported.report.valid
    assert len(audio.items) == 1
    assert audio.items[0].source_range == _range(0, 24)
    assert any(issue.code == "otio.track_omitted" for issue in exported.issues)


def test_public_export_service_writes_project_and_caption_sidecars(tmp_path: Path) -> None:
    engine, project = _export_project(tmp_path)

    project_result = engine.exporter().export(project, tmp_path / "exported.json")
    loaded, migrations = engine.load_project(project_result.path)
    assert migrations == []
    assert loaded == project

    caption_result = engine.exporter().export(
        project,
        tmp_path / "captions.vtt",
        caption_track_id="main-captions",
    )
    assert caption_result.path.read_text(encoding="utf-8").startswith("WEBVTT")
    assert "Exact caption" in caption_result.path.read_text(encoding="utf-8")


def test_cmx_export_reimports_exact_ranges_and_origins(tmp_path: Path) -> None:
    engine, project = _export_project(tmp_path)
    main = project.sequence()
    main.timeline.tracks[0] = VideoTrack(
        id="main-video",
        items=[
            Clip(
                id="main-clip",
                name="Source",
                media_reference_id="offline-av",
                timeline_range=_range(0, 24),
                source_range=_range(0, 24),
                source_audio_enabled=False,
            )
        ],
    )

    exported = engine.exporter().export(project, tmp_path / "roundtrip.edl")
    assert exported.metadata["event_count"] == 2
    text = exported.path.read_text(encoding="utf-8")
    assert "10:00:00:00 10:00:01:00" in text
    assert "01:00:00:00 01:00:01:00" in text

    imported = engine.adapters().import_cmx(
        exported.path,
        frame_rate=FrameRate(numerator=24),
        source_timecodes={"AX": "01:00:00:00"},
    )
    assert imported.report.valid
    assert imported.project.extensions["cmx:record_timecode_start"] == "10:00:00:00"
    video = next(
        track
        for track in imported.project.sequence().timeline.tracks
        if isinstance(track, VideoTrack)
    )
    audio = next(
        track
        for track in imported.project.sequence().timeline.tracks
        if isinstance(track, AudioTrack)
    )
    assert video.items[0].timeline_range == _range(0, 24)
    assert video.items[0].source_range == _range(0, 24)
    assert audio.items[0].timeline_range == _range(0, 24)


def test_fcpxml_export_reimports_nested_sequence_audio_and_captions(
    tmp_path: Path,
) -> None:
    engine, project = _export_project(tmp_path)
    exported = engine.exporter().export(project, tmp_path / "roundtrip.fcpxml")

    xml = exported.path.read_text(encoding="utf-8")
    assert '<media id="r-sequence-1" name="Reusable section">' in xml
    assert '<ref-clip offset="0s" duration="1s"' in xml
    assert 'value="Exact caption"' in xml

    imported = engine.adapters().import_fcpxml(exported.path)
    assert imported.report.valid
    assert len(imported.project.sequences) == 2
    main = imported.project.sequence()
    video = next(track for track in main.timeline.tracks if isinstance(track, VideoTrack))
    assert isinstance(video.items[0], NestedSequenceClip)
    assert video.items[0].timeline_range == _range(0, 24)
    assert any(isinstance(track, AudioTrack) for track in main.timeline.tracks)
    captions = next(track for track in main.timeline.tracks if isinstance(track, CaptionTrack))
    assert captions.items[0].text == "Exact caption"


def test_export_cli_emits_machine_readable_loss_report(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    engine, project = _export_project(tmp_path)
    project_path = engine.save_project(project, tmp_path / "project.json")
    output = tmp_path / "export.fcpxml"

    exit_code = main(
        [
            "export",
            str(project_path),
            str(output),
            "--format",
            "fcpxml",
            "--json",
        ]
    )
    payload = json.loads(capsys.readouterr().out)
    assert exit_code == 0
    assert payload["ok"] is True
    assert payload["format"] == "fcpxml"
    assert payload["output"] == str(output.resolve())
    assert output.is_file()
