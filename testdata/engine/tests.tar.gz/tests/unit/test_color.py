from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest
from pydantic import ValidationError

from video_engine.api.engine import VideoEngine
from video_engine.color import (
    AutoGradePolicy,
    ColorMeasurements,
    ColorPipeline,
    CreativeGrade,
    TechnicalNormalization,
)
from video_engine.core.schema import ColorSpace, EffectKind
from video_engine.core.time import RationalTime, TimeRange


def test_public_color_pipeline_lowers_all_stages(tmp_path: Path) -> None:
    engine = VideoEngine(tmp_path)
    project = engine.create_project("Color")
    pipeline = engine.color().pipeline(
        input_space=ColorSpace.HLG,
        working_space=ColorSpace.REC709,
        normalization=TechnicalNormalization(tone_map="hable", peak_nits=1_000),
        creative_grade=CreativeGrade(
            exposure_stops=0.25,
            temperature=0.1,
            contrast=1.05,
            gamma=1.04,
            saturation=0.95,
            highlights=-0.1,
            shadows=0.08,
        ),
        lut_path=tmp_path / "look.cube",
        output_space=ColorSpace.REC709,
    )

    effects = pipeline.effects(id_prefix="hero")
    assert [effect.kind for effect in effects] == [
        EffectKind.COLOR_INTERPRETATION,
        EffectKind.COLOR_NORMALIZATION,
        EffectKind.COLOR_GRADE,
        EffectKind.LUT,
    ]
    settings = pipeline.apply_project_settings(project.settings)
    profile = pipeline.apply_delivery_profile(project.delivery_profiles[0])
    assert settings.working_color_space is ColorSpace.REC709
    assert profile.output_color_space is ColorSpace.REC709
    assert profile.pixel_format == "yuv420p"
    assert effects[2].parameters["gamma"] == 1.04


def test_color_pipeline_rejects_unknown_and_invalid_hdr_output(tmp_path: Path) -> None:
    service = VideoEngine(tmp_path).color()
    with pytest.raises(ValidationError, match="Extra inputs are not permitted"):
        ColorPipeline.model_validate({"input_space": ColorSpace.REC709, "mystery": True})
    with pytest.raises(ValidationError, match="10-bit"):
        service.pipeline(input_space=ColorSpace.REC709, output_space=ColorSpace.PQ)


def measurements(*, y_mean: float, y_range: float, saturation: float) -> ColorMeasurements:
    return ColorMeasurements(
        source_sha256="a" * 64,
        source_range=TimeRange(
            start=RationalTime.zero(),
            duration=RationalTime(value=1, timescale=1),
        ),
        requested_samples=10,
        frames_analyzed=10,
        bit_depth=8,
        y_mean=y_mean,
        y_range=y_range,
        y_std=y_range / 4,
        saturation_mean=saturation,
        ffmpeg_fingerprint="test",
        ffprobe_fingerprint="test",
        cache_key="b" * 64,
    )


def test_legacy_clean_policy_reproduces_measured_decision_bounds() -> None:
    policy = AutoGradePolicy()
    dark_flat = policy.grade(measurements(y_mean=0.30, y_range=0.50, saturation=0.10))
    balanced = policy.grade(measurements(y_mean=0.50, y_range=0.70, saturation=0.25))
    bright_punchy = policy.grade(measurements(y_mean=0.70, y_range=0.75, saturation=0.50))

    assert dark_flat.contrast == pytest.approx(1.08)
    assert dark_flat.gamma == pytest.approx(1.10)
    assert dark_flat.saturation == pytest.approx(1.04)
    assert balanced == CreativeGrade(contrast=1.03, saturation=0.98)
    assert bright_punchy.gamma == pytest.approx(0.97)
    assert bright_punchy.saturation == pytest.approx(0.96)


def test_auto_grade_policy_rejects_inconsistent_thresholds_and_clamps() -> None:
    with pytest.raises(ValidationError, match="flat range floor"):
        AutoGradePolicy(flat_range_floor=0.7, flat_range_threshold=0.6)
    with pytest.raises(ValidationError, match="saturation clamps"):
        AutoGradePolicy(maximum_saturation=1.01)
    with pytest.raises(ValidationError, match="minimum contrast"):
        AutoGradePolicy(minimum_contrast=2)


def test_legacy_grade_helper_is_typed_non_rendering_compatibility_cli() -> None:
    helper_path = Path(__file__).parents[2] / "tools" / "video-use" / "helpers" / "grade.py"
    implementation_path = (
        Path(__file__).parents[2] / "tools" / "video-use" / "compat" / "grade.py"
    )
    wrapper = helper_path.read_text(encoding="utf-8")
    implementation = implementation_path.read_text(encoding="utf-8")
    assert "from compat.grade import main" in wrapper
    assert "def _sample_frame_stats" not in implementation
    assert ".color().auto_grade(" in implementation
    assert "subprocess.run" not in implementation
    assert "--filter" not in implementation
    assert "--output" not in implementation
    assert "def apply_grade" not in implementation

    result = subprocess.run(
        [sys.executable, str(helper_path), "--print-preset", "subtle", "--json"],
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(result.stdout)
    assert payload["preset"] == "subtle"
    assert payload["effect"]["kind"] == "color_grade"
    assert payload["effect"]["parameters"]["contrast"] == pytest.approx(1.03)
